# Native migration combined transaction rehearsal v1

Rehearsal only. There is no live apply or service command. Takes a read-only SQLite backup of the current application database into a private rehearsal directory and exercises replacement of copied launcher/recovery-unit files plus an atomic SQLite migration receipt/cursor update. Live adapter/database state is never changed. Live inputs and all expected proposal hashes are checked.

Cross-file/database writes are not one atomic transaction. The protocol uses durable original-file backups, fsynced replacements and a phase journal while the SQLite cursor transaction remains uncommitted. Before database commit, any ordinary injected interruption restores both files and rolls back receipt/cursor together. After commit, it restores the copied files but preserves the committed cursor and migration receipt and records source restart forbidden; it never rewinds the cursor or restores a database automatically. Actual deployment must keep source/services stopped during this protocol and review post-commit failures explicitly.

Nine scenarios: success; faults after receipt insert, cursor update, either file replacement, immediately before commit and immediately after commit; changed cursor and changed controller binding. All preexisting tables except the committed cursor are fingerprinted for preservation. Rehearsal requires the exact proposed journal tail/prefix to verify cryptographically; if writers appended since proposal preparation, regenerate the proposal rather than modify expected hashes.

This checks ordinary exception recovery in disposable files/databases. Actual systemd orchestration, process crash/power loss recovery, final live transition implementation and post-install source freshness are not certified here. Previous native recovery and Source integration receipts remain separate requirements. No enrollment or activation is available.

No behavioral tests were run locally. Static AST/ZIP checks only; run review.py on the VM.
