# Source reader candidate — no live apply

Preserves full SHA256/sequence validation before exposing a snapshot. Uses private temporary data/index files with lazy sequence slicing and bounded per-record memory. Entire source prefix is verified under a shared lock. Limits: 2 GiB source, 8 MiB per line, 1,000,000 records; exceeding limits blocks. All records are retained on temporary disk; temporary disk space proportional to source size is required. Every poll still verifies the entire journal; CPU/time and temporary I/O are not incremental. No source truncation or cursor migration.

review.py verifies installed seal and exact reader baseline, stages an isolated backend, runs focused reader tests and existing bridge/preparation regressions on the VM, and optionally verifies the real journal without processing signals. It leaves stage and results for review. It does not install, restart, modify the journal, open broker credentials or qualify strategy admission. Current-source regression success does not alone certify all sealed-runtime dependencies. Building and installing a sealed successor and resolving warmup bindings remain separate.

Tests include >64 MiB journal, memory bound, corruption/incomplete tail rejection, sequence/slicing behavior, retained snapshot after source change, resource ceilings and shared-lock writer exclusion. No local behavioral tests were run. Static Python parsing and ZIP checks only.

V2 corrects the regression harness only: includes the synthetic preparation fixture helper from the repository and adds the isolated tests directory to PYTHONPATH. The reader candidate and its limits are unchanged from v1. Regression tests are not skipped.
