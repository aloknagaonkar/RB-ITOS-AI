import ast
import hashlib
import json
from pathlib import Path
import pytest


def reader(filename='candidate.py'):
    tree = ast.parse((Path(__file__).parent / filename).read_text())
    names = {'_SourceRecordSlice', '_VerifiedSourceRecords', 'verified_records'}
    nodes = [n for n in tree.body if isinstance(n, (ast.ClassDef, ast.FunctionDef)) and n.name in names
             or isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id.startswith('SOURCE_') for t in n.targets)]
    class Blocked(ValueError):
        pass
    import fcntl, os, operator, struct, tempfile
    from collections.abc import Sequence
    scope = dict(Path=Path, hashlib=hashlib, json=json, fcntl=fcntl, os=os,
                 operator=operator, struct=struct, tempfile=tempfile, Sequence=Sequence, Blocked=Blocked)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), filename, 'exec'), scope)
    return scope


def record(sequence, previous, padding=''):
    row = dict(sequence=sequence, previous_hash=previous, stage='OBSERVATION', payload={'padding': padding})
    row['record_hash'] = hashlib.sha256(json.dumps(row, sort_keys=True, separators=(',', ':'), ensure_ascii=False, default=str).encode()).hexdigest()
    return row


def write(path, count=4, padding=''):
    rows=[];previous=None
    with path.open('w') as f:
        for i in range(1,count+1):
            row=record(i,previous,padding);previous=row['record_hash'];f.write(json.dumps(row)+'\n');rows.append(row)
    return rows


def test_valid_sequence_slice_reverse_and_snapshot(tmp_path):
    p=tmp_path/'a';rows=write(p)
    with reader()['verified_records'](p) as result:
        assert len(result)==4 and result[-1]==rows[-1]
        assert list(result)==rows and list(result[1:])==rows[1:]
        assert list(result[::-1])==rows[::-1] and list(result[1:][::-1])==rows[1:][::-1]
        p.write_text('replaced after snapshot\n')
        assert list(result)==rows
        with pytest.raises(IndexError):result[4]


def test_large_journal_exceeds_old_limit_without_large_memory(tmp_path):
    import tracemalloc
    p=tmp_path/'a'
    # 68+ MiB with bounded per-line JSON. Do not retain generated records.
    previous=None
    with p.open('w') as f:
        for i in range(1,69):
            row=record(i,previous,'x'*(1024*1024));previous=row['record_hash'];f.write(json.dumps(row)+'\n')
    r=reader();tracemalloc.start()
    try:
        with r['verified_records'](p) as result:
            assert len(result)==68 and result[-1]['record_hash']==previous
            assert tracemalloc.get_traced_memory()[1] < 32*1024*1024
    finally:tracemalloc.stop()


@pytest.mark.parametrize('mutation', ['hash','sequence','previous','json','partial'])
def test_late_invalid_record_rejects_whole_snapshot(tmp_path,mutation):
    p=tmp_path/'a';rows=write(p)
    if mutation=='hash':rows[-1]['record_hash']='bad'
    if mutation=='sequence':rows[-1]['sequence']=10
    if mutation=='previous':rows[-1]['previous_hash']='bad'
    text=''.join(json.dumps(r)+'\n' for r in rows)
    if mutation=='json':text+='invalid\n'
    if mutation=='partial':text=text.rstrip('\n')
    p.write_text(text);r=reader()
    with pytest.raises((r['Blocked'],json.JSONDecodeError)):r['verified_records'](p)


def test_limits_and_empty_blank(tmp_path):
    p=tmp_path/'a';p.write_text('\n  \n');r=reader()
    with r['verified_records'](p) as result:assert len(result)==0
    write(p)
    for setting,value in [('SOURCE_RECORD_MAX_BYTES',16),('SOURCE_SNAPSHOT_MAX_BYTES',16),('SOURCE_RECORD_MAX_COUNT',1)]:
        r=reader();r[setting]=value
        with pytest.raises(r['Blocked']):r['verified_records'](p)


def test_writer_lock_exclusion(tmp_path):
    import fcntl
    p=tmp_path/'a';write(p);r=reader();original=r['_VerifiedSourceRecords']._append
    def locked(self,raw):
        with p.open('rb') as other:
            with pytest.raises(BlockingIOError):fcntl.flock(other,fcntl.LOCK_EX|fcntl.LOCK_NB)
        original(self,raw)
    r['_VerifiedSourceRecords']._append=locked
    with r['verified_records'](p) as result:assert len(result)==4


def test_all_non_reader_code_is_identical():
    def rest(filename):
        tree=ast.parse((Path(__file__).parent/filename).read_text())
        names={'verified_records','_VerifiedSourceRecords','_SourceRecordSlice'}
        return [ast.dump(n,include_attributes=False) for n in tree.body
                if not isinstance(n,(ast.Import,ast.ImportFrom))
                and not (isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names)
                and not (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id.startswith('SOURCE_') for t in n.targets))]
    assert rest('candidate.py')==rest('original.py')
