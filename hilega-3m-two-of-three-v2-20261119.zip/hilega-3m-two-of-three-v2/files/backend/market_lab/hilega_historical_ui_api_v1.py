"""Session-centric, read-only Hilega historical/live replay API.

The historical page selects a trading day, not a capture folder.

Source precedence for a selected day:
1. Current directional live-shadow audit
2. Rich Phase-7D historical capture
3. Legacy completed Hilega live-shadow audit
4. Per-session canonical Hilega replay
5. 120-session research summary fallback

This module never calls broker APIs, never starts/restarts a worker and never
submits orders. Existing append-only evidence is read without mutation.
"""
from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from fastapi import APIRouter, HTTPException, Query

from .hilega_milega_audit_report_v1 import build_audit_index
from .live_shadow_step_audit_v1 import ShadowStepAuditStoreV1

router = APIRouter(prefix="/api/live-shadow/hilega-historical", tags=["hilega-historical"])

IST = ZoneInfo("Asia/Kolkata")
ROOT = Path("data/historical-evidence")
REPLAY_ROOT = ROOT / "hilega-milega-replay-v1"
RESEARCH_ROOT = ROOT / "hilega-milega-bullish-expansion-multisession-v1"
LIVE_AUDIT = Path("data/live-observation/hilega-milega-v1/step-audit.jsonl")
DIRECTIONAL_LIVE_AUDIT = Path(
    "data/live-observation/hilega-directional-v1/step-audit.jsonl"
)

NAME_RE = re.compile(r"^hilega-phase7d-(\d{4}-\d{2}-\d{2})(?:-[a-zA-Z0-9_-]+)?$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

SOURCE_RANK = {
    "DIRECTIONAL_LIVE_SHADOW": 500,
    "PHASE7D": 400,
    "LIVE_SHADOW": 300,
    "SESSION_REPLAY": 200,
    "RESEARCH_120": 100,
}


def _json_file(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, OSError) as exc:
        raise HTTPException(422, f"Invalid historical artifact {path.name}: {type(exc).__name__}") from exc


def _row_day(row: dict) -> str | None:
    payload = row.get("payload") or {}
    for value in (
        row.get("checkpoint"),
        row.get("event_time"),
        payload.get("session_date"),
        payload.get("bar_timestamp"),
        payload.get("signal_bar"),
        payload.get("cutoff_timestamp"),
    ):
        value = str(value or "")
        if len(value) >= 10 and DATE_RE.fullmatch(value[:10]):
            return value[:10]
    return None


def _read_audit(path: Path):
    store = ShadowStepAuditStoreV1(path)
    try:
        chain_ok, chain_issue = store.verify_chain()
        rows = store.read_all()
    except (ValueError, OSError, KeyError, TypeError) as exc:
        raise HTTPException(422, f"Historical audit unreadable: {type(exc).__name__}") from exc
    return chain_ok, chain_issue, rows


def _phase7d_candidates(root: Path = ROOT):
    found = []
    if not root.is_dir():
        return found
    for child in root.iterdir():
        if not child.is_dir() or child.is_symlink():
            continue
        match = NAME_RE.fullmatch(child.name)
        if not match or not (child / "step-audit.jsonl").is_file():
            continue
        try:
            day = date.fromisoformat(match.group(1)).isoformat()
        except ValueError:
            continue
        manifest_path = child / "source-manifest.json"
        manifest = _json_file(manifest_path) if manifest_path.is_file() else {}
        found.append({
            "session_date": day,
            "source": "PHASE7D",
            "source_id": child.name,
            "path": child / "step-audit.jsonl",
            "manifest": manifest,
            "has_report": (child / "detailed-audit-report.json").is_file(),
            "has_manifest": manifest_path.is_file(),
            "ce_available": True,
            "evidence_level": "FULL",
            "status": "COMPLETE",
        })
    return found


def _replay_candidates(root: Path = REPLAY_ROOT):
    found = []
    if not root.is_dir():
        return found
    for child in root.iterdir():
        if not child.is_dir() or child.is_symlink() or not DATE_RE.fullmatch(child.name):
            continue
        audit = child / "step-audit.jsonl"
        if not audit.is_file():
            continue
        found.append({
            "session_date": child.name,
            "source": "SESSION_REPLAY",
            "source_id": f"replay:{child.name}",
            "path": audit,
            "manifest": {},
            "has_report": (child / "detailed-audit-report.json").is_file(),
            "has_manifest": False,
            "ce_available": False,
            "evidence_level": "STRATEGY",
            "status": "COMPLETE",
        })
    return found


def _live_is_complete(rows: list[dict]) -> bool:
    for row in rows:
        payload = row.get("payload") or {}
        if str(payload.get("state_after") or "").upper() == "SESSION_LOCKED":
            return True
        events = payload.get("events_emitted") or []
        if any(str(x).upper() == "SESSION_LOCKED_1455" for x in events):
            return True
        if str(row.get("status") or "").upper() == "SESSION_LOCKED_1455":
            return True
    return False


def _live_candidates(path: Path = LIVE_AUDIT):
    if not path.is_file():
        return []
    chain_ok, chain_issue, rows = _read_audit(path)
    grouped: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        day = _row_day(row)
        if day:
            grouped[day].append(row)

    today = datetime.now(IST).date().isoformat()
    found = []
    for day, day_rows in grouped.items():
        complete = _live_is_complete(day_rows)
        is_today = day == today
        # Keep the active trading day visible in the session registry so the
        # historical/session UI can reuse the same canonical candle renderer.
        # Active evidence is explicitly LIVE/PARTIAL; no evidence is rewritten.
        found.append({
            "session_date": day,
            "source": "LIVE_SHADOW",
            "source_id": f"live:{day}",
            "path": path,
            "manifest": {},
            "has_report": True,
            "has_manifest": False,
            "ce_available": any("OPTION_" in str(r.get("stage") or "") for r in day_rows),
            "evidence_level": "FULL" if complete else "PARTIAL",
            "status": "COMPLETE" if complete else ("LIVE" if is_today else "PARTIAL"),
            "live_chain_ok": chain_ok,
            "live_chain_issue": chain_issue,
        })
    return found


def _directional_live_is_complete(rows: list[dict]) -> bool:
    return any(
        str(row.get("stage") or "").upper() == "DIRECTIONAL_SESSION_CUTOFF"
        and str(row.get("status") or "").upper() == "PROCESSED"
        for row in rows
    )


def _directional_live_candidates(path: Path = DIRECTIONAL_LIVE_AUDIT):
    """Expose every recorded directional live day without copying evidence."""
    if not path.is_file():
        return []
    chain_ok, chain_issue, rows = _read_audit(path)
    grouped: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        day = _row_day(row)
        if day:
            grouped[day].append(row)

    today = datetime.now(IST).date().isoformat()
    found = []
    for day, day_rows in grouped.items():
        complete = _directional_live_is_complete(day_rows)
        found.append({
            "session_date": day,
            "source": "DIRECTIONAL_LIVE_SHADOW",
            "source_id": f"directional-live:{day}",
            "path": path,
            "manifest": {},
            "has_report": True,
            "has_manifest": False,
            "ce_available": any(
                "OPTION" in str(row.get("stage") or "").upper()
                for row in day_rows
            ),
            "evidence_level": "FULL" if complete else "PARTIAL",
            "status": "COMPLETE" if complete else (
                "LIVE" if day == today else "PARTIAL"
            ),
            "live_chain_ok": chain_ok,
            "live_chain_issue": chain_issue,
        })
    return found


def _research_files(root: Path = RESEARCH_ROOT):
    return root / "day-summary.csv", root / "trade-expansion-details.csv"


def _read_csv(path: Path):
    if not path.is_file():
        return []
    try:
        with path.open(newline="", encoding="utf-8") as handle:
            return list(csv.DictReader(handle))
    except OSError as exc:
        raise HTTPException(422, f"Historical CSV unreadable: {path.name}") from exc


def _research_candidates(root: Path = RESEARCH_ROOT):
    day_summary, trades = _research_files(root)
    dates = set()
    for row in _read_csv(day_summary):
        value = str(row.get("session_date") or row.get("date") or "")
        if DATE_RE.fullmatch(value):
            dates.add(value)
    for row in _read_csv(trades):
        value = str(row.get("session_date") or "")
        if DATE_RE.fullmatch(value):
            dates.add(value)
    return [{
        "session_date": day,
        "source": "RESEARCH_120",
        "source_id": f"research120:{day}",
        "path": trades,
        "manifest": {},
        "has_report": False,
        "has_manifest": False,
        "ce_available": False,
        "evidence_level": "SUMMARY",
        "status": "COMPLETE",
    } for day in dates]


def _all_candidates(root: Path = ROOT, replay_root: Path = REPLAY_ROOT,
                    research_root: Path = RESEARCH_ROOT, live_path: Path = LIVE_AUDIT,
                    directional_live_path: Path = DIRECTIONAL_LIVE_AUDIT):
    return (
        _phase7d_candidates(root)
        + _directional_live_candidates(directional_live_path)
        + _live_candidates(live_path)
        + _replay_candidates(replay_root)
        + _research_candidates(research_root)
    )


def _best_for_day(rows: list[dict]):
    def score(x):
        rich = 20 if x.get("has_report") else 0
        manifest = 5 if x.get("has_manifest") else 0
        # For Phase-7D variants, later/richer capture IDs (e.g. d4) sort last.
        return (SOURCE_RANK.get(x["source"], 0) + rich + manifest, x.get("source_id", ""))
    return sorted(rows, key=score, reverse=True)[0]


def list_sessions(root: Path = ROOT, replay_root: Path = REPLAY_ROOT,
                  research_root: Path = RESEARCH_ROOT, live_path: Path = LIVE_AUDIT,
                  directional_live_path: Path = DIRECTIONAL_LIVE_AUDIT):
    grouped: dict[str, list[dict]] = defaultdict(list)
    for row in _all_candidates(
        root, replay_root, research_root, live_path, directional_live_path
    ):
        grouped[row["session_date"]].append(row)

    sessions = []
    for day, rows in grouped.items():
        best = _best_for_day(rows)
        alternatives = sorted({x["source"] for x in rows})
        sessions.append({
            "session_date": day,
            "source": best["source"],
            "source_id": best["source_id"],
            "status": best["status"],
            "evidence_level": best["evidence_level"],
            "ce_available": bool(best.get("ce_available")),
            "expiry": (best.get("manifest") or {}).get("expiry"),
            "available_sources": alternatives,
        })
    from .recovered_replay_ui_v1 import hilega_sessions
    return hilega_sessions(sorted(sessions, key=lambda x: x["session_date"], reverse=True))


def _load_audit_candidate(candidate: dict):
    chain_ok, chain_issue, rows = _read_audit(candidate["path"])
    day = candidate["session_date"]
    rows = [r for r in rows if _row_day(r) == day]
    reports = build_audit_index(
        rows,
        mode="HISTORICAL_SESSION_REGISTRY_V1",
        chain_ok=chain_ok,
        chain_issue=chain_issue,
    )
    reports.sort(key=lambda x: x["checkpoint"])
    return {
        "session_date": day,
        "source": candidate["source"],
        "source_id": candidate["source_id"],
        "evidence_level": candidate["evidence_level"],
        "ce_available": bool(candidate.get("ce_available")),
        "manifest": candidate.get("manifest") or {},
        "audit_chain_ok": chain_ok,
        "audit_chain_issue": chain_issue,
        "reports": reports,
        "report_count": len(reports),
        "observation_only": True,
        "execution_enabled": False,
        "warning": (
            "Read-only session view. Source evidence is preserved as recorded. "
            "No broker request, replay worker or execution action is started."
        ),
    }


def _directional_report(row: dict) -> dict:
    """Project a directional candle into the established audit-table contract."""
    accepted = [x for x in str(row.get("accepted_events") or "").split(",") if x]
    transitions = [{
        "event_time": row.get("bar_timestamp"),
        "event_type": event,
        "price": row.get("close"),
        "source": "DIRECTIONAL_LIVE_AUDIT",
        "state_before": row.get("owner_before"),
        "state_after": row.get("owner_after"),
        "details": {
            "bullish_state": row.get("bullish_state"),
            "bearish_state": row.get("bearish_state"),
            "suppressed_events": row.get("suppressed_events"),
        },
    } for event in accepted]
    if row.get("strategy_id") in {"HILEGA_WMA_GAP_V2_LIVE_SHADOW", "HILEGA_V2_ALIGNMENT_DUAL_EXIT"}:
        details = {x.get("event_type"): x for x in row.get("event_details") or []}
        for transition in transitions:
            event = details.get(transition["event_type"], {})
            transition.update({key: event.get(key) for key in ("price", "points", "entry_price", "entry_time", "exit_reason")})
            transition["details"].update({"original_entry_time": event.get("entry_time"),
                                          "original_entry_price": event.get("entry_price")})
    selected_route = next((
        route for route in ("ROUTE_A", "ROUTE_B", "OPENING")
        if any(route in event for event in accepted)
    ), None)
    return {
        "checkpoint": row.get("bar_timestamp"),
        "audit_row_id": row.get("audit_row_id"),
        "bar": {key: row.get(key) for key in ("open", "high", "low", "close", "volume")},
        "indicators": {
            "rsi9": row.get("rsi9"),
            "ema3_rsi": row.get("ema3_rsi"),
            "wma21_rsi": row.get("wma21_rsi"),
        },
        "conditions": {"authoritative_strategy_steps": bool(row.get("strategy_steps")), "strategy_steps": row.get("strategy_steps") or [], "policy_events": row.get("policy_events") or [], "wma_gap_checks": row.get("wma_gap_checks") or [], "canonical_setup": row.get("canonical_setup"), "decision_interval_minutes": row.get("decision_interval_minutes",5), "exit_validation": row.get("exit_validation"), "opposite_confirmation": row.get("opposite_confirmation"), "indicator_timestamp": row.get("indicator_timestamp"), "setup_attempts": row.get("setup_attempts") or [], "exit_warning_time": row.get("exit_warning_time")},
        "strategy": {
            "strategy_id": row.get("strategy_id"),
            "policy_id": row.get("policy_id"),
            "strategy_version": row.get("strategy_version"),
            "decision_timestamp": row.get("decision_timestamp"),
            "source_bar_timestamp": row.get("source_bar_timestamp"),
            "directional_action": row.get("action"),
            "manual_exit": row.get("manual_exit"),
            "manual_exit_source_state": row.get("manual_exit_source_state"),
            "state_before": row.get("owner_before"),
            "state_after": row.get("owner_after"),
            "selected_route": selected_route,
            "events_emitted": accepted,
            "direction": __import__("market_lab.hilega_pending_direction_display_v1", fromlist=["resolve_audit_direction"]).resolve_audit_direction(row),
            "bullish_state": row.get("bullish_state"),
            "bearish_state": row.get("bearish_state"),
            "bullish_armed": row.get("bullish_armed"),
            "bearish_armed": row.get("bearish_armed"),
        },
        "route_a": {},
        "route_b": {},
        "transitions": transitions,
        "option_candidate": None,
        "option_market_snapshot": None,
        "option_lifecycle": {},
        "audit_integrity": {
            "source": "DIRECTIONAL_LIVE_AUDIT",
            "canonical_step_audit_available": bool(row.get("directional_evidence")),
        },
        "safety": {
            "observation_only": True,
            "execution_enabled": False,
            "paper_order_enabled": False,
        },
    }


def _load_directional_live_candidate(candidate: dict):
    # Lazy import avoids coupling session discovery to candle reconstruction.
    from .hilega_directional_candle_ui_v1 import build_live_directional_candles

    chain_ok, chain_issue, _ = _read_audit(candidate["path"])
    candles = build_live_directional_candles(candidate["session_date"])
    reports = [
        _directional_report(row) for row in candles.get("rows", [])
        if row.get("bar_timestamp")
    ]
    reports.sort(key=lambda row: row["checkpoint"])
    return {
        "session_date": candidate["session_date"],
        "source": candidate["source"],
        "source_id": candidate["source_id"],
        "evidence_level": candidate["evidence_level"],
        "ce_available": bool(candidate.get("ce_available")),
        "manifest": {},
        "audit_chain_ok": chain_ok,
        "audit_chain_issue": chain_issue,
        "reports": reports,
        "report_count": len(reports),
        "observation_only": True,
        "execution_enabled": False,
        "warning": (
            "Read-only replay from the recorded directional live audit and market "
            "evidence. Bullish and bearish decisions are preserved; no broker call, "
            "strategy execution or synthetic trade is created."
        ),
    }


def _float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _iso(day: str, hhmm: str):
    if not hhmm:
        return None
    return f"{day}T{hhmm}:00+05:30"


def _entry_event(source: str):
    value = source.upper()
    if "ROUTE_A" in value:
        return "ENTRY_PATH1_ROUTE_A_CROSS_RSI50_ABOVE_WMA21", "ROUTE_A"
    if "ROUTE_B" in value:
        return "ENTRY_PATH1_ROUTE_B_STRUCTURAL", "ROUTE_B"
    return "ENTRY_OPENING_BULLISH_CONFIRMED", "OPENING_PATH"


def _summary_report(checkpoint: str, *, close, state_before, state_after,
                    selected_route, event_type, price, points=None,
                    original_entry_time=None):
    event = {
        "event_time": checkpoint,
        "event_type": event_type,
        "price": price,
        "entry_price": price if event_type.startswith("ENTRY_") else None,
        "entry_time": checkpoint if event_type.startswith("ENTRY_") else None,
        "exit_reason": "RSI_CROSS_BELOW_WMA21" if "STRUCTURAL_EXIT" in event_type else None,
        "points": points,
        "source": selected_route,
        "state_before": state_before,
        "state_after": state_after,
        "details": {"original_entry_time": original_entry_time} if original_entry_time else None,
    }
    return {
        "checkpoint": checkpoint,
        "bar": {"open": None, "high": None, "low": None, "close": close, "volume": None},
        "indicators": {},
        "conditions": {},
        "strategy": {
            "state_before": state_before,
            "state_after": state_after,
            "selected_route": selected_route if event_type.startswith("ENTRY_") else None,
            "events_emitted": [event_type],
        },
        "route_a": {},
        "route_b": {},
        "transitions": [event],
        "option_candidate": None,
        "option_market_snapshot": None,
        "option_lifecycle": {},
        "audit_integrity": {
            "source": "RESEARCH_120_SUMMARY",
            "canonical_step_audit_available": False,
        },
        "safety": {"observation_only": True, "execution_enabled": False},
    }


def _load_research_summary(candidate: dict, research_root: Path = RESEARCH_ROOT):
    _, trades_path = _research_files(research_root)
    day = candidate["session_date"]
    reports = []
    for row in _read_csv(trades_path):
        if str(row.get("session_date") or "") != day:
            continue
        entry_time = str(row.get("entry_time") or "")
        exit_time = str(row.get("exit_time") or "")
        entry_cp = _iso(day, entry_time)
        exit_cp = _iso(day, exit_time)
        if not entry_cp:
            continue
        event_type, route = _entry_event(str(row.get("source") or ""))
        entry_close = _float(row.get("entry_close"))
        exit_close = _float(row.get("exit_close"))
        points = _float(row.get("points"))
        reports.append(_summary_report(
            entry_cp, close=entry_close, state_before="PATH1_IDLE",
            state_after="BULLISH_ACTIVE", selected_route=route,
            event_type=event_type, price=entry_close,
        ))
        if exit_cp:
            reports.append(_summary_report(
                exit_cp, close=exit_close, state_before="BULLISH_ACTIVE",
                state_after="PATH1_IDLE", selected_route=route,
                event_type="STRUCTURAL_EXIT_RSI_CROSS_BELOW_WMA21",
                price=exit_close, points=points, original_entry_time=entry_cp,
            ))
    reports.sort(key=lambda x: x["checkpoint"])
    return {
        "session_date": day,
        "source": "RESEARCH_120",
        "source_id": candidate["source_id"],
        "evidence_level": "SUMMARY",
        "ce_available": False,
        "manifest": {},
        "audit_chain_ok": None,
        "audit_chain_issue": "Canonical per-candle step audit was not recorded for this research-only session.",
        "reports": reports,
        "report_count": len(reports),
        "observation_only": True,
        "execution_enabled": False,
        "warning": (
            "120-session research fallback: entry/exit summary only. "
            "Full five-minute conditions and exact ATM±2 CE lifecycle are unavailable "
            "unless a richer replay/capture exists for this day."
        ),
    }


def load_session(session_date: str, root: Path = ROOT, replay_root: Path = REPLAY_ROOT,
                 research_root: Path = RESEARCH_ROOT, live_path: Path = LIVE_AUDIT,
                 directional_live_path: Path = DIRECTIONAL_LIVE_AUDIT,
                 preferred_source: str | None = None):
    try:
        day = date.fromisoformat(session_date).isoformat()
    except ValueError as exc:
        raise HTTPException(422, "Invalid session date") from exc

    candidates = [
        x for x in _all_candidates(
            root, replay_root, research_root, live_path, directional_live_path
        )
        if x["session_date"] == day
    ]
    if not candidates:
        raise HTTPException(404, "Hilega session not found")
    preferred = str(preferred_source or "").strip().upper()
    matches = [x for x in candidates if str(x.get("source") or "").upper() == preferred]
    best = _best_for_day(matches or candidates)
    if best["source"] == "RESEARCH_120":
        result = _load_research_summary(best, research_root)
    elif best["source"] == "DIRECTIONAL_LIVE_SHADOW":
        result = _load_directional_live_candidate(best)
    else:
        result = _load_audit_candidate(best)
    result["available_sources"] = sorted({x["source"] for x in candidates})
    return result


class _CacheOnlyUnderlyingGateway:
    """Historical V2 testing may consume cached candles, never broker data."""

    def __init__(self, cache_root: Path):
        self.cache_root = cache_root

    def historical_candles(self, instrument_key: str, session_date: date):
        from .hilega_milega_historical_replay_v1 import _read_cache

        return _read_cache(
            self.cache_root / f"{session_date.isoformat()}.json",
            instrument_key,
            session_date,
        ) or []


def _v2_report(row: dict) -> dict:
    checkpoint = row["bar_timestamp"]
    accepted = [x for x in str(row.get("accepted_events") or "").split(",") if x]
    suppressed = [x for x in str(row.get("suppressed_events") or "").split(",") if x]
    transitions = [{
        "event_type": event,
        "event_time": checkpoint,
        "price": row.get("close"),
        "source": event,
        "state_before": row.get("owner_before"),
        "state_after": row.get("owner_after"),
    } for event in accepted]
    return {
        "checkpoint": checkpoint,
        "bar": {key: row.get(key) for key in ("open", "high", "low", "close", "volume")},
        "indicators": {
            "rsi9": row.get("rsi9"), "ema3_rsi": row.get("ema3_rsi"),
            "wma21_rsi": row.get("wma21_rsi"),
            "previous_wma21_rsi": row.get("previous_wma21_rsi"),
        },
        "conditions": {
            "wma21_slope_required": True,
            "wma21_slope_change": row.get("wma21_slope_change"),
            "wma21_slope_direction": row.get("wma21_slope_direction"),
            "wma21_slope_gate_status": row.get("wma21_slope_gate_status"),
            "wma21_current_candle": row.get("wma21_current_candle"),
            "wma21_previous_candle": row.get("wma21_previous_candle"),
            "wma21_slope_interval_minutes": row.get("wma21_slope_interval_minutes"),
            "bullish_wma21_rising": row.get("bullish_wma21_rising"),
            "bearish_wma21_falling": row.get("bearish_wma21_falling"),
            "bullish_wma21_slope_pass": row.get("bullish_wma21_slope_pass"),
            "bearish_wma21_slope_pass": row.get("bearish_wma21_slope_pass"),
            "bullish_wma21_slope_rejection": row.get("bullish_wma21_slope_rejection"),
            "bearish_wma21_slope_rejection": row.get("bearish_wma21_slope_rejection"),
        },
        "strategy": {
            "strategy_id": "HILEGA_DIRECTIONAL_SHADOW_V2",
            "strategy_version": "2.0.0",
            "directional_action": row.get("action"),
            "owner_before": row.get("owner_before"), "owner_after": row.get("owner_after"),
            "state_before": row.get("owner_before"), "state_after": row.get("owner_after"),
            "events_emitted": accepted, "suppressed_events": suppressed,
            "note": row.get("note"),
        },
        "route_a": {"fail_reasons": [x for x in (row.get("bullish_wma21_slope_rejection"), row.get("bearish_wma21_slope_rejection")) if x]},
        "route_b": {"fail_reasons": []},
        "transitions": transitions,
        "option_candidate": None, "option_market_snapshot": None, "option_lifecycle": {},
        "audit_integrity": {"source": "CACHED_CANDLE_V2_OBSERVATION_TEST", "chain_ok": None, "canonical_step_audit_available": False},
        "safety": {"observation_only": True, "execution_enabled": False, "paper_order_enabled": False},
    }


@router.get("/strategy-test")
def strategy_test(session_date: str = Query(..., min_length=10, max_length=10),
                  strategy: str = Query("V2", max_length=20),
                  input_basis: str = Query("LOCAL", pattern="^(LOCAL|VALIDATED)$")):
    try:
        day = date.fromisoformat(session_date)
    except ValueError as exc:
        raise HTTPException(422, "Invalid session date") from exc
    try:
        if strategy.strip().upper() == "V2_ALIGN_LEGACY":
            from . import hilega_v2_alignment_replay_v1 as legacy
            from .hilega_v2_replay_presentation_v1 import project_session
            return project_session(legacy.load_session(day.isoformat()))
        if strategy.strip().upper() == "V2_ALIGN":
            from .hilega_v2_replay_presentation_v1 import load_session as load_alignment
            from .hilega_v2_alignment_replay_v1 import ReplayBusyError
            try:
                return load_alignment(day.isoformat(),input_basis=input_basis)
            except ReplayBusyError as exc:
                raise HTTPException(409, str(exc)) from exc
            except FileNotFoundError as exc:
                raise HTTPException(404, str(exc)) from exc
            except ValueError as exc:
                raise HTTPException(422, str(exc)) from exc
        from .recovered_replay_ui_v1 import load_hilega
        recovered = load_hilega(day.isoformat(), "V1" if strategy.strip().upper() == "V1" else "V2")
        if recovered is not None:
            return recovered
        from .hilega_wma_gap_historical_v1 import (
            build_v1_session,
            build_wma_gap_session,
            recorded_live_metrics,
        )
        result = (build_v1_session(day.isoformat())
                  if strategy.strip().upper() == "V1"
                  else build_wma_gap_session(day.isoformat()))
        try:
            recorded = load_session(day.isoformat())
        except HTTPException:
            recorded = None
        if recorded and recorded.get("source") in {
            "LIVE_SHADOW", "DIRECTIONAL_LIVE_SHADOW"
        }:
            recorded_reports = recorded.get("reports") or []
            live_metrics = recorded_live_metrics(recorded_reports)
            result["performance_summary"][0] = live_metrics
            canonical_metrics = next(
                (row for row in result["performance_summary"]
                 if row.get("strategy_id") == "HILEGA_V1_REPLAY"),
                {"signals": 0, "completed": 0},
            )
            live_entries = []
            for report in recorded_reports:
                for transition in report.get("transitions") or []:
                    event = str(transition.get("event_type") or "")
                    if not event.startswith("ENTRY_"):
                        continue
                    live_entries.append({
                        "timestamp": transition.get("event_time") or report.get("checkpoint"),
                        "direction": "BEARISH" if "BEARISH" in event else "BULLISH",
                        "event_type": event,
                    })
            replay_entries = []
            for report in result.get("reports") or []:
                event = str((report.get("strategy") or {}).get("directional_action") or "")
                if event not in {"HILEGA_V1_CANONICAL_ENTRY", "WMA_GAP_SIGNAL_RECEIVED"}:
                    continue
                replay_entries.append({
                    "timestamp": report.get("checkpoint"),
                    "direction": str((report.get("strategy") or {}).get("direction") or
                                     (report.get("conditions") or {}).get("direction") or ""),
                    "event_type": event,
                })
            live_count = int(live_metrics.get("signals") or 0)
            replay_count = int(canonical_metrics.get("signals") or 0)
            parity_ok = live_count == replay_count
            result["parity"] = {
                "status": "PASS" if parity_ok else "PARITY_MISMATCH",
                "recorded_live_signals": live_count,
                "recorded_live_completed": int(live_metrics.get("completed") or 0),
                "canonical_replay_signals": replay_count,
                "canonical_replay_completed": int(canonical_metrics.get("completed") or 0),
                "recorded_live_entries": live_entries,
                "canonical_replay_entries": replay_entries,
            }
            result["forward_confirmation_eligible"] = parity_ok
            if not parity_ok:
                result["warning"] = (
                    "PARITY_MISMATCH: recorded live and canonical replay signal counts differ. "
                    "This session is diagnostic only and is excluded from forward confirmation."
                )
        return result
    except FileNotFoundError as exc:
        raise HTTPException(
            404,
            f"{strategy} replay evidence unavailable for {session_date}: {exc}. "
            "Recorded live and other strategy evidence remain separate.",
        ) from exc


@router.get("/wma-gap-forward-status")
def wma_gap_forward_status():
    path = ROOT / "hilega-wma-gap-forward-confirmation-v1" / "report.json"
    if not path.is_file():
        return {
            "model": "HILEGA_WMA_GAP_FORWARD_CONFIRMATION_V1",
            "available": False,
            "forward_sessions": 0,
            "selected_dates": [],
            "observation_only": True,
            "execution_enabled": False,
        }
    result = _json_file(path)
    result["available"] = True
    return result


# Backward-compatible capture discovery remains available for old bookmarks/tests.
def _candidate_dirs(root: Path = ROOT):
    return [(x["session_date"], x["path"].parent) for x in _phase7d_candidates(root)]


def list_available(root: Path = ROOT):
    sessions = []
    for row in _phase7d_candidates(root):
        sessions.append({
            "session_date": row["session_date"],
            "capture_id": row["source_id"],
            "has_report": row["has_report"],
            "has_manifest": row["has_manifest"],
            "expiry": (row.get("manifest") or {}).get("expiry"),
            "audit_path_present": True,
        })
    return sorted(sessions, key=lambda x: (x["session_date"], x["capture_id"]), reverse=True)


def load_capture(capture_id: str, root: Path = ROOT):
    valid = {x["source_id"]: x for x in _phase7d_candidates(root)}
    if capture_id not in valid:
        raise HTTPException(404, "Historical Hilega capture not found")
    result = _load_audit_candidate(valid[capture_id])
    result["capture_id"] = capture_id
    return result


@router.get("/sessions")
def sessions():
    return {
        "model": "HILEGA_SESSION_REGISTRY_V1",
        "sessions": __import__("market_lab.hilega_combined_replay_v1", fromlist=["merge_sessions"]).merge_sessions(list_sessions()),
    }


@router.get("/session")
def session(session_date: str = Query(..., min_length=10, max_length=10),
            source: str | None = Query(None, max_length=40)):
    return load_session(session_date, preferred_source=source)


@router.get("/capture")
def capture(capture_id: str = Query(..., max_length=120)):
    return load_capture(capture_id)


@router.get('/comparison-metrics')
def comparison_metrics(session_date: str = Query(..., min_length=10, max_length=10),
                       input_basis: str = Query('LOCAL', pattern='^(LOCAL|VALIDATED)$')):
    """Independent evidence per row; a missing replay never hides recorded data."""
    try:day=date.fromisoformat(session_date).isoformat()
    except ValueError as exc:raise HTTPException(422,'Invalid session date') from exc
    from .hilega_wma_gap_historical_v1 import recorded_live_metrics
    rows=[]
    for key,identifier in [('LIVE','LIVE_RECORDED_V1'),('V1','HILEGA_V1_REPLAY'),('V2','HILEGA_WMA_GAP_V2_REPLAY'),('V2_ALIGN','HILEGA_V2_ALIGNMENT_DUAL_EXIT_REPLAY_V1')]:
        try:
            if key=='LIVE':
                source=load_session(day)
                if source.get('source') not in {'LIVE_SHADOW','DIRECTIONAL_LIVE_SHADOW'}:
                    raise FileNotFoundError('No recorded live audit for '+day+'; replay outcomes are not live evidence')
                metric=recorded_live_metrics(source.get('reports') or [])
            else:
                source=strategy_test(day,strategy=key,input_basis=input_basis if key=='V2_ALIGN' else 'LOCAL')
                metric=next((r for r in source.get('performance_summary',[]) if r.get('strategy_id')==identifier),None)
                if metric is None:raise FileNotFoundError('No '+key+' metrics in saved strategy evidence for '+day)
            rows.append(dict(metric,evidence_source=source.get('source')))
        except (HTTPException,FileNotFoundError,ValueError) as exc:
            detail=exc.detail if isinstance(exc,HTTPException) else str(exc)
            rows.append(dict(strategy_id=identifier,available=False,unavailable_reason=str(detail)))
    return dict(session_date=day,performance_summary=rows,observation_only=True,execution_enabled=False)
