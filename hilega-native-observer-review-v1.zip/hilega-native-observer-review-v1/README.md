# Native policy observer candidate review

No installation, service changes, live database access or broker calls. Binds the exact VM publisher SHA a442b9... and stages only a replacement Publisher.on_row plus the reviewed native contract and a routing module. All other publisher code, selector, feed and policy gates remain unchanged. The separate quote-stream v4 native selector is not replaced or certified by this observer candidate.

Native policy/version/strategy identity, detailed confirmed events and three-minute boundaries are validated. Reconstructed and previous-session entries are ignored. Exits precede opposite entries for observation only; identities deduplicate repeated observations. Legacy journal rows are ignored rather than relabeled. Manual resets and signal-free observation rows are not promoted without native schema qualification. No retrospective live qualification is claimed.

The existing exact-minute velocity gate is preserved. Native continuous price-observation cadence and close coverage are not yet qualified, so policy evaluation may remain NOT_EVALUABLE. Review PASS means event routing compatibility only, not publisher restoration or policy admission. Existing publisher state needs transition/baseline review before install or restart. No cursor or state reset is performed.

Runs eleven disposable routing tests, including the actual candidate Publisher.on_row method via isolated AST extraction without constructing Publisher, and scans the locked hash-verified real journal for native event compatibility. Only AST and ZIP checks performed locally; behavioral review runs on the VM.
