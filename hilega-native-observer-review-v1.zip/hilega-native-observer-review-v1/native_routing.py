"""Native decision routing for observation only. No broker, database or service calls."""
import math
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
from native_contract import accepted,POLICY,VERSION,ContractBlocked
STRATEGY='HILEGA_RSI_TWO_ROUTE_CONFIRMED_MIDPOINT'
IST=ZoneInfo('Asia/Kolkata')
def on_row(self,row,*,current=None):
    p=row.get('payload') or {}
    if not isinstance(p,dict):raise ContractBlocked('SOURCE_PAYLOAD_INVALID')
    # The append-only journal includes older strategies. Never relabel those rows.
    if p.get('policy_id')!=POLICY and p.get('strategy_id')!=STRATEGY:return
    if p.get('policy_id')!=POLICY or p.get('strategy_version')!=VERSION or p.get('strategy_id')!=STRATEGY:
        raise ContractBlocked('SOURCE_POLICY_OR_VERSION_MISMATCH')
    if row.get('stage') not in {'DIRECTIONAL_DECISION','DIRECTIONAL_SESSION_CUTOFF'} or row.get('status')!='PROCESSED':return
    if p.get('reconstructed') is True:return
    events=accepted(row)
    # No signal-free observations are used as minute velocity evidence until their
    # native schema and cadence are separately qualified.
    if not events:return
    current=current or datetime.now(timezone.utc)
    if current.tzinfo is None:raise ContractBlocked('AWARE_OBSERVER_CLOCK_REQUIRED')
    at=datetime.fromisoformat(events[0]['event_at'])
    if at.astimezone(IST).date()!=current.astimezone(IST).date():return
    if at>current:raise ContractBlocked('FUTURE_NATIVE_OBSERVATION')
    entries=[e for e in events if e['role']=='ENTRY']
    close=p.get('nifty_close')
    if entries and (isinstance(close,bool) or not isinstance(close,(int,float)) or not math.isfinite(close) or close<=0):
        raise ContractBlocked('CONFIRMED_SIGNAL_SPOT_MISSING')
    # The contract yields exits before entries. All validation above precedes mutation.
    for event in events:
        if event['role']=='EXIT':
            self.request_exit(event['direction'],event['event_at'],event.get('exit_reason') or 'STRATEGY_EXIT')
            continue
        oid='HILEGA-NATIVE-POLICY-'+event['id'][:24]
        if oid in self.state['pending'] or self.store.db.execute('SELECT 1 FROM state WHERE id=?',(oid,)).fetchone():continue
        context=dict(direction=event['direction'],signal_confirmed=True,velocity_confirmed=False,
                     signal_timestamp=event['event_at'],spot=float(close),strategy_version=VERSION,strategy_policy_id=POLICY)
        self.state['pending'][oid]=dict(context=context,audit_sequence=row['sequence'],event_type=event['source_event'])
