"""Stage native observer routing and run disposable checks. Never installs or starts services."""
import argparse,ast,hashlib,importlib.util,json,os,subprocess,sys,tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
EXPECTED='a442b9bd390df162e4179275e97ccaa9ff5c02b373e5703978cc744146cc0053'
def need(v,reason):
    if not v:raise ValueError(reason)
def raw(p):
    need(not any(q.is_symlink() for q in (p,*p.parents)),'SYMLINK_REJECTED');return p.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def verify(folder):
    for n,h in json.loads(raw(folder/'MANIFEST.json')).items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts and sha(raw(folder/rel))==h,'PACKAGE_CHANGED')
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n');p.chmod(0o600)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);a=ap.parse_args();repo=a.repo.resolve();verify(HERE)
    source=repo/'hilega_policy_live/publisher.py';b=raw(source);need(sha(b)==EXPECTED,'INSTALLED_PUBLISHER_CHANGED');text=b.decode();tree=ast.parse(text);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Publisher');method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='on_row')
    replacement="    def on_row(self, row):\n        from native_routing import on_row\n        return on_row(self, row, current=now())\n"
    lines=text.splitlines(keepends=True);candidate=''.join(lines[:method.lineno-1])+replacement+''.join(lines[method.end_lineno:]);ast.parse(candidate)
    audit=Path(tempfile.mkdtemp(prefix='hilega-native-observer-review-',dir=repo));audit.chmod(0o700);stage=audit/'candidate';stage.mkdir(mode=0o700)
    for name,data in {'publisher.py':candidate.encode(),'native_routing.py':raw(HERE/'native_routing.py'),'native_contract.py':raw(HERE/'native_contract.py')}.items():(stage/name).write_bytes(data);(stage/name).chmod(0o600)
    env=dict(PATH=os.defpath,LANG='C.UTF-8',HOME=str(audit),PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(stage),CANDIDATE_PUBLISHER=str(stage/'publisher.py'))
    r=subprocess.run([sys.executable,'-B','-m','unittest','-v','test_routing'],cwd=HERE,env=env,capture_output=True,text=True,timeout=90);save(audit/'TEST-PROCESS.json',dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));print(r.stdout+r.stderr,flush=True);need(r.returncode==0,'ROUTING_TEST_FAILED: '+str(audit))
    reader=repo/'hilega-source-reader-candidate-v3';contract=repo/'hilega-native-preparation-contract-v1';verify(reader);verify(contract);need(sha(raw(contract/'contract.py'))==sha(raw(HERE/'native_contract.py')),'REVIEWED_NATIVE_CONTRACT_CHANGED')
    sys.path.insert(0,str(stage));from native_routing import on_row,STRATEGY
    from native_contract import POLICY,VERSION
    sys.path.insert(0,str(contract))
    spec=importlib.util.spec_from_file_location('observer_review_reader',contract/'review.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
    # Validate all native event envelopes, using their own session time. This is
    # historical compatibility only, never a live quote/freshness qualification.
    from test_routing import Target
    from datetime import datetime
    counts=dict(chain_records=0,native_rows=0,validated_event_rows=0);failures=[]
    with v.reader(reader/'candidate.py')(repo/'data/live-observation/hilega-directional-v1/step-audit.jsonl') as rows:
        counts['chain_records']=len(rows)
        for row in rows:
            p=row.get('payload') or {}
            if p.get('policy_id')!=POLICY:continue
            counts['native_rows']+=1
            if not p.get('accepted_events') or p.get('reconstructed') is True:continue
            at=p.get('decision_timestamp') or p.get('cutoff_timestamp')
            try:on_row(Target(),row,current=datetime.fromisoformat(at));counts['validated_event_rows']+=1
            except Exception as e:
                if len(failures)<20:failures.append(dict(sequence=row.get('sequence'),error_type=type(e).__name__,reason=str(e) if isinstance(e,ValueError) else None))
    report=dict(status='NATIVE_OBSERVER_CANDIDATE_REVIEW_PASS' if not failures else 'NATIVE_OBSERVER_CANDIDATE_REVIEW_BLOCKED',audit=str(audit),counts=counts,failures=failures,installed_publisher_sha256=EXPECTED,candidate_files={q.name:sha(raw(q)) for q in stage.iterdir()},existing_velocity_gate_preserved=True,continuous_native_velocity_evidence_qualified=False,installed_sources_modified=False,observer_started=False,services_changed=False,production_execution_enabled=False,live_apply_available=False)
    need(sha(raw(source))==EXPECTED,'INSTALLED_SOURCE_CHANGED_DURING_REVIEW');save(audit/'RESULT.json',report);print(json.dumps(report,indent=2));need(not failures,'NATIVE_JOURNAL_COMPATIBILITY_FAILED')
if __name__=='__main__':main()
