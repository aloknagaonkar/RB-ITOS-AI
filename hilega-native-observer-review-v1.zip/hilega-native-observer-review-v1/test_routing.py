import copy,unittest
from types import SimpleNamespace
from datetime import datetime
from native_routing import on_row,STRATEGY
from native_contract import POLICY,VERSION,ENTRIES,EXITS,ContractBlocked
CURRENT=datetime.fromisoformat('2026-11-25T10:00:00+05:30')
class DB:
    def execute(self,*args):return self
    def fetchone(self):return None
class Target:
    def __init__(self):self.state={'pending':{}};self.store=SimpleNamespace(db=DB());self.exits=[]
    def request_exit(self,*args):self.exits.append(args)
def row(names=None):
    names=list(ENTRIES)[:1] if names is None else names;at='2026-11-25T09:21:00+05:30'
    return dict(sequence=1,record_hash='fixture',stage='DIRECTIONAL_DECISION',status='PROCESSED',payload=dict(strategy_id=STRATEGY,policy_id=POLICY,strategy_version=VERSION,reconstructed=False,nifty_close=24000,decision_timestamp=at,accepted_events=names,event_details=[dict(event_type=n,event_time=at,entry_time=at if n in ENTRIES else '2026-11-25T09:18:00+05:30') for n in names]))
class Tests(unittest.TestCase):
    def test_native_ce_pe_and_three_minute(self):
        for event,direction in ENTRIES.items():
            t=Target();on_row(t,row([event]),current=CURRENT);self.assertEqual(next(iter(t.state['pending'].values()))['context']['direction'],direction)
    def test_duplicate_identity(self):
        t=Target();r=row();on_row(t,r,current=CURRENT);r['sequence']=2;on_row(t,r,current=CURRENT);self.assertEqual(len(t.state['pending']),1)
    def test_wrong_policy_version_strategy_rejected(self):
        for field in ('policy_id','strategy_version','strategy_id'):
            r=row();r['payload'][field]='WRONG';t=Target()
            with self.assertRaises(ContractBlocked):on_row(t,r,current=CURRENT)
            self.assertFalse(t.state['pending']);self.assertFalse(t.exits)
    def test_legacy_ignored(self):
        r=row();r['payload'].update(strategy_id='HILEGA_V2_ALIGNMENT_DUAL_EXIT',policy_id='BULLISH_GAP2_FULL_WMA2');t=Target();on_row(t,r,current=CURRENT);self.assertFalse(t.state['pending'])
    def test_reconstructed_ignored(self):
        r=row();r['payload']['reconstructed']=True;t=Target();on_row(t,r,current=CURRENT);self.assertFalse(t.state['pending'])
    def test_previous_session_ignored(self):
        t=Target();on_row(t,row(),current=datetime.fromisoformat('2026-11-26T10:00:00+05:30'));self.assertFalse(t.state['pending'])
    def test_future_rejected(self):
        with self.assertRaises(ContractBlocked):on_row(Target(),row(),current=datetime.fromisoformat('2026-11-25T09:20:00+05:30'))
    def test_exit_then_reversal_entry(self):
        t=Target();on_row(t,row([list(ENTRIES)[1],list(EXITS)[0]]),current=CURRENT);self.assertEqual(t.exits[0][0],'BULLISH');self.assertEqual(len(t.state['pending']),1)
    def test_invalid_detail_no_mutation(self):
        r=row([list(ENTRIES)[1],list(EXITS)[0]]);r['payload']['event_details']=[];t=Target()
        with self.assertRaises(ContractBlocked):on_row(t,r,current=CURRENT)
        self.assertFalse(t.exits);self.assertFalse(t.state['pending'])
    def test_invalid_spot_no_mutation(self):
        r=row();r['payload']['nifty_close']=float('nan');t=Target()
        with self.assertRaises(ContractBlocked):on_row(t,r,current=CURRENT)
        self.assertFalse(t.state['pending'])
    def test_candidate_publisher_method_matches_adapter(self):
        import ast,os
        path=os.environ['CANDIDATE_PUBLISHER'];tree=ast.parse(open(path).read());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Publisher');method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='on_row');namespace={};exec(compile(ast.Module(body=[method],type_ignores=[]),path,'exec'),namespace)
        t=Target()
        # Wrapper passes its clock explicitly, preserving the real installed call path.
        namespace['now']=lambda:CURRENT
        namespace['on_row'](t,row());self.assertEqual(len(t.state['pending']),1)
if __name__=='__main__':unittest.main()
