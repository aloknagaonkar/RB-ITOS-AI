"""Sealed-dependency baseline/candidate validation. No installation or service actions."""
import argparse,ast,hashlib,importlib.util,json,os,shutil,subprocess,sys,tempfile,time
from pathlib import Path
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
TARGET=Path('backend/market_lab/hilega_production_simulator_bridge_v1.py')
TESTS=('test_hilega_application_preparation_v1.py','test_hilega_candle_revision_policy_v1.py','test_hilega_central_sim_allocation_v1.py','test_hilega_production_bridge_health_v1.py','test_hilega_production_simulator_bridge_v1.py')
def need(ok,reason):
    if not ok:raise ValueError(reason)
def raw(p):
    need(p.is_absolute() and p.is_file() and not any(q.is_symlink() for q in (p,*p.parents)),'REGULAR_INPUT_REQUIRED')
    return p.read_bytes()
def sha(p):return hashlib.sha256(raw(p)).hexdigest()
def save(path,v):
    with path.open('x') as f:json.dump(v,f,indent=2)
    path.chmod(0o600)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--source',type=Path);a=ap.parse_args();repo=a.repo.absolute()
    for n,h in json.loads(raw(HERE/'MANIFEST.json')).items():need(sha(HERE/n)==h,'REVIEW_PACKAGE_CHANGED')
    launcher=repo/'scripts/hilega_production_simulator_bridge.py';launcher_sha=sha(launcher)
    tree=ast.parse(raw(launcher));roots=[]
    for n in tree.body:
        if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='root' for t in n.targets) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='Path':roots.append(Path(ast.literal_eval(n.value.args[0])))
    need(len(roots)==1,'EXACT_SEALED_ROOT_REQUIRED');release=roots[0];manifest=release/'RELEASE-MANIFEST.json'
    need(sha(manifest)==release.name,'SEALED_MANIFEST_CHANGED');files=json.loads(raw(manifest))['files']
    def verify_seal():
        need(sha(manifest)==release.name and sha(launcher)==launcher_sha,'RELEASE_OR_LAUNCHER_CHANGED')
        for n,h in files.items():
            rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts,'UNSAFE_SEALED_PATH')
            need(sha(release/rel)==h,'SEALED_FILE_CHANGED: '+n)
    verify_seal();need(sha(release/TARGET)==sha(HERE/'original.py'),'INSTALLED_READER_BASE_CHANGED')
    out=Path(tempfile.mkdtemp(prefix='hilega-sealed-reader-review-',dir=repo));out.chmod(0o700)
    inputs={str(repo/'tests'/n):sha(repo/'tests'/n) for n in TESTS};results={}
    def test(root,paths,label):
        env=dict(PATH=os.defpath,LANG='C.UTF-8',HOME=str(out),PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONPATH=os.pathsep.join(str(root/n) for n in ('backend','runtime','tests')))
        junit=out/(label+'.xml')
        r=subprocess.run([str(repo/'.venv/bin/python'),'-B','-m','pytest','-q','-p','no:cacheprovider','--junitxml='+str(junit),*map(str,paths)],cwd=root,env=env,capture_output=True,text=True,timeout=600)
        detail=dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr)
        if junit.is_file():
            cases=list(ET.parse(junit).getroot().iter('testcase'))
            detail.update(tests=len(cases),failed=[c.attrib.get('classname','')+'::'+c.attrib.get('name','') for c in cases if c.find('failure') is not None or c.find('error') is not None],skipped=sum(c.find('skipped') is not None for c in cases))
        save(out/(label+'.json'),detail);print(label+':\n'+r.stdout,flush=True);return detail
    for variant in ('baseline','candidate'):
        root=out/variant;root.mkdir(mode=0o700)
        # Only manifest-listed installed Python payload; never copy the evolving repository backend.
        copied=0
        for n,h in files.items():
            rel=Path(n)
            if rel.parts[0] not in ('backend','runtime') or rel.suffix!='.py':continue
            p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw(release/rel));copied+=1
        need(copied>0 and (root/TARGET).is_file(),'SEALED_BACKEND_MISSING')
        if variant=='candidate':shutil.copyfile(HERE/'candidate.py',root/TARGET)
        tests=root/'tests';tests.mkdir()
        for n in TESTS:shutil.copyfile(repo/'tests'/n,tests/n)
        shutil.copyfile(HERE/'hilega_application_preparation_fixtures.py',tests/'hilega_application_preparation_fixtures.py')
        # Standalone synthetic test CLI, not the live sealed launcher. Tests pass --once and private temporary paths.
        (root/'scripts').mkdir();shutil.copyfile(HERE/'fixture_cli.py',root/'scripts/hilega_production_simulator_bridge.py')
        results[variant]=test(root,[tests/n for n in TESTS],variant)
    results['reader']=test(out/'candidate',[HERE/'test_reader.py'],'reader')
    scan=None
    if a.source:
        spec=importlib.util.spec_from_file_location('isolated_reader_tests',HERE/'test_reader.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        start=time.monotonic()
        with m.reader()['verified_records'](a.source.absolute()) as records:
            scan=dict(records=len(records),last_record_hash=records[-1]['record_hash'] if records else None,seconds=round(time.monotonic()-start,3),signals_processed=False)
    verify_seal()
    for name,h in inputs.items():need(sha(Path(name))==h,'TEST_SOURCE_CHANGED')
    passed=all(v['exit_code']==0 and v.get('tests',0)>0 and v.get('skipped',0)==0 for v in results.values())
    result=dict(status='SEALED_DEPENDENCY_READER_REVIEW_PASS' if passed else 'SEALED_DEPENDENCY_READER_REVIEW_BLOCKED',installed_release_sha256=release.name,stage=str(out),results={k:{f:v.get(f) for f in ('exit_code','tests','failed','skipped')} for k,v in results.items()},test_source_hashes=inputs,real_journal_scan=scan,repository_backend_used=False,installed_sources_modified=False,services_changed=False,controller_resumed=False,broker_requests_issued=False,live_apply_available=False,production_ready=False)
    save(out/'RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
    if not passed:raise SystemExit(2)
if __name__=='__main__':main()
