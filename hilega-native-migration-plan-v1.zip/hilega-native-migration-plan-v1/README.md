# Native preparation migration proposal v1

Preparation only. No apply, stop/start, daemon reload or live database writes. Reads the live application/adapter state in read-only mode, validates empty paused/closed baseline, verifies both sealed releases and passing 11-scenario v4 integration evidence, records hashes of launcher/recovery/unit/supervision inputs and verifies the real journal chain and saved cursor prefix. Stages coordinated launcher/recovery payloads and a proposal for the explicit native journal transition. No historical signals are dispatched.

The plan includes six release additions/changes: bounded bridge reader, native event adapter, Source import, exact Source hash in exclusive guard, heartbeat policy selection and dependency declarations. Frozen legacy simulator policy is not relabeled. Existing preparation entry window and all risk/evidence/authority controls remain intact.

A plan is not permission to edit the live cursor. The live cursor transition implementation, combined file/database transaction rehearsal and native recovery rehearsal remain pending and are explicitly false. Subsequent installer must quiesce all writers, reverify snapshot/state, back up both databases, persist a migration receipt atomically with the cursor, coordinate release and recovery bindings, and define rollback without automatically restoring trading databases. No production enrollment, activation or execution is available here.

Only static AST/ZIP checks have been run locally. Behavioral execution is on the VM.
