"""Stage exact native migration proposal. No live changes, service actions or live apply."""
import argparse,ast,hashlib,importlib.util,json,os,shlex,sqlite3,subprocess,sys,tempfile,time
from datetime import datetime,timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent
POLICY='RSI_TWO_ROUTE_CONFIRMED_MIDPOINT';VERSION='rsi-two-route-1.0.0-3m-native-confirmed-midpoint'
OLD='e9e092399fcf29672d5273c18ef138de645a8feec573407954d1db62392d0b59'
OLD_RECOVERY='a8b24daa87d481410b47b47539e7bab303f98f13dc5945d533c5f894ceef2da4'
UNITS=('hilega-production-source-worker.service','hilega-worker.service','hilega-api.service','hilega-lifecycle-reference.service','hilega-observation-analytics.service','hilega-observation-readiness.service')
RECOVERY='hilega-closed-pause-recovery.service'
def need(ok,reason):
    if not ok:raise ValueError(reason)
def raw(p):
    need(p.is_absolute() and p.is_file() and not any(q.is_symlink() for q in (p,*p.parents)),'REGULAR_ABSOLUTE_FILE_REQUIRED');return p.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def encoded(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def put(p,b):
    p.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    with p.open('xb') as f:f.write(b)
    p.chmod(0o600)
def verify_package(root):
    for n,h in json.loads(raw(root/'MANIFEST.json')).items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts,'UNSAFE_PATH');need(sha(raw(root/rel))==h,'PACKAGE_CHANGED')
def seal(root,h):
    data=raw(root/'RELEASE-MANIFEST.json');need(sha(data)==h,'MANIFEST_CHANGED');manifest=json.loads(data)
    for n,digest in manifest['files'].items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts,'UNSAFE_PATH');need(sha(raw(root/rel))==digest,'SEALED_FILE_CHANGED')
    need({p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}==set(manifest['files'])|{'RELEASE-MANIFEST.json'},'UNMANIFESTED_RELEASE_FILE')
    return manifest

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--integration-review',type=Path,required=True);a=ap.parse_args();repo=a.repo.resolve();review=a.integration_review.resolve();verify_package(HERE)
    result=json.loads(raw(review/'RESULT.json'));need(result['status']=='DISPOSABLE_NATIVE_SOURCE_GUARD_INTEGRATION_PASS' and len(result['scenarios'])==11 and all(r['passed'] for r in result['scenarios']),'PASSING_COMPLETE_INTEGRATION_REQUIRED')
    need(result['signed_evidence_to_unsent_plan_verified'] is True and result['exit_scope']=='REFUSED_CLOSED_WITHOUT_OWNERSHIP' and result['full_worker_startup_verified'] is True,'INTEGRATION_SCOPE_REQUIRED')
    changes=json.loads(raw(review/'CANDIDATE-CHANGES.json'));candidate=review/'candidate';candidate_digest=changes['candidate_manifest_sha256'];manifest=seal(candidate,candidate_digest)
    old=repo/'data/runtime/hilega-closed-releases'/OLD;old_manifest=seal(old,OLD)
    changed={n:dict(before=old_manifest['files'].get(n),after=h) for n,h in manifest['files'].items() if old_manifest['files'].get(n)!=h}
    need(set(old_manifest['files'])<=set(manifest['files']),'SEALED_FILE_REMOVAL_REQUIRES_REVIEW')
    expected={'backend/market_lab/hilega_production_simulator_bridge_v1.py','backend/market_lab/hilega_preparation_runtime_v1/source.py','backend/market_lab/hilega_exclusive_closed_route_v1.py','backend/market_lab/hilega_native_preparation_contract_v1.py','runtime/worker_binding.py','backend/market_lab/hilega_preparation_runtime_v1/dependencies.json'}
    need(set(changed)==expected,'UNEXPECTED_NATIVE_RELEASE_CHANGE')
    registration=json.loads(raw(candidate/'runtime/FACTORY-REGISTRATION.json'));need(registration['enabled'] is False and registration['production_execution_enabled'] is False,'DISABLED_FACTORY_REQUIRED')
    closed=json.loads(raw(candidate/'CLOSED-REGISTRATION.json'));need(closed['mode']=='CLOSED_PREPARATION_ONLY' and closed['execution_factory_configured'] is False and closed['production_execution_enabled'] is False,'CLOSED_RELEASE_REQUIRED')
    old_folder=repo/'data/runtime/hilega-closed-pause-recovery'/OLD_RECOVERY;config_bytes=raw(old_folder/'CONFIG.json');need(sha(config_bytes)==OLD_RECOVERY,'OLD_RECOVERY_CONFIG_CHANGED');config=json.loads(config_bytes)
    launcher=Path(config['worker']);old_worker=raw(launcher);need(sha(old_worker)==config['worker_sha256'] and config['bundle']==str(old) and config['release_manifest_sha256']==OLD,'OLD_LAUNCHER_RECOVERY_MISMATCH')
    need(old_worker.count(OLD.encode())==2,'EXACT_CLOSED_WRAPPER_REQUIRED');new_worker=old_worker.replace(OLD.encode(),candidate_digest.encode());ast.parse(new_worker)
    destination=old.parent/candidate_digest;need(not destination.exists(),'NEW_RELEASE_DESTINATION_REQUIRED')
    config.update(bundle=str(destination),release_manifest_sha256=candidate_digest,worker_sha256=sha(new_worker));new_config=encoded(config);new_recovery=old_folder.parent/sha(new_config);need(not new_recovery.exists(),'NEW_RECOVERY_DESTINATION_REQUIRED')
    unit=Path.home()/'.config/systemd/user'/RECOVERY;old_unit=raw(unit);need(old_unit.count(OLD_RECOVERY.encode())==3,'EXACT_RECOVERY_UNIT_REQUIRED');new_unit=old_unit.replace(OLD_RECOVERY.encode(),new_recovery.name.encode())
    tool=repo/'hilega-group1-rollout-v1';verify_package(tool);s=importlib.util.spec_from_file_location('native_plan_primitives',tool/'maintenance_primitives.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
    warmup=repo/'hilega-warmup-install-plan-6d56keoy/PLAN.json';need(sha(raw(warmup))=='25a6a37a1600b1a0cebb5026abd356712e9d764b048a4ae757a5c5c475d1f3f9','OLD_PLAN_CHANGED');previous=json.loads(raw(warmup));app=Path(config['application_db']);adapter=Path(previous['adapter_db']);need(str(app)==previous['application_db'],'APPLICATION_SCOPE_CHANGED');m.require_empty_closed_baseline(app,adapter)
    with sqlite3.connect(app.as_uri()+'?mode=ro',uri=True) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
        control=json.loads(db.execute('SELECT data FROM control WHERE id=1').fetchone()[0]);cursor=json.loads(db.execute('SELECT data FROM preparation_source WHERE id=1').fetchone()[0]);tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        need(control['production_execution_enabled'] is False and control['simulation_only'] is True,'CLOSED_CONTROLLER_REQUIRED')
        need('native_source_transition_rehearsal' not in tables,'REHEARSAL_TABLE_IN_LIVE_DATABASE')
    states={};bindings={str(launcher):sha(old_worker),str(unit):sha(old_unit),str(old_folder/'CONFIG.json'):sha(config_bytes),str(old_folder/'live_recovery.py'):sha(raw(old_folder/'live_recovery.py')),str(warmup):sha(raw(warmup)),str(review/'RESULT.json'):sha(raw(review/'RESULT.json')),str(review/'CANDIDATE-CHANGES.json'):sha(raw(review/'CANDIDATE-CHANGES.json'))}
    for name in (*UNITS,RECOVERY,'hilega-quote-observer.service'):
        run=subprocess.run(['systemctl','--user','--no-pager','--full','show',name,'--property=ActiveState,SubState,MainPID,FragmentPath,DropInPaths,ExecStart'],capture_output=True,text=True,timeout=15,check=True);state=dict(line.split('=',1) for line in run.stdout.splitlines() if '=' in line);states[name]=state
        for p in ([state['FragmentPath']] if state.get('FragmentPath') else [])+shlex.split(state.get('DropInPaths','')):bindings[p]=sha(raw(Path(p)))
    need(states[UNITS[0]]['ActiveState'] in {'inactive','failed'} and int(states[UNITS[0]]['MainPID'])==0,'SOURCE_MUST_BE_STOPPED')
    need(all(states[n]['ActiveState']=='active' and int(states[n]['MainPID'])>0 for n in UNITS[1:]),'COMPANION_STATE_CHANGED')
    need(states[RECOVERY]['ActiveState']=='active' and not states[RECOVERY].get('DropInPaths'),'RECOVERY_STATE_CHANGED');need(int(states['hilega-quote-observer.service']['MainPID'])==0,'QUOTE_OBSERVER_MUST_BE_STOPPED')
    # Bind supervision by hashes only; never print credentials or environment values.
    supervision=Path.home()/'hilega-persistent-supervision-stage-v1'
    for n in ('runner.py','config-private.json','MIGRATION_APPROVED.json'):bindings[str(supervision/n)]=sha(raw(supervision/n))
    reader_package=repo/'hilega-source-reader-candidate-v3';contract_package=repo/'hilega-native-preparation-contract-v1'
    for package in (reader_package,contract_package):verify_package(package)
    sys.path.insert(0,str(contract_package));s=importlib.util.spec_from_file_location('plan_reader',contract_package/'review.py');loader=importlib.util.module_from_spec(s);s.loader.exec_module(loader)
    journal=repo/'data/live-observation/hilega-directional-v1/step-audit.jsonl';need(cursor['path']==str(journal),'CURSOR_PATH_MISMATCH')
    with loader.reader(reader_package/'candidate.py')(journal) as rows:
        need(type(cursor['sequence']) is int and 0<=cursor['sequence']<=len(rows),'CURSOR_OUTSIDE_SNAPSHOT')
        need(not cursor['sequence'] or rows[cursor['sequence']-1]['record_hash']==cursor['hash'],'CURSOR_PREFIX_MISMATCH')
        tail=dict(path=str(journal),sequence=len(rows),hash=rows[-1]['record_hash'] if rows else None)
    output=Path(tempfile.mkdtemp(prefix='hilega-native-migration-plan-',dir=repo));output.chmod(0o700)
    for n,b in {'worker.py':new_worker,'CONFIG.json':new_config,'live_recovery.py':raw(old_folder/'live_recovery.py'),'recovery.service':new_unit}.items():put(output/'payload'/n,b)
    proposal=dict(model='HILEGA_NATIVE_PREPARATION_MIGRATION_PROPOSAL_V1',status='EXACT_PROPOSAL_STAGED_NOT_APPLIED',created_at=datetime.now(timezone.utc).isoformat(),repo=str(repo),candidate=str(candidate),candidate_release_sha256=candidate_digest,destination=str(destination),old_release=str(old),old_release_sha256=OLD,changed_release_files=changed,application_db=str(app),adapter_db=str(adapter),controller_version=control['version'],session_date=control['session_date'],old_cursor=cursor,proposed_baseline=tail,historical_records_to_baseline=tail['sequence']-cursor['sequence'],policy_id=POLICY,strategy_version=VERSION,worker=str(launcher),old_worker_sha256=sha(old_worker),new_worker_sha256=sha(new_worker),recovery_unit=str(unit),old_recovery_unit_sha256=sha(old_unit),new_recovery_unit_sha256=sha(new_unit),old_recovery_folder=str(old_folder),new_recovery_folder=str(new_recovery),bindings=bindings,unit_state=states,payload_hashes={p.name:sha(raw(p)) for p in sorted((output/'payload').iterdir())},entry_window_preserved='09:15 <= entry time < 14:55 IST',live_cursor_transition_implemented=False,combined_file_database_transaction_rehearsed=False,native_recovery_rehearsed=False,managed_service_health_verified=False,live_apply_available=False,services_changed=False,live_cursor_modified=False,production_execution_enabled=False)
    put(output/'PLAN.json',encoded(proposal));print(json.dumps(dict(status=proposal['status'],plan=str(output/'PLAN.json'),plan_sha256=sha(raw(output/'PLAN.json')),candidate_release_sha256=candidate_digest,changed_release_files=sorted(changed),controller_version=control['version'],old_sequence=cursor['sequence'],proposed_baseline_sequence=tail['sequence'],historical_records_to_baseline=proposal['historical_records_to_baseline'],live_apply_available=False,production_execution_enabled=False),indent=2))
if __name__=='__main__':main()
