# Native RSI preparation contract candidate

Review-only artifact. Never install this module into the live runtime directly.

Validates native RSI identity, exact supported entry/exit names, reconstructed-record exclusion, completed 3-minute regular-session envelope, event details, exit-first reversal and deterministic event identities. The adapter does not authorize entries. The existing preparation 14:55 entry cutoff must remain enforced separately. Special-session compatibility, source clock freshness, ownership, funds, admission, cursor transition and sealed integration are NOT qualified here.

review.py runs 16 synthetic unit tests on the VM, then uses the previously reviewed bounded reader to verify the entire journal hash chain and check native policy event records. No database access, broker requests, service commands or cursor updates. Historical acceptance is counted for schema validation only, never submitted to any worker. Other policy IDs remain counted by the reader's chain scan but are not interpreted by this candidate; migration handling remains pending. A pass does not certify safety of skipping history or authorize installation.

No behavioral tests were run locally. Only AST syntax and ZIP structure were checked before delivery.
