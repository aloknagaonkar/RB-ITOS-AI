import copy
import unittest
from contract import accepted,ContractBlocked,POLICY,VERSION,ENTRIES,EXITS
BULL,BEAR=ENTRIES
BX,SX=EXITS
def row(names=None,stamp='2026-11-25T09:18:00+05:30'):
    names=[BULL] if names is None else names
    return dict(sequence=1,record_hash='synthetic',stage='DIRECTIONAL_DECISION',status='PROCESSED',payload=dict(policy_id=POLICY,strategy_version=VERSION,reconstructed=False,decision_timestamp=stamp,accepted_events=names,event_details=[dict(event_type=n,event_time=stamp,entry_time=stamp if n in ENTRIES else '2026-11-25T09:18:00+05:30') for n in names]))
class ContractTests(unittest.TestCase):
    def reject(self,r,reason):
        with self.assertRaisesRegex(ContractBlocked,'^'+reason+'$'):accepted(r)
    def test_ce_and_pe_entries(self):
        self.assertEqual([accepted(row([n]))[0]['direction'] for n in ENTRIES],['BULLISH','BEARISH'])
    def test_three_minute_boundary_not_five_minute(self):
        self.assertEqual(len(accepted(row(stamp='2026-11-25T09:21:00+05:30'))),1)
        self.reject(row(stamp='2026-11-25T09:20:00+05:30'),'COMPLETED_THREE_MINUTE_BOUNDARY_REQUIRED')
    def test_version_and_policy_rejected(self):
        for key in ('policy_id','strategy_version'):
            r=row();r['payload'][key]='OLD';self.reject(r,'SOURCE_POLICY_OR_VERSION_MISMATCH')
    def test_reconstructed_never_entry(self):
        r=row();r['payload']['reconstructed']=True;self.assertEqual(accepted(r),[])
        del r['payload']['reconstructed'];self.reject(r,'SOURCE_RECONSTRUCTION_FLAG_REQUIRED')
    def test_duplicate_rejected(self):self.reject(row([BULL,BULL]),'DUPLICATE_EVENT_IN_BOUNDARY')
    def test_unknown_event_rejected(self):self.reject(row(['UNREVIEWED_EVENT']),'UNKNOWN_ACCEPTED_EVENT')
    def test_reversal_exit_first(self):self.assertEqual([r['role'] for r in accepted(row([BEAR,BX]))],['EXIT','ENTRY'])
    def test_same_direction_reentry_rejected(self):self.reject(row([BULL,BX]),'SAME_DIRECTION_EXIT_ENTRY_NOT_SUPPORTED')
    def test_cutoff_exit_only(self):
        r=row([BX],'2026-11-25T15:30:00+05:30');r['stage']='DIRECTIONAL_SESSION_CUTOFF';self.assertEqual(accepted(r)[0]['role'],'EXIT')
        r=row([BULL],'2026-11-25T15:30:00+05:30');r['stage']='DIRECTIONAL_SESSION_CUTOFF';self.reject(r,'CUTOFF_CANNOT_OPEN_ENTRY')
    def test_event_detail_mismatch(self):
        r=row();r['payload']['event_details'][0]['event_time']='2026-11-25T09:21:00+05:30';self.reject(r,'EVENT_DETAIL_TIME_OR_IDENTITY_MISMATCH')
    def test_no_details_rejected(self):
        r=row();r['payload']['event_details']=[];self.reject(r,'EVENT_DETAIL_TIME_OR_IDENTITY_MISMATCH')
    def test_naive_timestamp_rejected(self):self.reject(row(stamp='2026-11-25T09:18:00'),'AWARE_SOURCE_TIMESTAMP_REQUIRED')
    def test_identity_stable_on_repeated_observation(self):
        a=row();b=copy.deepcopy(a);b.update(sequence=2,record_hash='different');self.assertEqual(accepted(a)[0]['id'],accepted(b)[0]['id'])
    def test_exit_retains_entry_reference(self):self.assertEqual(accepted(row([BX],'2026-11-25T09:24:00+05:30'))[0]['entry_reference_at'],'2026-11-25T09:18:00+05:30')
    def test_nonprocessed_and_observation_ignored(self):
        r=row();r['status']='BLOCKED';self.assertEqual(accepted(r),[])
        r=row();r['stage']='COMBINED_PRICE_OBSERVATION';self.assertEqual(accepted(r),[])
    def test_prior_entry_window_not_relaxed_by_adapter(self):
        # This adapter describes signals; the preparation layer must retain its own 14:55 entry gate.
        self.assertEqual(accepted(row(stamp='2026-11-25T15:00:00+05:30'))[0]['role'],'ENTRY')
if __name__=='__main__':unittest.main()
