"""Candidate contract tests and locked real-journal read-only compatibility scan."""
import argparse,ast,hashlib,json,os,subprocess,sys,tempfile,time
from pathlib import Path
from contract import accepted,ContractBlocked,POLICY,VERSION
HERE=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()
def raw(p):
    if any(q.is_symlink() for q in (p,*p.parents)):raise ValueError('SYMLINK_REJECTED')
    return p.read_bytes()
def reader(path):
    import fcntl,operator,struct
    from collections.abc import Sequence
    names={'_SourceRecordSlice','_VerifiedSourceRecords','verified_records'}
    tree=ast.parse(raw(path));nodes=[n for n in tree.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in names or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id.startswith('SOURCE_') for t in n.targets)]
    scope=dict(Path=Path,hashlib=hashlib,json=json,fcntl=fcntl,os=os,operator=operator,struct=struct,tempfile=tempfile,Sequence=Sequence,Blocked=ContractBlocked)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),scope);return scope['verified_records']
def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);a=p.parse_args();repo=a.repo.resolve()
    for n,h in json.loads(raw(HERE/'MANIFEST.json')).items():
        rel=Path(n)
        if rel.is_absolute() or '..' in rel.parts or sha(raw(HERE/rel))!=h:raise ValueError('REVIEW_PACKAGE_CHANGED')
    reader_package=repo/'hilega-source-reader-candidate-v3'
    for n,h in json.loads(raw(reader_package/'MANIFEST.json')).items():
        rel=Path(n)
        if rel.is_absolute() or '..' in rel.parts or sha(raw(reader_package/rel))!=h:raise ValueError('READER_PACKAGE_CHANGED')
    audit=Path(tempfile.mkdtemp(prefix='hilega-native-contract-review-',dir=repo));audit.chmod(0o700)
    env=dict(PATH=os.defpath,LANG='C.UTF-8',HOME=str(audit),PYTHONDONTWRITEBYTECODE='1')
    test=subprocess.run([sys.executable,'-B','-m','unittest','-v','test_contract'],cwd=HERE,env=env,capture_output=True,text=True,timeout=60)
    (audit/'TEST-PROCESS.json').write_text(json.dumps(dict(exit_code=test.returncode,stdout=test.stdout,stderr=test.stderr),indent=2));print(test.stdout+test.stderr,flush=True)
    if test.returncode:raise ValueError('CONTRACT_TEST_FAILED: '+str(audit))
    path=repo/'data/live-observation/hilega-directional-v1/step-audit.jsonl'
    counts=dict(native_records=0,reconstructed_records=0,entry_events=0,exit_events=0);failures=[];start=time.monotonic()
    with reader(reader_package/'candidate.py')(path) as rows:
        total=len(rows);last=rows[-1]['record_hash'] if rows else None
        for row in rows:
            payload=row.get('payload')
            if not isinstance(payload,dict) or payload.get('policy_id')!=POLICY:continue
            counts['native_records']+=1
            if payload.get('reconstructed') is True:counts['reconstructed_records']+=1
            try:
                if payload.get('strategy_version')!=VERSION:raise ContractBlocked('SOURCE_POLICY_OR_VERSION_MISMATCH')
                for event in accepted(row):counts['entry_events' if event['role']=='ENTRY' else 'exit_events']+=1
            except ContractBlocked as e:
                if len(failures)<30:failures.append(dict(sequence=row.get('sequence'),reason=str(e)))
    passed=counts['native_records']>0 and not failures
    result=dict(status='NATIVE_CONTRACT_READ_ONLY_REVIEW_PASS' if passed else 'NATIVE_CONTRACT_READ_ONLY_REVIEW_BLOCKED',audit=str(audit),policy_id=POLICY,strategy_version=VERSION,chain_records_verified=total,last_record_hash=last,counts=counts,failures=failures,elapsed_seconds=round(time.monotonic()-start,3),reader_sha256=sha(raw(reader_package/'candidate.py')),contract_sha256=sha(raw(HERE/'contract.py')),installed_sources_modified=False,database_access_performed=False,services_changed=False,signals_executed=False,cursor_transition_verified=False,preparation_integration_verified=False,live_apply_available=False,production_execution_enabled=False)
    (audit/'RESULT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
    if not passed:raise SystemExit(2)
if __name__=='__main__':main()
