# Native observer transition proposal

Read-only live inputs; creates only new private proposal files. Does not install code, change services, open credentials, call broker APIs or modify live observer/application databases or cursors.

Requires exact reviewed V2 candidate, stopped supervisor/collector, no pending entries/deliveries or open observer rows. Every stored exit request must point to an existing CLOSED observer row, otherwise preparation blocks for review. Existing observer DB contents are bound by logical row digest; no historical DB rows are deleted. Complete old publisher state and all exit requests are copied into the private proposal. Proposed state clears active exit requests and old close cache, advances ONLY observer offset/hash/sequence to verified journal tail and prevents backlog dispatch by starting after that boundary. Other state keys remain. No preparation-worker cursor reset.

Eight disposable tests cover preservation, tail fields, outstanding-work refusal, orphan exit refusal, sequence/offset regression and idempotent proposal. Live source journal chain and original saved byte/hash boundary are verified. Proposed code/state install with locks, backups, rollback and publisher restart validation remains a separate transaction, not supplied by this planning tool. History baselining is not live qualification; fresh minute and quote evidence must accumulate after restoration. All production gates remain disabled.

Local validation: Python AST and ZIP structure only; behavioral tests run on VM.
