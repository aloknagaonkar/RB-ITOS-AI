import copy,unittest
from transition import propose
class Tests(unittest.TestCase):
    def setUp(self):
        self.s=dict(sequence=3,offset=30,previous_hash='old',source_identity=[1,2],pending={},deliveries={},closes={'old':1},exits={'old-id':{'reason':'OLD_EXIT'}},other={'retained':True})
        self.kw=dict(sequence=5,previous_hash='new',offset=50,identity=[1,2],closed_exit_ids={'old-id'})
    def test_history_archived_without_mutating_input(self):
        before=copy.deepcopy(self.s);p,a=propose(self.s,**self.kw);self.assertEqual(self.s,before);self.assertEqual(a,before['exits']);self.assertEqual(p['exits'],{});self.assertEqual(p['closes'],{});self.assertEqual(p['other'],before['other'])
    def test_verified_tail_fields_preserved(self):
        p,_=propose(self.s,**self.kw);self.assertEqual((p['sequence'],p['offset'],p['previous_hash'],p['source_identity']),(5,50,'new',[1,2]))
    def test_pending_rejected(self):
        self.s['pending']['entry']={}
        with self.assertRaisesRegex(ValueError,'OUTSTANDING'):propose(self.s,**self.kw)
    def test_delivery_rejected(self):
        self.s['deliveries']['delivery']={}
        with self.assertRaisesRegex(ValueError,'OUTSTANDING'):propose(self.s,**self.kw)
    def test_orphan_exit_rejected(self):
        self.kw['closed_exit_ids']=set()
        with self.assertRaisesRegex(ValueError,'EXIT_WITHOUT'):propose(self.s,**self.kw)
    def test_sequence_regression_rejected(self):
        self.kw['sequence']=2
        with self.assertRaisesRegex(ValueError,'OBSERVER_CURSOR'):propose(self.s,**self.kw)
    def test_offset_regression_rejected(self):
        self.kw['offset']=29
        with self.assertRaisesRegex(ValueError,'OBSERVER_OFFSET'):propose(self.s,**self.kw)
    def test_idempotent_proposal(self):
        p,_=propose(self.s,**self.kw);again,archive=propose(p,**self.kw);self.assertEqual(p,again);self.assertEqual(archive,{})
if __name__=='__main__':unittest.main()
