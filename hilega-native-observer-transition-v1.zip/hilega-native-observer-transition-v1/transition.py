"""Pure observer-state proposal. No file, broker or database operations."""
import copy

def need(ok,reason):
    if not ok:raise ValueError(reason)

def propose(state,*,sequence,previous_hash,offset,identity,closed_exit_ids):
    need(type(state) is dict,'STATE_OBJECT_REQUIRED')
    for key in ('pending','deliveries','exits','closes'):
        need(type(state.get(key,{})) is dict,'STATE_MAPPING_REQUIRED')
    need(not state.get('pending') and not state.get('deliveries'),'OUTSTANDING_OBSERVER_WORK_REQUIRES_REVIEW')
    need(type(state.get('sequence')) is int and type(sequence) is int and 0<=state['sequence']<=sequence,'OBSERVER_CURSOR_REGRESSION')
    need(type(offset) is int and offset>=state.get('offset',0),'OBSERVER_OFFSET_REGRESSION')
    need(set(state.get('exits',{}))<=set(closed_exit_ids),'EXIT_WITHOUT_CLOSED_OBSERVATION')
    proposed=copy.deepcopy(state)
    proposed.update(sequence=sequence,previous_hash=previous_hash,offset=offset,source_identity=list(identity),pending={},deliveries={},exits={},closes={})
    return proposed,copy.deepcopy(state.get('exits',{}))
