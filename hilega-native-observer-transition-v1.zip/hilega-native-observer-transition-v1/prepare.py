"""Stage exact observer files/state proposal; live inputs read-only; no service actions."""
import argparse,fcntl,hashlib,importlib.util,json,os,sqlite3,subprocess,sys,tempfile,time
from pathlib import Path
from transition import propose,need
HERE=Path(__file__).resolve().parent
PUBLISHER='a442b9bd390df162e4179275e97ccaa9ff5c02b373e5703978cc744146cc0053'
CANDIDATE={'publisher.py':'138064f0f94d79293f641a878e0a7dbd0e1542516de6d0cd2d1e9ec549992a33','native_routing.py':'e2882698610147ea9a2bdc6c9bbdc5395650e91dd65cc5c7ed3c1c9b81d2a429','native_contract.py':'b7524253194042a5cdc142343414f75c04cc6cbe01a12539671a5ec97f4f9c3b'}
def raw(p):
    need(p.is_absolute() and not any(q.is_symlink() for q in (p,*p.parents)),'REGULAR_ABSOLUTE_PATH_REQUIRED');return p.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def encoded(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def put(p,b):
    p.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    with p.open('xb') as f:f.write(b)
    p.chmod(0o600)
def verify(folder):
    for n,h in json.loads(raw(folder/'MANIFEST.json')).items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts and sha(raw(folder/rel))==h,'PACKAGE_CHANGED')
def stopped(repo):
    targets={str(repo/'scripts/hilega_policy_observer_service.py').encode(),str(repo/'hilega_policy_live/publisher.py').encode()}
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name)==os.getpid():continue
        try:
            if p.stat().st_uid==os.getuid():need(not targets.intersection((p/'cmdline').read_bytes().split(b'\0')),'POLICY_OBSERVER_MUST_BE_STOPPED')
        except (FileNotFoundError,ProcessLookupError):pass

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);a=ap.parse_args();repo=a.repo.resolve();verify(HERE)
    review=repo/'hilega-native-observer-review-afpyvd77';proof=json.loads(raw(review/'RESULT.json'))
    need(proof['status']=='NATIVE_OBSERVER_CANDIDATE_REVIEW_PASS' and proof['historical_minute_coverage_complete'] is True and proof['failures']==[] and proof['candidate_files']==CANDIDATE,'EXACT_V2_REVIEW_REQUIRED')
    installed=repo/'hilega_policy_live';need(sha(raw(installed/'publisher.py'))==PUBLISHER,'INSTALLED_PUBLISHER_CHANGED')
    for n,h in CANDIDATE.items():
        need(sha(raw(review/'candidate'/n))==h,'REVIEWED_CANDIDATE_CHANGED')
        if n!='publisher.py':need(not (installed/n).exists(),'EXISTING_ROUTING_MODULE_REQUIRES_REVIEW')
    stopped(repo);data=repo/'data/live-observation/hilega-strike-observation-v1';state_path=data/'publisher-state.json';state_bytes=raw(state_path);state=json.loads(state_bytes)
    need(not state.get('pending') and not state.get('deliveries'),'OUTSTANDING_OBSERVER_WORK_REQUIRES_REVIEW')
    db_path=data/'observer.sqlite3';need(db_path.is_file() and not any(q.is_symlink() for q in (db_path,*db_path.parents)),'REGULAR_OBSERVER_DATABASE_REQUIRED')
    with sqlite3.connect(db_path.as_uri()+'?mode=ro',uri=True) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN');need(db.execute('SELECT COUNT(*) FROM state WHERE is_open!=0').fetchone()[0]==0,'OPEN_OBSERVATIONS_REQUIRE_REVIEW')
        ids=set(state.get('exits',{}));closed=set()
        for key in ids:
            row=db.execute('SELECT is_open FROM state WHERE id=?',(key,)).fetchone()
            if row and row[0]==0:closed.add(key)
        # Bind all existing observer tables, including outbox/cursors, without printing records.
        snapshot={name:db.execute('SELECT * FROM '+name+' ORDER BY '+order).fetchall() for name,order in (('seen','id'),('state','id'),('outbox','seq'),('cursor','key'))}
        db_digest=sha(encoded(snapshot));db.rollback()
    contract=repo/'hilega-native-preparation-contract-v1';reader=repo/'hilega-source-reader-candidate-v3';verify(contract);verify(reader);sys.path.insert(0,str(contract));s=importlib.util.spec_from_file_location('transition_reader',contract/'review.py');module=importlib.util.module_from_spec(s);s.loader.exec_module(module)
    journal=repo/'data/live-observation/hilega-directional-v1/step-audit.jsonl';raw_path=journal.absolute();need(not any(p.is_symlink() for p in (raw_path,*raw_path.parents)),'JOURNAL_SYMLINK')
    with journal.open('rb') as stream:
        fcntl.flock(stream,fcntl.LOCK_SH)
        start=os.fstat(stream.fileno());need(state.get('source_identity') in (None,[start.st_dev,start.st_ino]),'SOURCE_IDENTITY_CHANGED')
        with module.reader(reader/'candidate.py')(journal) as rows:
            sequence=len(rows);tail=rows[-1]['record_hash'] if rows else None;saved=state['sequence']
            need(type(saved) is int and 0<=saved<=sequence,'SAVED_SEQUENCE_INVALID')
            need((rows[saved-1]['record_hash'] if saved else None)==state.get('previous_hash'),'SAVED_PREFIX_CHANGED')
        # Verify saved byte position belongs to the same chain boundary.
        offset=0
        for i in range(sequence):
            line=stream.readline(8*1024*1024+1);need(line.endswith(b'\n'),'SOURCE_INCOMPLETE');offset+=len(line)
            if i+1==saved:need(offset==state['offset'],'SAVED_OFFSET_MISMATCH')
        if saved==0:need(state.get('offset',0)==0,'SAVED_OFFSET_MISMATCH')
        end=os.fstat(stream.fileno());need((start.st_dev,start.st_ino,start.st_size,start.st_mtime_ns)==(end.st_dev,end.st_ino,end.st_size,end.st_mtime_ns) and offset==start.st_size,'SOURCE_CHANGED_DURING_REVIEW')
        next_state,exits=propose(state,sequence=sequence,previous_hash=tail,offset=offset,identity=[start.st_dev,start.st_ino],closed_exit_ids=closed)
    need(sha(raw(state_path))==sha(state_bytes),'OBSERVER_STATE_CHANGED');stopped(repo)
    audit=Path(tempfile.mkdtemp(prefix='hilega-native-observer-transition-plan-',dir=repo));audit.chmod(0o700)
    env=dict(PATH=os.defpath,LANG='C.UTF-8',HOME=str(audit),PYTHONDONTWRITEBYTECODE='1')
    r=subprocess.run([sys.executable,'-B','-m','unittest','-v','test_transition'],cwd=HERE,env=env,capture_output=True,text=True,timeout=60);put(audit/'TEST-PROCESS.json',encoded(dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr)));print(r.stdout+r.stderr,flush=True);need(r.returncode==0,'TRANSITION_TEST_FAILED')
    put(audit/'original-state.json',state_bytes);put(audit/'archived-exit-requests.json',encoded(exits));put(audit/'payload/publisher-state.json',encoded(next_state))
    for n in CANDIDATE:put(audit/'payload'/n,raw(review/'candidate'/n))
    bindings={str(installed/n):sha(raw(installed/n)) for n in ('publisher.py','observer.py','active_marks.py','config.json')}
    bindings[str(repo/'scripts/hilega_policy_observer_service.py')]=sha(raw(repo/'scripts/hilega_policy_observer_service.py'))
    plan=dict(status='OBSERVER_TRANSITION_STAGED_NOT_APPLIED',model='HILEGA_NATIVE_OBSERVER_TRANSITION_PROPOSAL_V1',repo=str(repo),created_at=time.time(),review=str(review/'RESULT.json'),review_sha256=sha(raw(review/'RESULT.json')),bindings=bindings,state_path=str(state_path),state_sha256=sha(state_bytes),observer_db=str(db_path),observer_database_rows_sha256=db_digest,old_sequence=saved,baseline_sequence=sequence,baseline_previous_hash=tail,baseline_offset=offset,source_identity=[start.st_dev,start.st_ino],journal=str(journal),exit_requests_archived=len(exits),closed_observer_rows_verified=True,archived_exits_sha256=sha(encoded(exits)),payload_hashes={p.name:sha(raw(p)) for p in (audit/'payload').iterdir()},historical_dispatch_permitted=False,application_cursor_modified=False,observer_state_modified=False,services_changed=False,live_apply_available=False,production_execution_enabled=False)
    put(audit/'PLAN.json',encoded(plan));print(json.dumps(dict(status=plan['status'],plan=str(audit/'PLAN.json'),plan_sha256=sha(raw(audit/'PLAN.json')),old_observer_sequence=saved,proposed_observer_baseline_sequence=sequence,exit_requests_archived=len(exits),transition_tests=8,observer_state_modified=False,application_cursor_modified=False,services_changed=False,production_execution_enabled=False,live_apply_available=False),indent=2))
if __name__=='__main__':
    try:main()
    except Exception as e:
        print(json.dumps(dict(status='OBSERVER_TRANSITION_PREPARATION_BLOCKED',reason=str(e) if type(e) is ValueError else type(e).__name__,production_execution_enabled=False)));raise SystemExit(2)
