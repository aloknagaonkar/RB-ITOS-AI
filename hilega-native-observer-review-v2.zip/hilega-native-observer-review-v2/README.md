# Native observer price-routing review v2

Read-only live inputs, staged candidate only. No installation, services, broker calls or live observer state mutation. Carries v1 native entry/exit contract unchanged. Adds independent completed-minute price-observation schema: exact native strategy/policy/version, PROCESSED status, no accepted events, no reconstructed input, aware minute timestamps, decision/event availability exactly checkpoint plus one minute, finite positive price, current session, no future data. Missing reconstructed is permitted only for price observations based on the inspected producer's non-recovered branch. Decisions retain explicit reconstructed=False and 3-minute boundaries. Price conflicts block, no interpolation or timestamp shifts.

Runs twenty disposable routing checks and chronological real-journal replay into in-memory fake observer state. Coverage uses only prices available earlier in that replay, preserving exact-minute lookback. Historical complete coverage is not live stream qualification or proof the velocity threshold passes. Existing observer state remains untouched; 14 exit requests need explicit transition before restart. Existing publisher policy, selector, threshold and quote gates remain unchanged. No production enrollment or activation.

Local verification limited to AST and ZIP structure. Behavioral checks run only on VM.
