import copy,unittest
from types import SimpleNamespace
from datetime import datetime
from native_routing import on_row,STRATEGY
from native_contract import POLICY,VERSION,ENTRIES,EXITS,ContractBlocked
CURRENT=datetime.fromisoformat('2026-11-25T10:00:00+05:30')
class DB:
    def execute(self,*args):return self
    def fetchone(self):return None
class Target:
    def __init__(self):self.state={'pending':{},'closes':{}};self.store=SimpleNamespace(db=DB());self.exits=[]
    def request_exit(self,*args):self.exits.append(args)
def row(names=None):
    names=list(ENTRIES)[:1] if names is None else names;at='2026-11-25T09:21:00+05:30'
    return dict(sequence=1,record_hash='fixture',stage='DIRECTIONAL_DECISION',status='PROCESSED',payload=dict(strategy_id=STRATEGY,policy_id=POLICY,strategy_version=VERSION,reconstructed=False,nifty_close=24000,decision_timestamp=at,accepted_events=names,event_details=[dict(event_type=n,event_time=at,entry_time=at if n in ENTRIES else '2026-11-25T09:18:00+05:30') for n in names]))
class Tests(unittest.TestCase):
    def test_native_ce_pe_and_three_minute(self):
        for event,direction in ENTRIES.items():
            t=Target();on_row(t,row([event]),current=CURRENT);self.assertEqual(next(iter(t.state['pending'].values()))['context']['direction'],direction)
    def test_duplicate_identity(self):
        t=Target();r=row();on_row(t,r,current=CURRENT);r['sequence']=2;on_row(t,r,current=CURRENT);self.assertEqual(len(t.state['pending']),1)
    def test_wrong_policy_version_strategy_rejected(self):
        for field in ('policy_id','strategy_version','strategy_id'):
            r=row();r['payload'][field]='WRONG';t=Target()
            with self.assertRaises(ContractBlocked):on_row(t,r,current=CURRENT)
            self.assertFalse(t.state['pending']);self.assertFalse(t.exits)
    def test_legacy_ignored(self):
        r=row();r['payload'].update(strategy_id='HILEGA_V2_ALIGNMENT_DUAL_EXIT',policy_id='BULLISH_GAP2_FULL_WMA2');t=Target();on_row(t,r,current=CURRENT);self.assertFalse(t.state['pending'])
    def test_reconstructed_ignored(self):
        r=row();r['payload']['reconstructed']=True;t=Target();on_row(t,r,current=CURRENT);self.assertFalse(t.state['pending'])
    def test_previous_session_ignored(self):
        t=Target();on_row(t,row(),current=datetime.fromisoformat('2026-11-26T10:00:00+05:30'));self.assertFalse(t.state['pending'])
    def test_future_rejected(self):
        with self.assertRaises(ContractBlocked):on_row(Target(),row(),current=datetime.fromisoformat('2026-11-25T09:20:00+05:30'))
    def test_exit_then_reversal_entry(self):
        t=Target();on_row(t,row([list(ENTRIES)[1],list(EXITS)[0]]),current=CURRENT);self.assertEqual(t.exits[0][0],'BULLISH');self.assertEqual(len(t.state['pending']),1)
    def test_invalid_detail_no_mutation(self):
        r=row([list(ENTRIES)[1],list(EXITS)[0]]);r['payload']['event_details']=[];t=Target()
        with self.assertRaises(ContractBlocked):on_row(t,r,current=CURRENT)
        self.assertFalse(t.exits);self.assertFalse(t.state['pending'])
    def test_invalid_spot_no_mutation(self):
        r=row();r['payload']['nifty_close']=float('nan');t=Target()
        with self.assertRaises(ContractBlocked):on_row(t,r,current=CURRENT)
        self.assertFalse(t.state['pending'])
    def test_candidate_publisher_method_matches_adapter(self):
        import ast,os
        path=os.environ['CANDIDATE_PUBLISHER'];tree=ast.parse(open(path).read());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Publisher');method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='on_row');namespace={};exec(compile(ast.Module(body=[method],type_ignores=[]),path,'exec'),namespace)
        t=Target()
        # Wrapper passes its clock explicitly, preserving the real installed call path.
        namespace['now']=lambda:CURRENT
        namespace['on_row'](t,row());self.assertEqual(len(t.state['pending']),1)
def price():
    r=row([]);r['stage']='COMBINED_PRICE_OBSERVATION';r['checkpoint']='2026-11-25T09:19:00+05:30';r['event_time']='2026-11-25T09:20:00+05:30';r['payload']['decision_timestamp']=r['event_time'];r['payload'].pop('reconstructed');r['payload']['event_details']=[];return r
class PriceTests(unittest.TestCase):
    def test_missing_reconstruction_flag_valid_price(self):
        t=Target();on_row(t,price(),current=CURRENT);self.assertEqual(len(t.state['closes']),1);self.assertFalse(t.state['pending'])
    def test_signal_free_decision_supplies_boundary_close(self):
        t=Target();on_row(t,row([]),current=CURRENT);self.assertEqual(len(t.state['closes']),1)
    def test_exact_velocity_pair(self):
        from datetime import timedelta,timezone
        t=Target();on_row(t,price(),current=CURRENT);on_row(t,row(),current=CURRENT);at=datetime.fromisoformat(row()['payload']['decision_timestamp']).astimezone(timezone.utc)
        self.assertTrue(all((at-timedelta(minutes=i)).isoformat() in t.state['closes'] for i in (0,1)))
    def test_availability_mismatch_rejected(self):
        r=price();r['checkpoint']=r['event_time']
        with self.assertRaises(ContractBlocked):on_row(Target(),r,current=CURRENT)
    def test_price_cannot_create_entry(self):
        r=price();r['payload']['accepted_events']=[list(ENTRIES)[0]]
        with self.assertRaises(ContractBlocked):on_row(Target(),r,current=CURRENT)
    def test_recovered_price_ignored(self):
        r=price();r['status']='RECOVERED';t=Target();on_row(t,r,current=CURRENT);self.assertFalse(t.state['closes'])
    def test_conflicting_price_rejected(self):
        t=Target();r=price();on_row(t,r,current=CURRENT);r['payload']['nifty_close']+=1
        with self.assertRaises(ContractBlocked):on_row(t,r,current=CURRENT)
        self.assertEqual(next(iter(t.state['closes'].values())),24000)
    def test_reconstructed_price_ignored(self):
        t=Target();r=price();r['payload']['reconstructed']=True;on_row(t,r,current=CURRENT);self.assertFalse(t.state['closes'])
    def test_event_time_mismatch_rejected(self):
        r=price();r['event_time']='2026-11-25T09:21:00+05:30'
        with self.assertRaises(ContractBlocked):on_row(Target(),r,current=CURRENT)
if __name__=='__main__':unittest.main()
