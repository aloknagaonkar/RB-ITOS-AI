"""Disposable file/database migration protocol; no service commands or live apply."""
import hashlib,json,os,sqlite3,tempfile
from pathlib import Path
TABLE='hilega_native_source_transition_v1'
class MigrationBlocked(ValueError):pass
def need(ok,reason):
    if not ok:raise MigrationBlocked(reason)
def sha(b):return hashlib.sha256(b).hexdigest()
def encoded(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def raw(p):
    need(not any(q.is_symlink() for q in (p,*p.parents)),'SYMLINK_REJECTED');return p.read_bytes()
def atomic(p,b,mode=0o600):
    need(not any(q.is_symlink() for q in (p,*p.parents)),'SYMLINK_REJECTED');fd,name=tempfile.mkstemp(prefix='.native-migration-',dir=p.parent)
    try:
        os.fchmod(fd,mode)
        with os.fdopen(fd,'wb') as stream:stream.write(b);stream.flush();os.fsync(stream.fileno())
        os.replace(name,p);directory=os.open(p.parent,os.O_DIRECTORY)
        try:os.fsync(directory)
        finally:os.close(directory)
    finally:
        if os.path.exists(name):os.unlink(name)
def execute(database,proposal,proposal_sha256,entries,*,sandbox,audit,checkpoint=lambda stage:None,scope_check=None):
    database=Path(database).absolute();sandbox=Path(sandbox).absolute();audit=Path(audit).absolute()
    if scope_check is None:
        need(sandbox.name.startswith('hilega-native-transaction-review-'),'DISPOSABLE_SCOPE_REQUIRED')
        need(database.is_relative_to(sandbox) and audit.is_relative_to(sandbox),'DISPOSABLE_SCOPE_REQUIRED')
    else:
        need(callable(scope_check),'EXACT_SCOPE_CHECK_REQUIRED');scope_check(database,sandbox,audit,entries)
    need(not audit.exists(),'NEW_TRANSACTION_AUDIT_REQUIRED')
    need(entries and len({str(e['path']) for e in entries})==len(entries),'DISTINCT_REPLACEMENTS_REQUIRED')
    for entry in entries:
        p=Path(entry['path']).absolute()
        if scope_check is None:need(p.is_relative_to(sandbox),'DISPOSABLE_SCOPE_REQUIRED')
        need(sha(raw(p))==entry['before_sha256'],'FILE_BINDING_CHANGED')
    audit.mkdir(mode=0o700);old=[]
    for i,entry in enumerate(entries):
        p=Path(entry['path']);b=raw(p);mode=p.stat().st_mode&0o777;atomic(audit/('original-'+str(i)),b);old.append((p,b,mode))
    def phase(value):atomic(audit/'TRANSACTION.json',encoded(dict(phase=value,proposal_sha256=proposal_sha256,source_restart_permitted=False,automatic_database_restore=False,production_execution_enabled=False)))
    phase('ORIGINALS_DURABLE');committed=False;db=None
    try:
        db=sqlite3.connect(database,isolation_level=None);db.execute('PRAGMA synchronous=FULL');db.execute('BEGIN IMMEDIATE')
        tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")};need(TABLE not in tables,'EXISTING_MIGRATION_REQUIRES_REVIEW')
        control=json.loads(db.execute('SELECT data FROM control WHERE id=1').fetchone()[0]);route=json.loads(db.execute('SELECT data FROM preparation_route WHERE id=1').fetchone()[0]);stop=db.execute('SELECT generation,handled FROM sim_stop_state WHERE id=1').fetchone()
        need(control['mode']=='PAUSED' and control['production_execution_enabled'] is False and control['simulation_only'] is True and route['route']=='PREPARATION_ONLY' and stop and stop[0]==stop[1],'PAUSED_CLOSED_BASELINE_REQUIRED')
        need(control['version']==proposal['controller_version'] and control['session_date']==proposal['session_date'],'CONTROLLER_BINDING_CHANGED')
        for name in ('intents','sim_orders','sim_fills','sim_allocation_reservations','preparation_plans','preparation_shadow_holds','preparation_outbox','preparation_request_bindings','preparation_cash_reservations'):
            if name in tables:need(db.execute('SELECT 1 FROM '+name+' LIMIT 1').fetchone() is None,'PENDING_ACTIVITY_REQUIRES_REVIEW')
        cursor=json.loads(db.execute('SELECT data FROM preparation_source WHERE id=1').fetchone()[0]);need(cursor==proposal['old_cursor'],'CURSOR_BINDING_CHANGED')
        receipt=dict(model='HILEGA_NATIVE_SOURCE_TRANSITION_V1',proposal_sha256=proposal_sha256,old_cursor=cursor,new_cursor=proposal['proposed_baseline'],policy_id=proposal['policy_id'],strategy_version=proposal['strategy_version'],release_sha256=proposal['candidate_release_sha256'],controller_version=control['version'],session_date=control['session_date'],entry_permission=False,production_execution_enabled=False,historical_records_baselined=proposal['historical_records_to_baseline'])
        receipt['transition_id']=sha(encoded(receipt))
        db.execute('CREATE TABLE '+TABLE+'(id INTEGER PRIMARY KEY CHECK(id=1),data TEXT NOT NULL)');db.execute('INSERT INTO '+TABLE+' VALUES(1,?)',(encoded(receipt).decode(),));checkpoint('AFTER_RECEIPT_INSERT')
        db.execute('UPDATE preparation_source SET data=? WHERE id=1',(encoded(proposal['proposed_baseline']).decode(),));checkpoint('AFTER_CURSOR_UPDATE')
        phase('REPLACING_FILES_DATABASE_UNCOMMITTED')
        for i,entry in enumerate(entries):
            p=Path(entry['path']);need(sha(raw(p))==entry['before_sha256'],'FILE_CHANGED_BEFORE_REPLACEMENT');atomic(p,entry['after'],old[i][2]);checkpoint('AFTER_FILE_'+str(i+1))
        checkpoint('BEFORE_DATABASE_COMMIT');db.execute('COMMIT');committed=True;phase('CURSOR_COMMITTED_SOURCE_STOPPED');checkpoint('AFTER_DATABASE_COMMIT')
        for entry in entries:need(raw(Path(entry['path']))==entry['after'],'POST_COMMIT_FILE_CHANGED')
        phase('DISPOSABLE_COMBINED_TRANSACTION_PASS');return receipt
    except BaseException:
        if db is not None and db.in_transaction:db.rollback()
        try:
            for i,(p,b,mode) in reversed(list(enumerate(old))):
                need(sha(raw(p)) in {sha(b),sha(entries[i]['after'])},'ROLLBACK_FILE_CONFLICT');atomic(p,b,mode)
            phase('FILES_RESTORED_CURSOR_COMMITTED_SOURCE_STOPPED' if committed else 'FILES_AND_CURSOR_ROLLED_BACK_SOURCE_STOPPED')
        except BaseException:
            phase('ROLLBACK_CONFLICT_SOURCE_MUST_REMAIN_STOPPED');raise
        raise
    finally:
        if db is not None:db.close()
