"""Exact native migration: check first; paused/closed install only, never activation."""
import argparse,fcntl,hashlib,importlib.util,json,os,sqlite3,subprocess,sys,tempfile,time
from pathlib import Path
from transaction import execute,atomic,TABLE
HERE=Path(__file__).resolve().parent
PLAN_SHA='ff6dd6ea0b27525c514cd9f9d38856a791278edb1e10f6fb718974633f69cd0f'
PROOF_SHA='3d70f761989a6638c5b6202e6253ad3dc34c3704312e2387d929d7b361f33306'
RECOVERY='hilega-closed-pause-recovery.service'
def need(ok,reason):
    if not ok:raise ValueError(reason)
def raw(p):
    need(p.is_absolute() and p.is_file() and not any(q.is_symlink() for q in (p,*p.parents)),'REGULAR_ABSOLUTE_FILE_REQUIRED');return p.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(raw(p))
def save(p,v):atomic(p,(json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
def command(args,timeout=100):
    r=subprocess.run(args,capture_output=True,text=True,timeout=timeout);need(r.returncode==0,'COMMAND_FAILED: '+args[0]);return r.stdout
def ctl(action,name):command(['systemctl','--user',action,name])
def properties(name):return dict(l.split('=',1) for l in command(['systemctl','--user','--no-pager','--full','show',name,'--property=ActiveState,SubState,MainPID,FragmentPath,DropInPaths,ExecStart']).splitlines() if '=' in l)
def verify_package(root):
    for n,h in load(root/'MANIFEST.json').items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts,'UNSAFE_PACKAGE_PATH');need(sha(raw(root/rel))==h,'PACKAGE_CHANGED')
def seal(root,digest):
    mb=raw(root/'RELEASE-MANIFEST.json');need(sha(mb)==digest,'MANIFEST_CHANGED');manifest=json.loads(mb)
    for n,h in manifest['files'].items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts,'UNSAFE_RELEASE_PATH');need(sha(raw(root/rel))==h,'RELEASE_FILE_CHANGED')
    need({p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}==set(manifest['files'])|{'RELEASE-MANIFEST.json'},'UNMANIFESTED_RELEASE_FILE')
    reg=load(root/'runtime/FACTORY-REGISTRATION.json');need(reg['enabled'] is False and reg['production_execution_enabled'] is False,'FACTORY_DISABLED_REQUIRED')
    reg=load(root/'CLOSED-REGISTRATION.json');need(reg['mode']=='CLOSED_PREPARATION_ONLY' and reg['execution_factory_configured'] is False and reg['production_execution_enabled'] is False,'CLOSED_RELEASE_REQUIRED');return manifest

def helpers(repo):
    tool=repo/'hilega-group1-rollout-v1';verify_package(tool);sys.path[:0]=[str(tool),str(repo/'hilega-production-application-deployment')]
    def mod(name,file):
        s=importlib.util.spec_from_file_location(name,tool/file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
    return mod('native_installer_primitives','maintenance_primitives.py'),mod('native_installer_rollout','rollout.py')
def control_cursor(p):
    with sqlite3.connect(Path(p['application_db']).as_uri()+'?mode=ro',uri=True) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN');c=json.loads(db.execute('SELECT data FROM control WHERE id=1').fetchone()[0]);cursor=json.loads(db.execute('SELECT data FROM preparation_source WHERE id=1').fetchone()[0]);route=json.loads(db.execute('SELECT data FROM preparation_route WHERE id=1').fetchone()[0])
        migrated=db.execute('SELECT name FROM sqlite_master WHERE name=?',(TABLE,)).fetchone()
    need(c['mode']=='PAUSED' and c['production_execution_enabled'] is False and c['simulation_only'] is True and route['route']=='PREPARATION_ONLY','PAUSED_CLOSED_REQUIRED');return c,cursor,bool(migrated)
def journal(p,repo):
    contract=repo/'hilega-native-preparation-contract-v1';reader=repo/'hilega-source-reader-candidate-v3';verify_package(contract);verify_package(reader);sys.path.insert(0,str(contract))
    spec=importlib.util.spec_from_file_location('native_install_reader',contract/'review.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    with m.reader(reader/'candidate.py')(Path(p['old_cursor']['path'])) as rows:
        old=p['old_cursor'];tail=p['proposed_baseline'];need(len(rows)==tail['sequence'] and rows[-1]['record_hash']==tail['hash'],'JOURNAL_CHANGED_REPLAN');need(old['sequence']==0 or rows[old['sequence']-1]['record_hash']==old['hash'],'SOURCE_PREFIX_CHANGED')
def files(p,folder):
    for n,h in p['payload_hashes'].items():need(sha(raw(folder/'payload'/n))==h,'PAYLOAD_CHANGED')
    for n,h in p['bindings'].items():need(sha(raw(Path(n)))==h,'BOUND_INPUT_CHANGED')
    need(sha(raw(Path(p['worker'])))==p['old_worker_sha256'] and sha(raw(Path(p['recovery_unit'])))==p['old_recovery_unit_sha256'],'INSTALLED_FILES_CHANGED')
def preflight(p,repo,folder,m):
    files(p,folder);seal(Path(p['candidate']),p['candidate_release_sha256']);seal(Path(p['old_release']),p['old_release_sha256']);m.require_empty_closed_baseline(Path(p['application_db']),Path(p['adapter_db']));c,cursor,migrated=control_cursor(p)
    need(not migrated,'EXISTING_MIGRATION_REQUIRES_REVIEW');need(c['version']==p['controller_version'] and c['session_date']==p['session_date'] and cursor==p['old_cursor'],'DATABASE_BINDING_CHANGED')
    need(not Path(p['destination']).exists() and not Path(p['new_recovery_folder']).exists(),'DESTINATION_EXISTS_REVIEW_REQUIRED')
    states={n:properties(n) for n in (*m.UNITS,RECOVERY,'hilega-quote-observer.service')}
    need(states[m.UNITS[0]]['ActiveState'] in {'inactive','failed'} and int(states[m.UNITS[0]]['MainPID'])==0,'SOURCE_STOPPED_REQUIRED')
    need(all(states[n]['ActiveState']=='active' and int(states[n]['MainPID'])>0 for n in m.UNITS[1:]),'COMPANIONS_RUNNING_REQUIRED');need(states[RECOVERY]['ActiveState']=='active' and not states[RECOVERY]['DropInPaths'],'EXACT_ACTIVE_RECOVERY_REQUIRED');need(int(states['hilega-quote-observer.service']['MainPID'])==0,'QUOTE_OBSERVER_MUST_BE_STOPPED')
    allowed={os.getpid(),*(int(v['MainPID']) for v in states.values())}
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit() or int(entry.name) in allowed:continue
        try:
            if entry.stat().st_uid==os.getuid() and (entry/'cwd').resolve()==repo:
                argv=(entry/'cmdline').read_bytes().split(b'\0');need(not argv or argv[0]!=str(repo/'.venv/bin/python').encode(),'UNMANAGED_REPOSITORY_PYTHON_REMAINS')
        except (FileNotFoundError,ProcessLookupError):pass
    supervision=Path.home()/'hilega-persistent-supervision-stage-v1';permit=load(supervision/'MIGRATION_APPROVED.json');configuration=load(supervision/'config-private.json')
    need(permit['runner_sha256']==sha(raw(supervision/'runner.py')) and permit['config_sha256']==sha(raw(supervision/'config-private.json')),'SUPERVISION_BINDING_CHANGED');env_sha=sha(raw(repo/'.env'));need(configuration['env_sha256']==env_sha,'SUPERVISED_ENV_CHANGED')
    journal(p,repo);return dict(controller_version=c['version'],session_date=c['session_date'],cursor=cursor,unit_state=states,env_sha256=env_sha)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--action',choices=('check','apply'),default='check');ap.add_argument('--check',type=Path);ap.add_argument('--check-sha256');a=ap.parse_args();repo=a.repo.resolve();verify_package(HERE)
    proposal=repo/'hilega-native-migration-plan-on2233ej/PLAN.json';need(sha(raw(proposal))==PLAN_SHA,'EXACT_PROPOSAL_REQUIRED');p=load(proposal);folder=proposal.parent
    need(p['repo']==str(repo) and p['policy_id']=='RSI_TWO_ROUTE_CONFIRMED_MIDPOINT' and p['strategy_version']=='rsi-two-route-1.0.0-3m-native-confirmed-midpoint','NATIVE_SCOPE_REQUIRED')
    need(Path(p['worker'])==repo/'scripts/hilega_production_simulator_bridge.py' and Path(p['recovery_unit'])==Path.home()/'.config/systemd/user'/RECOVERY and Path(p['destination'])==repo/'data/runtime/hilega-closed-releases'/p['candidate_release_sha256'],'EXACT_DESTINATIONS_REQUIRED')
    proof=repo/'hilega-native-transaction-review-edy3nrhl/RESULT.json';need(sha(raw(proof))==PROOF_SHA,'COMBINED_PROOF_CHANGED');pr=load(proof);need(pr['proposal_sha256']==PLAN_SHA and pr['status']=='DISPOSABLE_COMBINED_NATIVE_MIGRATION_TRANSACTION_PASS' and len(pr['scenarios'])==9 and all(v['passed'] for v in pr['scenarios']),'COMBINED_PROOF_REQUIRED')
    recovery=folder/'native-recovery-review-3vk92jum/PROCESS.json';rr=load(recovery);need(rr['exit_code']==0 and rr['proposal_sha256']==PLAN_SHA and json.loads(rr['stdout'])['status']=='LIVE_ADAPTER_SYNTHETIC_REHEARSAL_PASS','NATIVE_RECOVERY_PROOF_REQUIRED')
    m,old=helpers(repo);lock=repo/'.hilega-closed-rollout.lock';need(not lock.is_symlink(),'LOCK_SYMLINK');fd=os.open(lock,os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'r+') as held:
        fcntl.flock(held,fcntl.LOCK_EX|fcntl.LOCK_NB);state=preflight(p,repo,folder,m)
        if a.action=='check':
            audit=Path(tempfile.mkdtemp(prefix='native-installer-check-',dir=folder));audit.chmod(0o700);output=audit/'hilega-native-transaction-review-core'
            r=subprocess.run([sys.executable,'-B',str(HERE/'rehearse_transaction.py'),'--repo',str(repo),'--plan',str(proposal),'--plan-sha256',PLAN_SHA,'--output',str(output)],capture_output=True,text=True,timeout=300)
            save(audit/'REHEARSAL-PROCESS.json',dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));print(r.stdout,flush=True);need(r.returncode==0,'PACKAGED_TRANSACTION_REHEARSAL_FAILED: '+str(audit));proof2=load(output/'RESULT.json');need(proof2['status']=='DISPOSABLE_COMBINED_NATIVE_MIGRATION_TRANSACTION_PASS','PACKAGED_REHEARSAL_NOT_PASSED')
            receipt=dict(status='NATIVE_MIGRATION_INSTALL_CHECK_PASS',created_at=time.time(),proposal_sha256=PLAN_SHA,installer_manifest_sha256=sha(raw(HERE/'MANIFEST.json')),state=state,transaction_rehearsal=str(output/'RESULT.json'),transaction_rehearsal_sha256=sha(raw(output/'RESULT.json')),recovery_receipt_sha256=sha(raw(recovery)),services_changed=False,live_cursor_modified=False,production_execution_enabled=False)
            save(audit/'CHECK.json',receipt);print(json.dumps(dict(check=str(audit/'CHECK.json'),check_sha256=sha(raw(audit/'CHECK.json')),status=receipt['status'],services_changed=False,live_cursor_modified=False,production_execution_enabled=False),indent=2));return
        need(a.check and a.check_sha256,'EXACT_CHECK_REQUIRED');check_path=a.check.absolute();need(sha(raw(check_path))==a.check_sha256,'CHECK_CHANGED');check=load(check_path)
        need(check['status']=='NATIVE_MIGRATION_INSTALL_CHECK_PASS' and check['proposal_sha256']==PLAN_SHA and check['installer_manifest_sha256']==sha(raw(HERE/'MANIFEST.json')),'CHECK_SCOPE_CHANGED');need(0<=time.time()-check['created_at']<=1800,'CHECK_EXPIRED');need(check['state']==state,'STATE_CHANGED_RECHECK');need(sha(raw(Path(check['transaction_rehearsal'])))==check['transaction_rehearsal_sha256'] and sha(raw(recovery))==check['recovery_receipt_sha256'],'CHECK_EVIDENCE_CHANGED')
        audit=Path(tempfile.mkdtemp(prefix='native-install-transaction-',dir=folder));audit.chmod(0o700);print('AUDIT: '+str(audit),flush=True)
        originals=[(Path(p['worker']),raw(Path(p['worker'])),Path(p['worker']).stat().st_mode&0o777),(Path(p['recovery_unit']),raw(Path(p['recovery_unit'])),Path(p['recovery_unit']).stat().st_mode&0o777)]
        for i,(_,b,_) in enumerate(originals):atomic(audit/('original-'+str(i)),b)
        def phase(v):save(audit/'TRANSACTION.json',dict(phase=v,proposal_sha256=PLAN_SHA,automatic_database_restore=False,production_execution_enabled=False))
        phase('STOPPING_WRITERS');cursor_committed=False
        try:
            for n in m.UNITS:ctl('stop',n)
            ctl('stop',RECOVERY);source_state=properties(m.UNITS[0])
            if source_state['ActiveState']=='failed' and int(source_state['MainPID'])==0:command(['systemctl','--user','reset-failed',m.UNITS[0]])
            stopped={n:properties(n) for n in (*m.UNITS,RECOVERY)};save(audit/'STOPPED-STATES.json',stopped);need(all(v['ActiveState']=='inactive' and int(v['MainPID'])==0 for v in stopped.values()),'QUIESCENCE_FAILED');m.no_unmanaged_python(repo)
            files(p,folder);journal(p,repo);m.require_empty_closed_baseline(Path(p['application_db']),Path(p['adapter_db']));c,cursor,migrated=control_cursor(p);need(not migrated and c['version']==p['controller_version'] and cursor==p['old_cursor'],'STOPPED_DATABASE_CHANGED');need(sha(raw(repo/'.env'))==state['env_sha256'],'ENV_CHANGED')
            for key in ('application_db','adapter_db'):m.backup_database(Path(p[key]),audit/(key+'.sqlite'))
            phase('QUIESCENT_BACKUPS_COMPLETE')
            dest=Path(p['destination']);need(not any(q.is_symlink() for q in (dest,*dest.parents)),'DESTINATION_SYMLINK');dest.mkdir(mode=0o700);candidate=Path(p['candidate']);manifest=seal(candidate,p['candidate_release_sha256'])
            for n in [*manifest['files'],'RELEASE-MANIFEST.json']:
                target=dest/n;target.parent.mkdir(parents=True,exist_ok=True,mode=0o700);atomic(target,raw(candidate/n))
            seal(dest,p['candidate_release_sha256']);new_recovery=Path(p['new_recovery_folder']);need(not any(q.is_symlink() for q in (new_recovery,*new_recovery.parents)),'RECOVERY_DESTINATION_SYMLINK');new_recovery.mkdir(mode=0o700)
            for n in ('CONFIG.json','live_recovery.py'):atomic(new_recovery/n,raw(folder/'payload'/n))
            entries=[dict(path=originals[0][0],before_sha256=p['old_worker_sha256'],after=raw(folder/'payload/worker.py')),dict(path=originals[1][0],before_sha256=p['old_recovery_unit_sha256'],after=raw(folder/'payload/recovery.service'))]
            def live_scope(database,sandbox,transaction_audit,targets):
                need(database==Path(p['application_db']) and sandbox==repo and transaction_audit==audit/'combined','EXACT_LIVE_TRANSACTION_SCOPE_REQUIRED');need([Path(e['path']) for e in targets]==[originals[0][0],originals[1][0]],'EXACT_REPLACEMENTS_REQUIRED');need(all(properties(n)['ActiveState']=='inactive' and int(properties(n)['MainPID'])==0 for n in (*m.UNITS,RECOVERY)),'SERVICES_MUST_REMAIN_STOPPED')
            phase('COMBINED_FILES_CURSOR_TRANSACTION');receipt=execute(Path(p['application_db']),p,PLAN_SHA,entries,sandbox=repo,audit=audit/'combined',scope_check=live_scope);cursor_committed=True;save(audit/'MIGRATION-RECEIPT.json',receipt)
            command(['systemctl','--user','daemon-reload']);phase('STARTING_NATIVE_PAUSE_RECOVERY');ctl('start',RECOVERY);m.require_empty_closed_baseline(Path(p['application_db']),Path(p['adapter_db']));control_cursor(p)
            previous=old.read_health(Path(p['application_db']))['run_id']
            for n in reversed(m.UNITS[1:]):ctl('start',n)
            old.wait_inventory(repo);command(['systemctl','--user','reset-failed',m.UNITS[0]]);ctl('start',m.UNITS[0]);old.wait_health(Path(p['application_db']),previous,m.Systemd(),list(m.UNITS),timeout=90)
            m.require_empty_closed_baseline(Path(p['application_db']),Path(p['adapter_db']));c,cursor,migrated=control_cursor(p);need(migrated and cursor['sequence']>=p['proposed_baseline']['sequence'],'MIGRATION_STATE_LOST');seal(dest,p['candidate_release_sha256']);need(sha(raw(originals[0][0]))==p['new_worker_sha256'] and sha(raw(originals[1][0]))==p['new_recovery_unit_sha256'],'POST_INSTALL_BINDINGS_CHANGED')
            phase('NATIVE_PREPARATION_MIGRATION_RUNNING_PAUSED');report=dict(status='NATIVE_PREPARATION_MIGRATION_RUNNING_PAUSED',audit=str(audit),release_sha256=p['candidate_release_sha256'],transition_id=receipt['transition_id'],controller_paused=True,managed_runtime_running=True,live_source_freshness_verified=False,real_enrollment_or_activation_complete=False,production_execution_enabled=False);save(audit/'RESULT.json',report);print(json.dumps(report,indent=2))
        except BaseException:
            phase('FAILURE_STOPPING_BEFORE_FILE_ROLLBACK')
            try:
                for n in m.UNITS:ctl('stop',n)
                ctl('stop',RECOVERY);need(all(int(properties(n)['MainPID'])==0 for n in (*m.UNITS,RECOVERY)),'ROLLBACK_STOP_FAILED');m.no_unmanaged_python(repo)
                for i,(path,b,mode) in reversed(list(enumerate(originals))):
                    need(sha(raw(path)) in {sha(b),p['new_worker_sha256'] if i==0 else p['new_recovery_unit_sha256']},'ROLLBACK_FILE_CONFLICT');atomic(path,b,mode)
                command(['systemctl','--user','daemon-reload']);ctl('start',RECOVERY);control_cursor(p)
                for n in reversed(m.UNITS[1:]):ctl('start',n)
                old.wait_inventory(repo);control_cursor(p)
                _,_,migrated=control_cursor(p);phase('FILES_RESTORED_CURSOR_COMMITTED_SOURCE_STOPPED' if migrated else 'FILES_AND_CURSOR_ROLLED_BACK_SOURCE_STOPPED')
            except BaseException:
                phase('ROLLBACK_REQUIRES_REVIEW_SOURCE_STOP_REQUESTED')
                try:ctl('stop',m.UNITS[0])
                except Exception:pass
            raise
if __name__=='__main__':
    try:main()
    except Exception as e:
        print(json.dumps(dict(status='NATIVE_MIGRATION_INSTALLER_BLOCKED',reason=str(e) if type(e) is ValueError else type(e).__name__,production_execution_enabled=False)),flush=True);raise SystemExit(2)
