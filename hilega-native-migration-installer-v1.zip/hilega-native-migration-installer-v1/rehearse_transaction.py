"""Exact-proposal transaction rehearsal, with read-only live database snapshot."""
import argparse,hashlib,importlib.util,json,os,sqlite3,tempfile
from pathlib import Path
from transaction import execute,TABLE
HERE=Path(__file__).resolve().parent

def need(ok,reason):
    if not ok:raise ValueError(reason)
def raw(p):
    need(p.is_absolute() and not any(q.is_symlink() for q in (p,*p.parents)),'REGULAR_PATH_REQUIRED');return p.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def verify(root):
    for n,h in json.loads(raw(root/'MANIFEST.json')).items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts and sha(raw(root/rel))==h,'PACKAGE_CHANGED')
def fingerprint(path,ignore=()):
    result={}
    with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
        for (name,) in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
            if name in ignore:continue
            quoted='"'+name.replace('"','""')+'"';result[name]=sha('\n'.join(sorted(repr(tuple(row)) for row in db.execute('SELECT * FROM '+quoted))).encode())
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--plan',type=Path,required=True);ap.add_argument('--plan-sha256',required=True);ap.add_argument('--output',type=Path);a=ap.parse_args();repo=a.repo.resolve();plan=a.plan.resolve();verify(HERE);plan_bytes=raw(plan);need(sha(plan_bytes)==a.plan_sha256,'PROPOSAL_CHANGED');p=json.loads(plan_bytes)
    need(p['model']=='HILEGA_NATIVE_PREPARATION_MIGRATION_PROPOSAL_V1' and p['repo']==str(repo),'PROPOSAL_SCOPE_CHANGED')
    candidate=Path(p['candidate']);mb=raw(candidate/'RELEASE-MANIFEST.json');need(sha(mb)==p['candidate_release_sha256'],'CANDIDATE_CHANGED')
    for n,h in json.loads(mb)['files'].items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts and sha(raw(candidate/rel))==h,'CANDIDATE_FILE_CHANGED')
    for n,h in p['payload_hashes'].items():need(sha(raw(plan.parent/'payload'/n))==h,'PAYLOAD_CHANGED')
    for n,h in p['bindings'].items():need(sha(raw(Path(n)))==h,'BOUND_INPUT_CHANGED')
    contract=repo/'hilega-native-preparation-contract-v1';reader=repo/'hilega-source-reader-candidate-v3';verify(contract);verify(reader)
    import sys
    sys.path.insert(0,str(contract));s=importlib.util.spec_from_file_location('combined_reader',contract/'review.py');loader=importlib.util.module_from_spec(s);s.loader.exec_module(loader)
    with loader.reader(reader/'candidate.py')(Path(p['old_cursor']['path'])) as rows:
        cursor=p['old_cursor'];tail=p['proposed_baseline'];need(len(rows)==tail['sequence'] and rows[-1]['record_hash']==tail['hash'],'JOURNAL_TAIL_CHANGED_REPLAN');need(cursor['sequence']==0 or rows[cursor['sequence']-1]['record_hash']==cursor['hash'],'CURSOR_PREFIX_CHANGED')
    audit=a.output.resolve() if a.output else Path(tempfile.mkdtemp(prefix='hilega-native-transaction-review-',dir=repo))
    if a.output:
        need(not audit.exists(),'NEW_REHEARSAL_DIRECTORY_REQUIRED');audit.mkdir(mode=0o700)
    audit.chmod(0o700);snapshot=audit/'read-only-live-snapshot.sqlite'
    live=Path(p['application_db'])
    with sqlite3.connect(live.as_uri()+'?mode=ro',uri=True) as source,sqlite3.connect(snapshot) as destination:source.backup(destination)
    snapshot.chmod(0o600);before=fingerprint(snapshot);cases=[]
    stages=('SUCCESS','AFTER_RECEIPT_INSERT','AFTER_CURSOR_UPDATE','AFTER_FILE_1','AFTER_FILE_2','BEFORE_DATABASE_COMMIT','AFTER_DATABASE_COMMIT')
    for stage in stages:
        folder=audit/stage;folder.mkdir(mode=0o700);database=folder/'application.sqlite'
        with sqlite3.connect(snapshot.as_uri()+'?mode=ro',uri=True) as source,sqlite3.connect(database) as dest:source.backup(dest)
        database.chmod(0o600);entries=[]
        for name,live_path,before_hash in [('worker.py',p['worker'],p['old_worker_sha256']),('recovery.service',p['recovery_unit'],p['old_recovery_unit_sha256'])]:
            original=raw(Path(live_path));need(sha(original)==before_hash,'ORIGINAL_FILE_CHANGED');target=folder/name;target.write_bytes(original);target.chmod(0o600);entries.append(dict(path=target,before_sha256=before_hash,after=raw(plan.parent/'payload'/name)))
        def fault(at):
            if at==stage:raise RuntimeError('INJECTED_COMBINED_TRANSACTION_INTERRUPTION')
        def scoped(db_path,scope,tx_audit,targets):
            need(db_path==database and scope==audit and tx_audit==folder/'transaction' and [e['path'] for e in targets]==[e['path'] for e in entries],'EXACT_TEST_SCOPE_REQUIRED')
        triggered=False
        try:receipt=execute(database,p,a.plan_sha256,entries,sandbox=audit,audit=folder/'transaction',checkpoint=fault,scope_check=scoped)
        except RuntimeError:triggered=True
        need(triggered==(stage!='SUCCESS'),'FAULT_NOT_TRIGGERED_OR_UNEXPECTED_FAILURE')
        phase=json.loads((folder/'transaction/TRANSACTION.json').read_text())['phase']
        committed=stage in ('SUCCESS','AFTER_DATABASE_COMMIT')
        with sqlite3.connect(database.as_uri()+'?mode=ro',uri=True) as db:
            cursor=json.loads(db.execute('SELECT data FROM preparation_source WHERE id=1').fetchone()[0]);exists=db.execute('SELECT name FROM sqlite_master WHERE name=?',(TABLE,)).fetchone()
            need(cursor==(p['proposed_baseline'] if committed else p['old_cursor']),'CURSOR_TRANSACTION_INCORRECT');need(bool(exists)==committed,'RECEIPT_TRANSACTION_INCORRECT')
            if committed:
                saved=json.loads(db.execute('SELECT data FROM '+TABLE+' WHERE id=1').fetchone()[0]);need(saved['proposal_sha256']==a.plan_sha256 and saved['new_cursor']==p['proposed_baseline'],'RECEIPT_BINDING_INCORRECT')
        if committed:need(fingerprint(database,('preparation_source',TABLE))=={n:h for n,h in before.items() if n!='preparation_source'},'UNRELATED_DATABASE_STATE_CHANGED')
        else:need(fingerprint(database)==before,'DATABASE_NOT_ROLLED_BACK')
        for entry in entries:need(raw(entry['path'])==(entry['after'] if stage=='SUCCESS' else raw(Path(p['worker'] if entry['path'].name=='worker.py' else p['recovery_unit']))),'FILES_NOT_RESTORED')
        expected='DISPOSABLE_COMBINED_TRANSACTION_PASS' if stage=='SUCCESS' else 'FILES_RESTORED_CURSOR_COMMITTED_SOURCE_STOPPED' if committed else 'FILES_AND_CURSOR_ROLLED_BACK_SOURCE_STOPPED';need(phase==expected,'RECOVERY_PHASE_INCORRECT')
        cases.append(dict(scenario=stage,passed=True,phase=phase,cursor_committed=committed));print(json.dumps(cases[-1]),flush=True)
    # Negative preconditions use the same transaction code and real snapshot copies.
    for label,mutate in [('cursor',"UPDATE preparation_source SET data='{}' WHERE id=1"),('controller',None)]:
        folder=audit/('negative-'+label);folder.mkdir(mode=0o700);db_path=folder/'application.sqlite'
        with sqlite3.connect(snapshot.as_uri()+'?mode=ro',uri=True) as src,sqlite3.connect(db_path) as dst:src.backup(dst)
        with sqlite3.connect(db_path) as db:
            if mutate:db.execute(mutate)
            else:
                c=json.loads(db.execute('SELECT data FROM control WHERE id=1').fetchone()[0]);c['version']+=1;db.execute('UPDATE control SET data=? WHERE id=1',(json.dumps(c),))
        local=folder/'worker';original=raw(Path(p['worker']));local.write_bytes(original);local.chmod(0o600)
        rejected=False
        try:execute(db_path,p,a.plan_sha256,[dict(path=local,before_sha256=sha(original),after=b'candidate')],sandbox=audit,audit=folder/'transaction')
        except ValueError as e:rejected=str(e)==('CURSOR_BINDING_CHANGED' if label=='cursor' else 'CONTROLLER_BINDING_CHANGED')
        need(rejected and raw(local)==original,'CHANGED_STATE_NOT_REJECTED');cases.append(dict(scenario='changed_'+label,passed=True))
    result=dict(status='DISPOSABLE_COMBINED_NATIVE_MIGRATION_TRANSACTION_PASS',audit=str(audit),proposal_sha256=a.plan_sha256,scenarios=cases,live_database_read_only_snapshot=True,live_database_modified=False,live_cursor_modified=False,live_files_modified=False,services_changed=False,process_crash_or_power_loss_recovery_verified=False,post_commit_cursor_rewind_performed=False,source_restart_permitted=False,live_apply_available=False,production_execution_enabled=False)
    (audit/'RESULT.json').write_text(json.dumps(result,indent=2));print('RESULT_SHA256:',sha(raw(audit/'RESULT.json')));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
