"""Exercise real installer coordinator using fake services and disposable filesystem only."""
import contextlib, hashlib, importlib.util, io, json, shutil, sqlite3, sys, tempfile
from pathlib import Path
from types import SimpleNamespace
HERE=Path(__file__).resolve().parent

def run_case(base, fault):
    root=base/fault;root.mkdir(mode=0o700)
    spec=importlib.util.spec_from_file_location('installer_case_'+fault,HERE/'manage.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    class SandboxPath(type(Path())):
        @classmethod
        def home(cls):return cls(root/'home')
    mod.Path=SandboxPath
    names=('hilega-production-source-worker.service','hilega-worker.service','hilega-api.service','hilega-lifecycle-reference.service','hilega-observation-analytics.service','hilega-observation-readiness.service')
    rec=mod.RECOVERY;quote='hilega-quote-observer.service'
    states={n:dict(ActiveState='active',SubState='running',MainPID='100',FragmentPath='',DropInPaths='',ExecStart='synthetic') for n in names}
    states[names[0]].update(ActiveState='failed',SubState='failed',MainPID='0')
    states[rec]=dict(ActiveState='active',SubState='exited',MainPID='0',FragmentPath='',DropInPaths='',ExecStart='synthetic')
    states[quote]=dict(ActiveState='inactive',SubState='dead',MainPID='0',FragmentPath='',DropInPaths='',ExecStart='')
    folder=root/'preparation';folder.mkdir();payload=folder/'payload';payload.mkdir()
    worker=root/'worker.py';worker.write_bytes(b'old worker');unit=root/'recovery.service';unit.write_bytes(b'old unit')
    worker.chmod(0o640);unit.chmod(0o600)
    for n,b in [('worker.py',b'new worker'),('recovery.service',b'new unit'),('live_recovery.py',b'synthetic recovery'),('CONFIG.json',b'{}')]: (payload/n).write_bytes(b)
    old_recovery=root/'old-recovery';old_recovery.mkdir()
    for n in ('CONFIG.json','live_recovery.py'):(old_recovery/n).write_bytes(b'old recovery')
    supervisor=root/'home/hilega-persistent-supervision-stage-v1';supervisor.mkdir(parents=True)
    (supervisor/'runner.py').write_bytes(b'synthetic runner');(supervisor/'config-private.json').write_bytes(b'{}')
    (supervisor/'MIGRATION_APPROVED.json').write_text(json.dumps(dict(config_sha256=mod.sha(b'{}'),runner_sha256=mod.sha(b'synthetic runner'))))
    fake_here=root/'installer';fake_here.mkdir();(fake_here/'MANIFEST.json').write_bytes(b'{}');mod.HERE=fake_here
    receipt=folder/'recovery-rehearsal-32bsab1i';receipt.mkdir();(receipt/'PROCESS.json').write_text(json.dumps(dict(exit_code=0,installation_plan_sha256=mod.PLAN_HASH,stdout=json.dumps(dict(status='LIVE_ADAPTER_SYNTHETIC_REHEARSAL_PASS')))))
    candidate=root/'candidate';candidate.mkdir();(candidate/'payload.py').write_bytes(b'candidate payload')
    (candidate/'RELEASE-MANIFEST.json').write_text(json.dumps(dict(files={'payload.py':mod.sha(b'candidate payload')})))
    app=root/'app.sqlite';adapter=root/'adapter.sqlite'
    for path in (app,adapter):
        with sqlite3.connect(path) as db:db.execute('CREATE TABLE fixture(value TEXT)')
    p=dict(application_db=str(app),adapter_db=str(adapter),worker_destination=str(worker),recovery_unit_destination=str(unit),old_worker_sha256=mod.sha(b'old worker'),old_recovery_unit_sha256=mod.sha(b'old unit'),new_worker_sha256=mod.sha(b'new worker'),new_recovery_unit_sha256=mod.sha(b'new unit'),proposed_release_destination=str(root/'installed-release'),new_recovery_folder=str(root/'installed-recovery'),old_recovery_folder=str(old_recovery),candidate=str(candidate),candidate_release_sha256='synthetic')
    triggered=[];events=[]
    def inject(at):
        if fault==at and not triggered:triggered.append(at);raise RuntimeError('INJECTED_'+at)
    def control(action,name):
        events.append((action,name))
        if action=='start':
            if name==rec:inject('recovery_start')
            elif name==names[-1]:inject('companion_start')
            states[name].update(ActiveState='active',SubState='exited' if name==rec else 'running',MainPID='0' if name==rec else '101')
        else:states[name].update(ActiveState='inactive',SubState='dead',MainPID='0')
    def backup(source,destination):inject('backup');shutil.copyfile(source,destination)
    def health(*a,**kw):inject('heartbeat')
    manager=SimpleNamespace(UNITS=names,no_unmanaged_python=lambda r:None,backup_database=backup,Systemd=lambda:None)
    prior=SimpleNamespace(read_health=lambda p:{'run_id':'previous'},wait_inventory=lambda r:None,wait_health=health)
    mod.prepare=lambda args:(root,p,folder)
    mod.helper=lambda repo:(manager,prior)
    mod.baseline=lambda p,m:dict(mode='PAUSED',version=260,session_date='2026-11-25')
    mod.properties=lambda name:dict(states[name])
    mod.ctl=control
    mod.command=lambda argv,timeout=60:events.append(tuple(argv)) or ''
    mod.seal=lambda path,digest:None  # Integrity logic tested separately by live read-only check.
    original_replace=mod.replace_pair
    def replace(entries,checkpoint=lambda n:None):
        def at(n):inject('replace_'+str(n));checkpoint(n)
        return original_replace(entries,at)
    old_argv=sys.argv[:]
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            sys.argv=['manage.py','--repo',str(root),'--action','check'];mod.main()
        check=next(folder.glob('installer-check-*/CHECK.json'))
        mod.replace_pair=replace
        proof_path=root/'proof.json'
        (fake_here/'rehearse.py').write_bytes(b'synthetic rehearsal')
        proof_path.write_text(json.dumps(dict(status='DISPOSABLE_INSTALLER_ORCHESTRATION_PASS',rehearsal_sha256=mod.sha(b'synthetic rehearsal'),installer_manifest_sha256=mod.sha(b'{}'),scenarios=[dict(passed=True) for _ in range(7)])))
        sys.argv=['manage.py','--repo',str(root),'--action','apply','--check',str(check),'--check-sha256',mod.sha(check.read_bytes()),'--orchestration-receipt',str(proof_path),'--orchestration-sha256',mod.sha(proof_path.read_bytes())]
        error=None
        try:
            with contextlib.redirect_stdout(io.StringIO()):mod.main()
        except RuntimeError as e:error=e
        tx=next(folder.glob('installer-transaction-*/TRANSACTION.json'));phase=json.loads(tx.read_text())['phase']
        if fault=='success':
            assert error is None and phase=='CLOSED_READER_REPAIR_RUNNING'
            assert worker.read_bytes()==b'new worker' and unit.read_bytes()==b'new unit'
            assert states[names[0]]['ActiveState']=='active'
        else:
            assert triggered==[fault] and error is not None,(fault,triggered,phase)
            assert phase=='ROLLED_BACK_SOURCE_LEFT_STOPPED',phase
            assert worker.read_bytes()==b'old worker' and unit.read_bytes()==b'old unit'
            assert states[names[0]]['MainPID']=='0'
            assert all(states[n]['ActiveState']=='active' for n in names[1:])
            assert states[rec]['ActiveState']=='active'
        assert worker.stat().st_mode&0o777==0o640
        assert unit.stat().st_mode&0o777==0o600
        assert all('resume' not in event for event in events)
        return dict(scenario=fault,phase=phase,passed=True)
    finally:sys.argv=old_argv

def main():
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--output-parent',type=Path,required=True);a=parser.parse_args()
    parent=a.output_parent.resolve();assert parent.is_dir() and not parent.is_symlink()
    base=Path(tempfile.mkdtemp(prefix='reader-installer-orchestration-',dir=parent));base.chmod(0o700)
    results=[run_case(base,n) for n in ('success','backup','replace_1','replace_2','recovery_start','companion_start','heartbeat')]
    result=dict(status='DISPOSABLE_INSTALLER_ORCHESTRATION_PASS',scenarios=results,services_simulated=True,live_services_changed=False,production_execution_enabled=False,full_systemd_or_power_loss_recovery_verified=False,rehearsal_sha256=hashlib.sha256((HERE/'rehearse.py').read_bytes()).hexdigest(),installer_manifest_sha256=hashlib.sha256((HERE/'MANIFEST.json').read_bytes()).hexdigest())
    (base/'RESULT.json').write_text(json.dumps(result,indent=2));print('AUDIT:',base);print('RESULT_SHA256:',hashlib.sha256((base/'RESULT.json').read_bytes()).hexdigest());print(json.dumps(result,indent=2))
if __name__=='__main__':main()
