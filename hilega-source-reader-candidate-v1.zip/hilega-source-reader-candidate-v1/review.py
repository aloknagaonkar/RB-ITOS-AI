"""Candidate validation only. No installation, worker launch or broker requests."""
import argparse,ast,hashlib,json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
TARGET=Path('backend/market_lab/hilega_production_simulator_bridge_v1.py')

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    a=argparse.ArgumentParser();a.add_argument('--repo',type=Path,required=True);a.add_argument('--source',type=Path);args=a.parse_args();repo=args.repo.resolve()
    pins=json.loads((HERE/'MANIFEST.json').read_text())
    for name,digest in pins.items():
        if sha(HERE/name)!=digest:raise ValueError('CANDIDATE_PACKAGE_CHANGED')
    if sha(repo/TARGET)!=sha(HERE/'original.py'):raise ValueError('REPOSITORY_READER_CHANGED')
    # Inspect the literal sealed release identity without executing the launcher.
    launcher=repo/'scripts/hilega_production_simulator_bridge.py'
    tree=ast.parse(launcher.read_text());roots=[]
    for node in tree.body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='root' for t in node.targets):
            if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=='Path':roots.append(Path(ast.literal_eval(node.value.args[0])))
    if len(roots)!=1:raise ValueError('SEALED_ROOT_UNRESOLVED')
    release=roots[0];manifest=release/'RELEASE-MANIFEST.json'
    if sha(manifest)!=release.name:raise ValueError('SEALED_MANIFEST_CHANGED')
    sealed=json.loads(manifest.read_text())['files']
    for name,digest in sealed.items():
        rel=Path(name);p=release/rel
        if rel.is_absolute() or '..' in rel.parts or any(q.is_symlink() for q in (p,*p.parents)) or sha(p)!=digest:raise ValueError('SEALED_INPUT_CHANGED')
    if sha(release/TARGET)!=sha(HERE/'original.py'):raise ValueError('INSTALLED_READER_DIFFERS_FROM_CANDIDATE_BASE')
    stage=Path(tempfile.mkdtemp(prefix='hilega-source-reader-candidate-',dir=repo));stage.chmod(0o700)
    # Isolated backend copy for existing regression tests; source installation untouched.
    shutil.copytree(repo/'backend',stage/'backend',symlinks=True,ignore=shutil.ignore_patterns('__pycache__','.env','*.sqlite*','*.db'))
    shutil.copyfile(HERE/'candidate.py',stage/TARGET)
    selected=['test_hilega_application_preparation_v1.py','test_hilega_candle_revision_policy_v1.py','test_hilega_central_sim_allocation_v1.py','test_hilega_production_bridge_health_v1.py','test_hilega_production_simulator_bridge_v1.py']
    tests=stage/'tests';tests.mkdir()
    for name in selected:shutil.copyfile(repo/'tests'/name,tests/name)
    env=dict(os.environ,PYTHONPATH=str(stage/'backend'),PYTHONDONTWRITEBYTECODE='1')
    env.pop('PYTEST_ADDOPTS',None);env['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
    results=[]
    for paths in [[str(HERE/'test_reader.py')],[str(tests/name) for name in selected]]:
        r=subprocess.run([str(repo/'.venv/bin/python'),'-B','-m','pytest','-q','-p','no:cacheprovider',*paths],cwd=stage,env=env,capture_output=True,text=True,timeout=600)
        results.append(dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
        print(r.stdout,flush=True)
        if r.returncode:
            (stage/'TEST-RESULTS.json').write_text(json.dumps(results,indent=2));raise ValueError('CANDIDATE_TEST_FAILED: '+str(stage))
    scan=None
    if args.source:
        # Extract only reader code; no bridge/database/worker imports or invocation.
        import importlib.util
        spec=importlib.util.spec_from_file_location('isolated_reader_tests',HERE/'test_reader.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        scope=module.reader()
        with scope['verified_records'](args.source.resolve()) as records:
            scan=dict(fully_verified=True,records=len(records),last_record_hash=records[-1]['record_hash'] if records else None,source_bytes=args.source.stat().st_size)
    if sha(release/TARGET)!=sha(HERE/'original.py') or sha(repo/TARGET)!=sha(HERE/'original.py'):raise ValueError('SOURCE_CHANGED_DURING_REVIEW')
    result=dict(status='READER_CANDIDATE_TESTS_PASS',installed_release_sha256=release.name,tests=results,journal_scan=scan,stage=str(stage),installed_sources_modified=False,services_changed=False,controller_resumed=False,orders_sent=False,live_apply_available=False,production_ready=False)
    (stage/'RESULT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
