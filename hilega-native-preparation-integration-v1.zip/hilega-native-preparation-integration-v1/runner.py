"""Actual Source guards on disposable state; no live databases, network or credentials."""
import argparse,hashlib,json,os,shutil,socket,sqlite3,sys,uuid
from datetime import datetime
from pathlib import Path

def deny_network(*a,**k):raise RuntimeError('NETWORK_DISABLED_FOR_REHEARSAL')
socket.socket.connect=deny_network;socket.socket.connect_ex=deny_network;socket.create_connection=deny_network

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--release',type=Path,required=True);ap.add_argument('--audit',type=Path,required=True);ap.add_argument('--backup',type=Path,required=True);ap.add_argument('--transition-package',type=Path,required=True);a=ap.parse_args()
    root=a.release.resolve();audit=a.audit.resolve();sys.path[:0]=[str(root/'backend'),str(root/'runtime'),str(a.transition_package)]
    from transition import transition
    from market_lab.hilega_production_foundation.core import Store,SimBroker,Service
    from market_lab.hilega_preparation_runtime_v1.source import Source
    from market_lab.hilega_exclusive_closed_route_v1 import closed_poll
    from market_lab.hilega_production_simulator_bridge_v1 import verified_records
    from market_lab.hilega_native_preparation_contract_v1 import POLICY,VERSION,ENTRIES
    journal=audit/'fixture-journal.jsonl';size=journal.stat().st_size
    outcomes=[]
    def counts(path):
        with sqlite3.connect(path) as db:
            names={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            return {n:db.execute('SELECT COUNT(*) FROM '+n).fetchone()[0] if n in names else 0 for n in ('preparation_consumed','preparation_events','preparation_plans','preparation_shadow_holds','preparation_outbox','intents','sim_orders','sim_fills')}
    with verified_records(journal) as history:
        last=history[-1]['record_hash'];sequence=len(history)
        for scenario in ('history','paused_and_replay','fresh_evidence_denied','stale','future','entry_clock','wrong_version'):
            with journal.open('r+b') as f:f.truncate(size)
            folder=audit/scenario;folder.mkdir(mode=0o700);database=folder/'application.sqlite';shutil.copyfile(a.backup,database);database.chmod(0o600)
            transition(database,history,journal,sandbox=audit)
            initial=counts(database);clock=[datetime.fromisoformat('2026-11-25T10:02:59+05:30')]
            store=Store(database);service=Service(store,SimBroker(store),lambda:clock[0],worker_start=False)
            requests=[]
            def provider():requests.append('REQUESTED');raise RuntimeError('NO_EVIDENCE_IN_REHEARSAL')
            source=Source(service,run_id='SYNTHETIC_NATIVE_REHEARSAL',provider=provider)
            if scenario not in ('history','paused_and_replay','wrong_version'):
                if scenario=='entry_clock':clock[0]=datetime.fromisoformat('2026-11-25T14:54:59+05:30')
                for action in ('reconcile','resume'):
                    c=store.control();service.command(action,request_id=uuid.uuid4().hex,expected_version=c['version'],actor='DISPOSABLE_NATIVE_TEST',session_date=c['session_date'])
                assert store.control()['mode']=='ARMED','SYNTHETIC_ARM_FAILED'
            clock[0]=datetime.fromisoformat('2026-11-25T14:57:00+05:30' if scenario=='entry_clock' else '2026-11-25T10:03:00+05:30')
            if scenario!='history':
                stamp={'stale':'2026-11-25T09:18:00+05:30','future':'2026-11-25T10:06:00+05:30','entry_clock':'2026-11-25T14:57:00+05:30'}.get(scenario,'2026-11-25T10:03:00+05:30');name=next(iter(ENTRIES))
                row=dict(sequence=sequence+1,previous_hash=last,stage='DIRECTIONAL_DECISION',status='PROCESSED',payload=dict(policy_id=POLICY,strategy_version='UNREVIEWED_NATIVE_VERSION' if scenario=='wrong_version' else VERSION,reconstructed=False,decision_timestamp=stamp,accepted_events=[name],event_details=[dict(event_type=name,event_time=stamp,entry_time=stamp)]))
                row['record_hash']=hashlib.sha256(json.dumps(row,sort_keys=True,separators=(',',':'),ensure_ascii=False,default=str).encode()).hexdigest()
                with journal.open('a') as f:f.write(json.dumps(row)+'\n')
            error=None
            try:result=closed_poll(source,journal)
            except Exception as e:error=str(e)
            if scenario=='wrong_version':assert error=='SOURCE_POLICY_OR_VERSION_MISMATCH',(scenario,error)
            else:assert error is None,(scenario,error)
            after=counts(database)
            assert all(after[n]==initial[n] for n in ('preparation_plans','preparation_shadow_holds','preparation_outbox','intents','sim_orders','sim_fills')),'UNEXPECTED_PREPARATION_OR_ORDER'
            if scenario=='history':
                assert after==initial and not requests,'HISTORY_REPLAYED'
                reason='HISTORY_BASELINED_WITHOUT_DISPATCH'
            elif scenario=='wrong_version':
                assert after['preparation_consumed']==initial['preparation_consumed'] and not requests
                reason=error
            else:
                with store.db() as db:
                    event=json.loads(db.execute('SELECT data FROM preparation_events ORDER BY seq DESC LIMIT 1').fetchone()[0])
                reason={'paused_and_replay':'CONTROLLER_PAUSED_OR_STOP_PENDING','fresh_evidence_denied':'EVIDENCE_PROVIDER_UNAVAILABLE','stale':'SIGNAL_STALE_FUTURE_OR_PRE_RESUME','future':'SIGNAL_STALE_FUTURE_OR_PRE_RESUME','entry_clock':'ENTRY_CLOCK_WINDOW_CLOSED'}[scenario]
                assert reason in event['reasons'],(scenario,event['reasons'])
                assert len(requests)==(1 if scenario=='fresh_evidence_denied' else 0),'UNEXPECTED_EVIDENCE_REQUEST'
                assert after['preparation_consumed']==initial['preparation_consumed']+1
                if scenario=='paused_and_replay':
                    closed_poll(source,journal);assert counts(database)==after,'REPLAY_MUTATED_STATE'
            assert store.control()['mode']=='PAUSED','FIXTURE_LEFT_ARMED'
            outcomes.append(dict(scenario=scenario,passed=True,reason=reason));print(json.dumps(outcomes[-1]),flush=True)
    report=dict(status='DISPOSABLE_NATIVE_SOURCE_GUARD_INTEGRATION_PASS',scenarios=outcomes,actual_sealed_source_guard_executed=True,synthetic_database_arm_only=True,signed_evidence_to_unsent_plan_verified=False,exit_dispatch_verified=False,full_worker_startup_verified=False,live_database_opened=False,live_cursor_modified=False,services_changed=False,production_execution_enabled=False,live_apply_available=False)
    (audit/'RESULT.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
