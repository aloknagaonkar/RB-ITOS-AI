"""Exercise real file protocol on disposable directories; no service or database calls."""
import argparse,json
from pathlib import Path
from repair import install_files,restore_files,sha

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();a.output.mkdir(mode=0o700);results=[]
    for fault in ('SUCCESS','AFTER_CACHE','AFTER_FILE_1','AFTER_FILE_2'):
        root=a.output/fault;root.mkdir(mode=0o700);release=root/'release';cache=release/'runtime/__pycache__/sample.cpython-313.pyc';cache.parent.mkdir(parents=True,mode=0o700);cache.write_bytes(b'not executable cache fixture')
        src=release/'runtime/sample.py';src.write_bytes(b'# source fixture\n');originals=[];entries=[]
        for n in ('worker','unit'):
            p=root/n;p.write_bytes(b'original '+n.encode());originals.append((p,p.read_bytes(),0o600));entries.append(dict(path=p,before_sha256=sha(p.read_bytes()),after=b'new '+n.encode(),mode=0o600))
        caches={cache.relative_to(release).as_posix():dict(sha256=sha(cache.read_bytes()),size=cache.stat().st_size)};audit=root/'audit';audit.mkdir(mode=0o700)
        def checkpoint(name):
            if name==fault:raise RuntimeError('INJECTED')
        failed=False
        try:install_files(release,caches,entries,audit,checkpoint)
        except RuntimeError:failed=True;restore_files(entries,originals)
        assert failed==(fault!='SUCCESS')
        assert not cache.exists() and (audit/'quarantine'/cache.relative_to(release)).read_bytes()==b'not executable cache fixture'
        assert src.read_bytes()==b'# source fixture\n'
        for e,o in zip(entries,originals):assert e['path'].read_bytes()==(e['after'] if fault=='SUCCESS' else o[1])
        results.append(dict(scenario=fault,passed=True))
    # An unexpected changed cache is rejected before any file replacement.
    root=a.output/'changed-cache';root.mkdir(mode=0o700);cache=root/'__pycache__/x.cpython-313.pyc';cache.parent.mkdir();cache.write_bytes(b'changed');audit=root/'audit';audit.mkdir()
    try:install_files(root,{'__pycache__/x.cpython-313.pyc':dict(sha256=sha(b'old'),size=3)},[],audit)
    except ValueError as e:assert str(e)=='CACHE_CHANGED'
    else:raise AssertionError('CHANGED_CACHE_ACCEPTED')
    assert cache.read_bytes()==b'changed';results.append(dict(scenario='changed_cache',passed=True))
    report=dict(status='DISPOSABLE_BYTECODE_FILE_TRANSACTION_PASS',scenarios=results,live_services_changed=False,database_access_performed=False,systemd_or_power_loss_recovery_verified=False,production_execution_enabled=False)
    (a.output/'RESULT.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
