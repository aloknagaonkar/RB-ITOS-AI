"""Exact native migration: check first; paused/closed install only, never activation."""
import argparse,fcntl,hashlib,importlib.util,json,os,sqlite3,subprocess,sys,tempfile,time
from pathlib import Path
from repair import atomic,install_files,restore_files
HERE=Path(__file__).resolve().parent
PLAN_SHA='4c589f7365f68305e111489c8706aef1e0b6d4e0d4701f76a7f481567e15033e'
TABLE='hilega_native_source_transition_v1'
RECOVERY='hilega-closed-pause-recovery.service'
def need(ok,reason):
    if not ok:raise ValueError(reason)
def raw(p):
    need(p.is_absolute() and p.is_file() and not any(q.is_symlink() for q in (p,*p.parents)),'REGULAR_ABSOLUTE_FILE_REQUIRED');return p.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(raw(p))
def save(p,v):atomic(p,(json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
def command(args,timeout=100):
    r=subprocess.run(args,capture_output=True,text=True,timeout=timeout);need(r.returncode==0,'COMMAND_FAILED: '+args[0]);return r.stdout
def ctl(action,name):command(['systemctl','--user',action,name])
def properties(name):return dict(l.split('=',1) for l in command(['systemctl','--user','--no-pager','--full','show',name,'--property=ActiveState,SubState,MainPID,FragmentPath,DropInPaths,ExecStart']).splitlines() if '=' in l)
def verify_package(root):
    for n,h in load(root/'MANIFEST.json').items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts,'UNSAFE_PACKAGE_PATH');need(sha(raw(root/rel))==h,'PACKAGE_CHANGED')
def seal(root,digest):
    mb=raw(root/'RELEASE-MANIFEST.json');need(sha(mb)==digest,'MANIFEST_CHANGED');manifest=json.loads(mb)
    for n,h in manifest['files'].items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts,'UNSAFE_RELEASE_PATH');need(sha(raw(root/rel))==h,'RELEASE_FILE_CHANGED')
    need({p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}==set(manifest['files'])|{'RELEASE-MANIFEST.json'},'UNMANIFESTED_RELEASE_FILE')
    reg=load(root/'runtime/FACTORY-REGISTRATION.json');need(reg['enabled'] is False and reg['production_execution_enabled'] is False,'FACTORY_DISABLED_REQUIRED')
    reg=load(root/'CLOSED-REGISTRATION.json');need(reg['mode']=='CLOSED_PREPARATION_ONLY' and reg['execution_factory_configured'] is False and reg['production_execution_enabled'] is False,'CLOSED_RELEASE_REQUIRED');return manifest

def helpers(repo):
    tool=repo/'hilega-group1-rollout-v1';verify_package(tool);sys.path[:0]=[str(tool),str(repo/'hilega-production-application-deployment')]
    def mod(name,file):
        s=importlib.util.spec_from_file_location(name,tool/file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
    return mod('native_installer_primitives','maintenance_primitives.py'),mod('native_installer_rollout','rollout.py')
def database(p,m,*,exact):
    m.require_empty_closed_baseline(Path(p['application_db']),Path(p['adapter_db']))
    with sqlite3.connect(Path(p['application_db']).as_uri()+'?mode=ro',uri=True) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
        c=json.loads(db.execute('SELECT data FROM control WHERE id=1').fetchone()[0])
        cursor=json.loads(db.execute('SELECT data FROM preparation_source WHERE id=1').fetchone()[0])
        receipt=json.loads(db.execute('SELECT data FROM '+TABLE+' WHERE id=1').fetchone()[0])
    need(c['mode']=='PAUSED' and c['simulation_only'] is True and c['production_execution_enabled'] is False,'PAUSED_CLOSED_REQUIRED')
    encoded=lambda v:(json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
    need(sha(encoded(receipt))==p['migration_receipt_sha256'] and receipt['transition_id']==p['migration_transition_id'],'MIGRATION_RECEIPT_CHANGED')
    if exact:need(c['version']==p['controller_version'] and c['session_date']==p['session_date'] and cursor==p['preserved_cursor'],'DATABASE_CHANGED_REPLAN')
    else:need(cursor['path']==p['preserved_cursor']['path'] and cursor['sequence']>=p['preserved_cursor']['sequence'],'CURSOR_REGRESSED')
    return dict(controller_version=c['version'],cursor=cursor)

def journal(p,repo,cursor):
    contract=repo/'hilega-native-preparation-contract-v1';reader=repo/'hilega-source-reader-candidate-v3';verify_package(contract);verify_package(reader);sys.path.insert(0,str(contract))
    s=importlib.util.spec_from_file_location('repair_reader',contract/'review.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
    with v.reader(reader/'candidate.py')(Path(cursor['path'])) as rows:
        need(cursor['sequence']>0 and cursor['sequence']<=len(rows) and rows[cursor['sequence']-1]['record_hash']==cursor['hash'],'CURSOR_PREFIX_CHANGED')

def cache_inventory(p):
    import importlib.util
    root=Path(p['release']);mb=raw(root/'RELEASE-MANIFEST.json');need(sha(mb)==p['release_sha256'],'MANIFEST_CHANGED');manifest=json.loads(mb)
    for n,h in manifest['files'].items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts and sha(raw(root/rel))==h,'SEALED_SOURCE_CHANGED')
    expected=set(manifest['files'])|{'RELEASE-MANIFEST.json'};extra={}
    for path in root.rglob('*'):
        need(not path.is_symlink(),'RELEASE_SYMLINK')
        if not path.is_file():continue
        n=path.relative_to(root).as_posix()
        if n in expected:continue
        need(path.parent.name=='__pycache__' and path.suffix=='.pyc','UNEXPECTED_EXTRA_FILE')
        source=Path(importlib.util.source_from_cache(str(path))).relative_to(root).as_posix();need(source in manifest['files'],'CACHE_SOURCE_NOT_MANIFESTED')
        extra[n]=dict(sha256=sha(raw(path)),size=path.stat().st_size,source=source)
    need(extra==p['cache_files_to_quarantine'],'CACHE_INVENTORY_CHANGED')

def files(p,folder):
    for n,h in p['payload_hashes'].items():
        need(Path(n).name==n and sha(raw(folder/'payload'/n))==h,'PAYLOAD_CHANGED')
    need(sha(raw(Path(p['worker'])))==p['old_worker_sha256'] and sha(raw(Path(p['recovery_unit'])))==p['old_recovery_unit_sha256'],'RESTORED_BINDINGS_CHANGED')
    need(not Path(p['new_recovery_folder']).exists(),'RECOVERY_DESTINATION_EXISTS')
    need(b'sys.dont_write_bytecode=True\n' in raw(folder/'payload/worker.py'),'WRAPPER_PREVENTION_REQUIRED')

def preflight(p,repo,folder,m):
    files(p,folder);cache_inventory(p);state=database(p,m,exact=True);journal(p,repo,state['cursor'])
    units={n:properties(n) for n in (*m.UNITS,RECOVERY,'hilega-quote-observer.service')}
    need(units[m.UNITS[0]]['ActiveState'] in {'inactive','failed'} and int(units[m.UNITS[0]]['MainPID'])==0,'SOURCE_STOPPED_REQUIRED')
    need(all(units[n]['ActiveState']=='active' and int(units[n]['MainPID'])>0 for n in m.UNITS[1:]),'COMPANIONS_RUNNING_REQUIRED')
    need(units[RECOVERY]['ActiveState']=='active' and not units[RECOVERY]['DropInPaths'] and int(units['hilega-quote-observer.service']['MainPID'])==0,'RECOVERY_OR_OBSERVER_CHANGED')
    for n,v in units.items():
        if n in p['unit_state']:
            for k in ('FragmentPath','DropInPaths','ExecStart'):need(v[k]==p['unit_state'][n][k],'UNIT_CONFIGURATION_CHANGED')
    allowed={os.getpid(),*(int(v['MainPID']) for v in units.values())}
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit() or int(entry.name) in allowed:continue
        try:
            if entry.stat().st_uid==os.getuid() and (entry/'cwd').resolve()==repo:
                argv=(entry/'cmdline').read_bytes().split(b'\0');need(not argv or argv[0]!=str(repo/'.venv/bin/python').encode(),'UNMANAGED_REPOSITORY_PYTHON_REMAINS')
        except (FileNotFoundError,ProcessLookupError):pass
    supervision=Path.home()/'hilega-persistent-supervision-stage-v1';permit=load(supervision/'MIGRATION_APPROVED.json');config=load(supervision/'config-private.json')
    need(permit['runner_sha256']==sha(raw(supervision/'runner.py')) and permit['config_sha256']==sha(raw(supervision/'config-private.json')),'SUPERVISION_CHANGED')
    state.update(unit_state=units,env_sha256=sha(raw(repo/'.env')));need(config['env_sha256']==state['env_sha256'],'ENV_CHANGED');return state

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--action',choices=('check','apply'),default='check');ap.add_argument('--check',type=Path);ap.add_argument('--check-sha256');a=ap.parse_args();repo=a.repo.resolve();verify_package(HERE)
    path=repo/'hilega-native-bytecode-repair-plan-mmmiussu/PLAN.json';need(sha(raw(path))==PLAN_SHA,'EXACT_REPAIR_PLAN_REQUIRED');p=load(path);folder=path.parent
    need(p['model']=='HILEGA_NATIVE_POST_COMMIT_BYTECODE_REPAIR_PROPOSAL_V1' and p['repo']==str(repo) and p['production_execution_enabled'] is False,'EXACT_REPAIR_SCOPE_REQUIRED')
    need(Path(p['worker'])==repo/'scripts/hilega_production_simulator_bridge.py' and Path(p['recovery_unit'])==Path.home()/'.config/systemd/user'/RECOVERY,'EXACT_TARGETS_REQUIRED')
    need(Path(p['release'])==repo/'data/runtime/hilega-closed-releases'/p['release_sha256'] and Path(p['new_recovery_folder']).parent==repo/'data/runtime/hilega-closed-pause-recovery','EXACT_RELEASE_AND_RECOVERY_REQUIRED')
    proof=folder/'pause-recovery-dnacv795/PROCESS.json';pr=load(proof);need(pr['exit_code']==0 and pr['repair_plan_sha256']==PLAN_SHA,'RECOVERY_PROOF_CHANGED');v=json.loads(pr['stdout']);need(v['status']=='LIVE_ADAPTER_SYNTHETIC_REHEARSAL_PASS' and {q['scenario'] for q in v['scenarios']}=={'paused-empty','armed-empty'} and all(q['native_pause_verified'] and q['disposable_database_only'] for q in v['scenarios']),'RECOVERY_PROOF_REQUIRED')
    m,old=helpers(repo);lock=repo/'.hilega-closed-rollout.lock';need(not lock.is_symlink(),'LOCK_SYMLINK');fd=os.open(lock,os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'r+') as held:
        fcntl.flock(held,fcntl.LOCK_EX|fcntl.LOCK_NB);state=preflight(p,repo,folder,m)
        if a.action=='check':
            audit=Path(tempfile.mkdtemp(prefix='bytecode-installer-check-',dir=folder));audit.chmod(0o700)
            r=subprocess.run([sys.executable,'-B',str(HERE/'rehearse.py'),'--output',str(audit/'rehearsal')],capture_output=True,text=True,timeout=90)
            save(audit/'REHEARSAL.json',dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));print(r.stdout,flush=True);need(r.returncode==0,'FILESYSTEM_REHEARSAL_FAILED: '+str(audit))
            check=dict(status='BYTECODE_FORWARD_REPAIR_CHECK_PASS',created_at=time.time(),plan_sha256=PLAN_SHA,manifest_sha256=sha(raw(HERE/'MANIFEST.json')),recovery_proof_sha256=sha(raw(proof)),rehearsal_sha256=sha(raw(audit/'REHEARSAL.json')),state=state,services_changed=False,live_cursor_modified=False,production_execution_enabled=False)
            save(audit/'CHECK.json',check);print(json.dumps(dict(status=check['status'],check=str(audit/'CHECK.json'),check_sha256=sha(raw(audit/'CHECK.json')),preserved_cursor_sequence=state['cursor']['sequence'],services_changed=False,live_cursor_modified=False,production_execution_enabled=False),indent=2));return
        need(a.check and a.check_sha256,'EXACT_CHECK_REQUIRED');cp=a.check.absolute();need(sha(raw(cp))==a.check_sha256,'CHECK_CHANGED');check=load(cp)
        need(check['status']=='BYTECODE_FORWARD_REPAIR_CHECK_PASS' and check['plan_sha256']==PLAN_SHA and check['manifest_sha256']==sha(raw(HERE/'MANIFEST.json')),'CHECK_SCOPE_CHANGED');need(0<=time.time()-check['created_at']<=1800 and check['state']==state,'CHECK_EXPIRED_OR_STATE_CHANGED');need(check['recovery_proof_sha256']==sha(raw(proof)) and check['rehearsal_sha256']==sha(raw(cp.parent/'REHEARSAL.json')),'PROOF_CHANGED')
        audit=Path(tempfile.mkdtemp(prefix='bytecode-install-transaction-',dir=folder));audit.chmod(0o700);print('AUDIT: '+str(audit),flush=True)
        def phase(s):save(audit/'TRANSACTION.json',dict(phase=s,plan_sha256=PLAN_SHA,cursor_rewind_performed=False,automatic_database_restore=False,production_execution_enabled=False))
        originals=[(Path(p['worker']),raw(Path(p['worker'])),Path(p['worker']).stat().st_mode&0o777),(Path(p['recovery_unit']),raw(Path(p['recovery_unit'])),Path(p['recovery_unit']).stat().st_mode&0o777)]
        entries=[dict(path=q[0],before_sha256=sha(q[1]),after=raw(folder/'payload'/n),mode=q[2]) for q,n in zip(originals,('worker.py','recovery.service'))]
        for i,q in enumerate(originals):atomic(audit/('original-'+str(i)),q[1])
        try:
            phase('STOPPING_WRITERS')
            for n in m.UNITS:ctl('stop',n)
            ctl('stop',RECOVERY)
            if properties(m.UNITS[0])['ActiveState']=='failed':command(['systemctl','--user','reset-failed',m.UNITS[0]])
            need(all(properties(n)['ActiveState']=='inactive' and int(properties(n)['MainPID'])==0 for n in (*m.UNITS,RECOVERY)),'QUIESCENCE_FAILED');m.no_unmanaged_python(repo)
            files(p,folder);cache_inventory(p);database(p,m,exact=True);need(sha(raw(repo/'.env'))==state['env_sha256'],'ENV_CHANGED');journal(p,repo,p['preserved_cursor'])
            for k in ('application_db','adapter_db'):m.backup_database(Path(p[k]),audit/(k+'.sqlite'))
            phase('INSTALLING_WITH_CACHE_QUARANTINE')
            install_files(Path(p['release']),p['cache_files_to_quarantine'],entries,audit)
            seal(Path(p['release']),p['release_sha256']);new=Path(p['new_recovery_folder']);need(not any(q.is_symlink() for q in (new,*new.parents)),'RECOVERY_SYMLINK');new.mkdir(mode=0o700)
            for n in ('CONFIG.json','live_recovery.py'):atomic(new/n,raw(folder/'payload'/n))
            command(['systemctl','--user','daemon-reload']);phase('STARTING_PAUSE_RECOVERY');ctl('start',RECOVERY);database(p,m,exact=False)
            previous=old.read_health(Path(p['application_db']))['run_id']
            for n in reversed(m.UNITS[1:]):ctl('start',n)
            old.wait_inventory(repo)
            if properties(m.UNITS[0])['ActiveState']=='failed':command(['systemctl','--user','reset-failed',m.UNITS[0]])
            ctl('start',m.UNITS[0]);old.wait_health(Path(p['application_db']),previous,m.Systemd(),list(m.UNITS),timeout=90)
            current=database(p,m,exact=False);journal(p,repo,current['cursor']);seal(Path(p['release']),p['release_sha256'])
            need(sha(raw(Path(p['worker'])))==p['new_worker_sha256'] and sha(raw(Path(p['recovery_unit'])))==p['new_recovery_unit_sha256'],'INSTALLED_BINDINGS_CHANGED')
            phase('NATIVE_PREPARATION_RUNNING_PAUSED');report=dict(status='NATIVE_PREPARATION_RUNNING_PAUSED',audit=str(audit),quarantined_cache_files=len(p['cache_files_to_quarantine']),cursor_sequence=current['cursor']['sequence'],migration_receipt_preserved=True,managed_worker_heartbeat_verified=True,controller_paused=True,live_source_freshness_verified=False,real_enrollment_or_activation_complete=False,production_execution_enabled=False);save(audit/'RESULT.json',report);print(json.dumps(report,indent=2))
        except BaseException:
            phase('FAILURE_STOPPING_BEFORE_RESTORE')
            try:
                for n in m.UNITS:ctl('stop',n)
                ctl('stop',RECOVERY);need(all(int(properties(n)['MainPID'])==0 for n in (*m.UNITS,RECOVERY)),'ROLLBACK_STOP_FAILED');m.no_unmanaged_python(repo)
                restore_files(entries,originals);command(['systemctl','--user','daemon-reload']);ctl('start',RECOVERY);database(p,m,exact=False)
                for n in reversed(m.UNITS[1:]):ctl('start',n)
                old.wait_inventory(repo);database(p,m,exact=False);phase('FILES_RESTORED_CURSOR_PRESERVED_SOURCE_STOPPED')
            except BaseException:
                phase('RECOVERY_REQUIRES_REVIEW_SOURCE_STOP_REQUESTED')
                try:ctl('stop',m.UNITS[0])
                except Exception:pass
            raise
if __name__=='__main__':
    try:main()
    except Exception as e:
        print(json.dumps(dict(status='BYTECODE_FORWARD_REPAIR_BLOCKED',reason=str(e) if type(e) is ValueError else type(e).__name__,production_execution_enabled=False)),flush=True);raise SystemExit(2)
