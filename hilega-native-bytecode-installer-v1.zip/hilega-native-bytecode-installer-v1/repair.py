"""Quarantine exact caches and replace exact wrapper files. No database operations."""
import hashlib,os,tempfile
from pathlib import Path
def need(ok,reason):
    if not ok:raise ValueError(reason)
def raw(p):
    need(p.is_absolute() and p.is_file() and not any(q.is_symlink() for q in (p,*p.parents)),'REGULAR_FILE_REQUIRED');return p.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def atomic(p,b,mode=0o600):
    need(not any(q.is_symlink() for q in (p,*p.parents)),'SYMLINK_REJECTED');fd,name=tempfile.mkstemp(prefix='.native-migration-',dir=p.parent)
    try:
        os.fchmod(fd,mode)
        with os.fdopen(fd,'wb') as stream:stream.write(b);stream.flush();os.fsync(stream.fileno())
        os.replace(name,p);directory=os.open(p.parent,os.O_DIRECTORY)
        try:os.fsync(directory)
        finally:os.close(directory)
    finally:
        if os.path.exists(name):os.unlink(name)

def install_files(root,caches,entries,audit,checkpoint=lambda name:None):
    quarantine=audit/'quarantine';quarantine.mkdir(mode=0o700)
    for name,info in caches.items():
        rel=Path(name);need(not rel.is_absolute() and '..' not in rel.parts and rel.parent.name=='__pycache__' and rel.suffix=='.pyc','EXACT_CACHE_PATH_REQUIRED')
        source=root/rel;need(sha(raw(source))==info['sha256'] and source.stat().st_size==info['size'],'CACHE_CHANGED')
        target=quarantine/rel;target.parent.mkdir(parents=True,exist_ok=True,mode=0o700);need(not target.exists(),'QUARANTINE_EXISTS')
        os.rename(source,target);target.chmod(0o600)
        for directory in (source.parent,target.parent):
            fd=os.open(directory,os.O_DIRECTORY)
            try:os.fsync(fd)
            finally:os.close(fd)
        checkpoint('AFTER_CACHE')
    for i,e in enumerate(entries,1):
        need(sha(raw(e['path']))==e['before_sha256'],'REPLACEMENT_CONFLICT');atomic(e['path'],e['after'],e['mode']);checkpoint('AFTER_FILE_'+str(i))

def restore_files(entries,originals):
    for e,(path,b,mode) in reversed(list(zip(entries,originals))):
        need(sha(raw(path)) in {sha(b),sha(e['after'])},'RESTORE_CONFLICT');atomic(path,b,mode)
