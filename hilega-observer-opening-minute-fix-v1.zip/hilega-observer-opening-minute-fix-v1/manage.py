"""Exact one-file observer timestamp correction; no trading or cursor resets."""
import argparse,ast,hashlib,importlib.util,json,os,subprocess,sys,tempfile,time
from datetime import datetime,timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent
OLD='e2882698610147ea9a2bdc6c9bbdc5395650e91dd65cc5c7ed3c1c9b81d2a429'
PUBLISHER='138064f0f94d79293f641a878e0a7dbd0e1542516de6d0cd2d1e9ec549992a33'
def need(ok,reason):
    if not ok:raise ValueError(reason)
def raw(p):
    need(p.is_absolute() and not any(q.is_symlink() for q in (p,*p.parents)),'SYMLINK_REJECTED');return p.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def encode(v):return (json.dumps(v,indent=2,sort_keys=True)+'\n').encode()
def atomic(p,b,mode=0o600):
    need(not any(q.is_symlink() for q in (p,*p.parents)),'SYMLINK_REJECTED');fd,name=tempfile.mkstemp(dir=p.parent)
    try:
        os.fchmod(fd,mode)
        with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
        os.replace(name,p);fd=os.open(p.parent,os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    finally:
        if os.path.exists(name):os.unlink(name)
def save(p,v):atomic(p,encode(v))
def verify(folder):
    for n,h in json.loads(raw(folder/'MANIFEST.json')).items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts and sha(raw(folder/rel))==h,'PACKAGE_CHANGED')
def stop_check(repo):
    targets={str(repo/'scripts/hilega_policy_observer_service.py').encode(),str(repo/'hilega_policy_live/publisher.py').encode()}
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name)==os.getpid():continue
        try:
            if p.stat().st_uid==os.getuid():need(not targets.intersection((p/'cmdline').read_bytes().split(b'\0')),'OBSERVER_NOT_STOPPED')
        except (FileNotFoundError,ProcessLookupError):pass

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--action',choices=('check','apply'),default='check');ap.add_argument('--check',type=Path);ap.add_argument('--check-sha256');a=ap.parse_args();repo=a.repo.resolve();verify(HERE);target=repo/'hilega_policy_live/native_routing.py';need(sha(raw(target))==OLD,'INSTALLED_ROUTING_CHANGED');publisher=repo/'hilega_policy_live/publisher.py';need(sha(raw(publisher))==PUBLISHER,'PUBLISHER_CHANGED');need(raw(repo/'hilega_policy_live/native_contract.py')==raw(HERE/'native_contract.py'),'ENTRY_CONTRACT_CHANGED')
    proposal=repo/'hilega-native-observer-transition-plan-zgqgq4hn/PLAN.json';need(sha(raw(proposal))=='2aa428ce7dcc4b8a0ce16e8788f4dccb6d02b22363f3a5697853a5ae2525ab60','OBSERVER_PLAN_CHANGED');binding=json.loads(raw(proposal))['bindings'];supervisor=repo/'scripts/hilega_policy_observer_service.py';need(sha(raw(supervisor))==binding[str(supervisor)],'SUPERVISOR_CHANGED')
    data=repo/'data/live-observation/hilega-strike-observation-v1';state=data/'publisher-state.json';manifest_sha=sha(raw(HERE/'MANIFEST.json'));new=raw(HERE/'native_routing.py')
    if a.action=='check':
        audit=Path(tempfile.mkdtemp(prefix='hilega-observer-opening-review-',dir=repo));audit.chmod(0o700);print('AUDIT: '+str(audit),flush=True)
        env=dict(PATH=os.defpath,LANG='C.UTF-8',HOME=str(audit),TMPDIR=str(audit),PYTHONDONTWRITEBYTECODE='1',CANDIDATE_PUBLISHER=str(publisher))
        r=subprocess.run([sys.executable,'-B','-m','unittest','-v','test_routing'],cwd=HERE,env=env,capture_output=True,text=True,timeout=90);save(audit/'TEST-PROCESS.json',dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));print(r.stdout+r.stderr,flush=True);need(r.returncode==0,'OPENING_REGRESSION_TEST_FAILED')
        # Inspect one pending row without moving the actual publisher state.
        old_state=json.loads(raw(state));journal=repo/'data/live-observation/hilega-directional-v1/step-audit.jsonl';need(not any(p.is_symlink() for p in (journal,*journal.parents)),'JOURNAL_SYMLINK')
        with journal.open('rb') as f:
            f.seek(old_state['offset']);line=f.readline(8*1024*1024+1)
        diagnostic=dict(saved_sequence=old_state['sequence'],pending_record_present=bool(line))
        if line:
            need(line.endswith(b'\n'),'PENDING_ROW_INCOMPLETE');row=json.loads(line);need(row['sequence']==old_state['sequence']+1 and row['previous_hash']==old_state['previous_hash'],'PENDING_CHAIN_MISMATCH');core={k:v for k,v in row.items() if k!='record_hash'};need(sha(json.dumps(core,sort_keys=True,separators=(',',':'),ensure_ascii=False,default=str).encode())==row['record_hash'],'PENDING_HASH_MISMATCH')
            from test_routing import Target
            from native_routing import on_row
            spec=importlib.util.spec_from_file_location('old_observer_routing',target);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
            try:module.on_row(Target(),row,current=datetime.now(timezone.utc));old_reason=None
            except ValueError as e:old_reason=str(e)
            on_row(Target(),row,current=datetime.now(timezone.utc));diagnostic.update(sequence=row['sequence'],stage=row.get('stage'),checkpoint=row.get('checkpoint'),decision_timestamp=(row.get('payload') or {}).get('decision_timestamp'),old_error=old_reason,corrected_pending_record_accepted=True)
        save(audit/'PENDING-RECORD-CHECK.json',diagnostic);print(json.dumps(diagnostic,indent=2),flush=True)
        check=dict(status='OBSERVER_OPENING_FIX_CHECK_PASS',created_at=time.time(),repo=str(repo),manifest_sha256=manifest_sha,old_routing_sha256=OLD,new_routing_sha256=sha(new),publisher_sha256=PUBLISHER,supervisor_sha256=sha(raw(supervisor)),test_receipt_sha256=sha(raw(audit/'TEST-PROCESS.json')),pending_receipt_sha256=sha(raw(audit/'PENDING-RECORD-CHECK.json')),observer_state_modified=False,services_changed=False,production_execution_enabled=False);save(audit/'CHECK.json',check);print(json.dumps(dict(status=check['status'],check=str(audit/'CHECK.json'),check_sha256=sha(raw(audit/'CHECK.json')),tests=24,observer_state_modified=False,services_changed=False,production_execution_enabled=False),indent=2));return
    need(a.check and a.check_sha256,'EXACT_CHECK_REQUIRED');cp=a.check.absolute();need(sha(raw(cp))==a.check_sha256,'CHECK_CHANGED');c=json.loads(raw(cp));need(c['status']=='OBSERVER_OPENING_FIX_CHECK_PASS' and c['repo']==str(repo) and c['manifest_sha256']==manifest_sha and c['new_routing_sha256']==sha(new) and c['old_routing_sha256']==OLD and c['supervisor_sha256']==sha(raw(supervisor)),'CHECK_SCOPE_CHANGED');need(0<=time.time()-c['created_at']<=1800,'CHECK_EXPIRED');need(sha(raw(cp.parent/'TEST-PROCESS.json'))==c['test_receipt_sha256'] and sha(raw(cp.parent/'PENDING-RECORD-CHECK.json'))==c['pending_receipt_sha256'],'CHECK_PROOF_CHANGED')
    audit=Path(tempfile.mkdtemp(prefix='hilega-observer-opening-install-',dir=repo));audit.chmod(0o700);print('AUDIT: '+str(audit),flush=True)
    r=subprocess.run([sys.executable,'-B',str(supervisor),'stop'],cwd=repo,capture_output=True,text=True,timeout=30);save(audit/'STOP.json',dict(exit_code=r.returncode));need(r.returncode==0,'OBSERVER_STOP_FAILED');stop_check(repo)
    old=raw(target);need(sha(old)==OLD,'ROUTING_CHANGED_BEFORE_REPLACE');before_state=raw(state);atomic(audit/'original-native_routing.py',old);atomic(audit/'publisher-state-before.json',before_state);mode=target.stat().st_mode&0o777
    save(audit/'TRANSACTION.json',dict(phase='OBSERVER_STOPPED_BACKUPS_COMPLETE',production_execution_enabled=False))
    try:
        atomic(target,new,mode);need(sha(raw(target))==sha(new),'PATCH_VERIFICATION_FAILED');need(raw(state)==before_state,'PUBLISHER_STATE_CHANGED');stop_check(repo)
    except BaseException:
        stop_check(repo);need(sha(raw(target)) in {sha(old),sha(new)},'RESTORE_CONFLICT');atomic(target,old,mode);save(audit/'TRANSACTION.json',dict(phase='ORIGINAL_ROUTING_RESTORED_OBSERVER_STOPPED',production_execution_enabled=False));raise
    save(audit/'TRANSACTION.json',dict(phase='OPENING_TIMESTAMP_FIX_INSTALLED_OBSERVER_STOPPED',production_execution_enabled=False));report=dict(status='OPENING_TIMESTAMP_FIX_INSTALLED_OBSERVER_STOPPED',audit=str(audit),old_routing_sha256=OLD,new_routing_sha256=sha(new),publisher_state_preserved=True,journal_cursor_reset=False,entry_contract_modified=False,application_services_changed=False,observer_started=False,live_quote_publishing_verified=False,production_execution_enabled=False);save(audit/'RESULT.json',report);print(json.dumps(report,indent=2))
if __name__=='__main__':
    try:main()
    except Exception as e:
        print(json.dumps(dict(status='OBSERVER_OPENING_FIX_BLOCKED',reason=str(e) if type(e) is ValueError else type(e).__name__,production_execution_enabled=False)));raise SystemExit(2)
