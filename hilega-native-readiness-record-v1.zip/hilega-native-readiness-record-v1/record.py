"""Record reconciled native readiness evidence. No live changes or activation."""
import argparse,hashlib,json,os,sqlite3,subprocess,sys,tempfile
from datetime import datetime,timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent
ORIGINAL='25a6a37a1600b1a0cebb5026abd356712e9d764b048a4ae757a5c5c475d1f3f9'
RELEASE='e21825cbe956c8d13492684861dee2e00a2e48d17c79d0a9f6418e615d956b75'
REVIEWED={
'hilega-operational-lifecycle-tools-6cexrur_/cli.py':'b9c557b79543738ef05e68b92b4f180902708196c48db906286e72a55050a964',
'hilega-operational-lifecycle-tools-6cexrur_/manifest.json':'7d9d2657563ecb0dafbfb54ea4ddbf16c35c199413b8db1d70ecf3f88bc2daf7',
'hilega-reference-service-stage-yup3_wr1/lifecycle_reference_service.py':'695a709a9a23ed84f8ec228e647febd44960000200a765da1310e7784ac95537',
'backend/market_lab/operational_readiness_v1.py':'1a97c2989c591615f5642141dd1cca85cfc8c0ba9d85bc614de270711fcc54c4',
'scripts/hilega_production_simulator_bridge.py':'5d22f6795146512dba59736f8a5e4cce8e5aa9495a6cc0a2d0eb65e5eb3e7fc6'}
OBSERVER={'publisher.py':'138064f0f94d79293f641a878e0a7dbd0e1542516de6d0cd2d1e9ec549992a33','native_routing.py':'e2882698610147ea9a2bdc6c9bbdc5395650e91dd65cc5c7ed3c1c9b81d2a429','native_contract.py':'b7524253194042a5cdc142343414f75c04cc6cbe01a12539671a5ec97f4f9c3b'}
def need(ok,reason):
    if not ok:raise ValueError(reason)
def raw(p):
    need(p.is_absolute() and not any(q.is_symlink() for q in (p,*p.parents)),'REGULAR_ABSOLUTE_PATH_REQUIRED');return p.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(raw(p))
def encoded(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def save(p,v):
    with p.open('xb') as f:f.write(encoded(v));f.flush();os.fsync(f.fileno())
    p.chmod(0o600)
def verify(folder):
    for n,h in load(folder/'MANIFEST.json').items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts and sha(raw(folder/rel))==h,'RECORDER_PACKAGE_CHANGED')
WARMUP=r'''
import hashlib,json,sys
from datetime import datetime,date
from pathlib import Path
from zoneinfo import ZoneInfo
repo=Path(sys.argv[1])
path=repo/'backend/market_lab/hilega_three_minute_v1/warmup.py'
assert not any(p.is_symlink() for p in (path,*path.parents))
assert hashlib.sha256(path.read_bytes()).hexdigest()=='4b2a91e11be0c026d94f4c068d5bd8ef5b9a434d32f86b2a2ad0c4462e783697','WARMUP_CHANGED'
def guard(event,args):
    if event.startswith('socket.') or event.startswith('sqlite3.connect') or event in ('subprocess.Popen','os.system'):raise RuntimeError('OFFLINE_ONLY')
sys.addaudithook(guard);sys.path.insert(0,str(repo/'backend'))
from market_lab.hilega_active_strategy_v1 import effective_strategy
from market_lab.hilega_alignment_dual_exit_live_v1 import HilegaAlignmentDualExitLiveCoordinator as Coordinator,STRATEGY_ID
from market_lab.hilega_three_minute_v1.hilega_v2_alignment_replay_v1 import cache_index
from market_lab.hilega_three_minute_v1.warmup import load_warmup,warmup_bars
assert effective_strategy('HILEGA_V2_ALIGNMENT_DUAL_EXIT')==STRATEGY_ID=='HILEGA_RSI_TWO_ROUTE_CONFIRMED_MIDPOINT','NATIVE_SELECTION_CHANGED'
target=datetime.now(ZoneInfo('Asia/Kolkata')).date();warmup,coverage=load_warmup(cache_index(),target,source=None);canonical=Coordinator.canonical_factory();count=0
for day,rows in warmup:
    for bar in warmup_bars(rows,date.fromisoformat(day)):canonical.on_bar(bar);count+=1
ready=bool(canonical.bullish.previous_indicators and canonical.bullish.previous_indicators.ready)
assert ready,'NATIVE_INDICATORS_NOT_READY'
print(json.dumps(dict(status='CACHE_ONLY_NATIVE_WARMUP_PASS',target_session=target.isoformat(),coverage=coverage,three_minute_bars_replayed=count,indicator_warmup_ready=ready,official_calendar_reverified=False,broker_source_supplied=False,live_bootstrap_executed=False)))
'''

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);a=ap.parse_args();repo=a.repo.resolve();verify(HERE)
    plan_path=repo/'hilega-warmup-install-plan-6d56keoy/PLAN.json';need(sha(raw(plan_path))==ORIGINAL,'ORIGINAL_PLAN_CHANGED');old=load(plan_path)
    repair_folder=repo/'hilega-native-bytecode-repair-plan-mmmiussu';repair_path=repair_folder/'PLAN.json';need(sha(raw(repair_path))=='4c589f7365f68305e111489c8706aef1e0b6d4e0d4701f76a7f481567e15033e','REPAIR_PLAN_CHANGED');repair=load(repair_path)
    reviewed={str(repo/k):v for k,v in REVIEWED.items()};reviewed[repair['recovery_unit']]=repair['new_recovery_unit_sha256'];need(repair['new_worker_sha256']==REVIEWED['scripts/hilega_production_simulator_bridge.py'],'WORKER_REPAIR_BINDING_CHANGED')
    reconciled={};changes=[]
    for name,before in old['installed_bindings'].items():
        current=sha(raw(Path(name)));expected=reviewed.get(name,before);need(current==expected,'UNREVIEWED_BOUND_INPUT_CHANGE: '+name);reconciled[name]=current
        if current!=before:changes.append(dict(path=name,original_sha256=before,reviewed_successor_sha256=current))
    need(len(changes)==6,'EXPECTED_SIX_REVIEWED_CHANGES_REQUIRED')
    release=repo/'data/runtime/hilega-closed-releases'/RELEASE;manifest_bytes=raw(release/'RELEASE-MANIFEST.json');need(sha(manifest_bytes)==RELEASE,'RELEASE_MANIFEST_CHANGED');manifest=json.loads(manifest_bytes)
    for n,h in manifest['files'].items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts and sha(raw(release/rel))==h,'SEALED_RELEASE_CHANGED')
    actual=set()
    for p in release.rglob('*'):
        need(not p.is_symlink(),'RELEASE_SYMLINK')
        if p.is_file():actual.add(p.relative_to(release).as_posix())
    need(actual==set(manifest['files'])|{'RELEASE-MANIFEST.json'},'UNMANIFESTED_RELEASE_FILE')
    for n,h in OBSERVER.items():need(sha(raw(repo/'hilega_policy_live'/n))==h,'OBSERVER_SOURCE_CHANGED');reconciled[str(repo/'hilega_policy_live'/n)]=h
    receipts={
        'worker_repair':repair_folder/'bytecode-install-transaction-71sccd6_/RESULT.json',
        'observer_install':repo/'hilega-native-observer-transition-plan-zgqgq4hn/observer-install-transaction-m0377j89/RESULT.json',
        'observer_routing_review':repo/'hilega-native-observer-review-afpyvd77/RESULT.json'}
    proofs={name:load(p) for name,p in receipts.items()};need(proofs['worker_repair']['status']=='NATIVE_PREPARATION_RUNNING_PAUSED' and proofs['worker_repair']['migration_receipt_preserved'] is True,'REPAIR_PROOF_REQUIRED');need(proofs['observer_install']['status']=='NATIVE_OBSERVER_INSTALLED_STOPPED' and proofs['observer_install']['observer_history_preserved'] is True,'OBSERVER_INSTALL_PROOF_REQUIRED');need(proofs['observer_routing_review']['historical_minute_coverage_complete'] is True and not proofs['observer_routing_review']['failures'],'OBSERVER_REVIEW_PROOF_REQUIRED')
    app=repo/'data/research/hilega-production-workspace/sim.sqlite';need(app.is_file() and not any(p.is_symlink() for p in (app,*app.parents)),'REGULAR_APPLICATION_DB_REQUIRED')
    with sqlite3.connect(app.as_uri()+'?mode=ro',uri=True) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN');control=json.loads(db.execute('SELECT data FROM control WHERE id=1').fetchone()[0]);route=json.loads(db.execute('SELECT data FROM preparation_route WHERE id=1').fetchone()[0]);cursor=json.loads(db.execute('SELECT data FROM preparation_source WHERE id=1').fetchone()[0]);migration=json.loads(db.execute('SELECT data FROM hilega_native_source_transition_v1 WHERE id=1').fetchone()[0])
    need(control['mode']=='PAUSED' and control['production_execution_enabled'] is False and control['simulation_only'] is True and route['route']=='PREPARATION_ONLY','PAUSED_CLOSED_REQUIRED');need(sha(encoded(migration))==repair['migration_receipt_sha256'] and cursor['sequence']>=repair['preserved_cursor']['sequence'],'MIGRATION_RECEIPT_OR_CURSOR_CHANGED')
    audit=Path(tempfile.mkdtemp(prefix='hilega-native-readiness-record-',dir=repo));audit.chmod(0o700);print('AUDIT: '+str(audit),flush=True)
    environment=dict(PATH=os.defpath,LANG='C.UTF-8',HOME=str(audit),PYTHONDONTWRITEBYTECODE='1')
    process=subprocess.run([sys.executable,'-B','-c',WARMUP,str(repo)],cwd=repo,env=environment,capture_output=True,text=True,timeout=180);save(audit/'WARMUP-PROCESS.json',dict(exit_code=process.returncode,stdout=process.stdout,stderr=process.stderr));need(process.returncode==0,'CACHE_ONLY_WARMUP_CHECK_FAILED: '+str(audit));warmup=json.loads(process.stdout);save(audit/'NATIVE-WARMUP.json',warmup)
    process=subprocess.run([sys.executable,'-B',str(repo/'hilega-operational-lifecycle-tools-6cexrur_/cli.py'),'check','--repo',str(repo)],cwd=repo,env=environment,capture_output=True,text=True,timeout=60);save(audit/'PACKAGE-CHECK.json',dict(exit_code=process.returncode,stdout=process.stdout,stderr=process.stderr));need(process.returncode==0 and json.loads(process.stdout)['status']=='PACKAGE_AND_RUNTIME_CHECK_PASS','PACKAGE_CHECK_FAILED')
    # Read only the public observer status file. A connected stream is not qualification.
    observer=load(repo/'data/live-observation/hilega-strike-observation-v1/collector-status.json');public={k:observer.get(k) for k in ('timestamp','status','observation_only','execution_enabled','stream_connected','cached_instruments','pending_entries','dropped_feed_messages')};need(public['observation_only'] is True and public['execution_enabled'] is False,'OBSERVER_NOT_CLOSED')
    for name,h in reconciled.items():need(sha(raw(Path(name)))==h,'BOUND_INPUT_CHANGED_DURING_RECORD')
    save(audit/'RECONCILED-BINDINGS.json',reconciled)
    evidence={name:dict(path=str(path),sha256=sha(raw(path))) for name,path in receipts.items()}
    report=dict(status='SUCCESSOR_HISTORICAL_READINESS_EVIDENCE_RECORDED',created_at=datetime.now(timezone.utc).isoformat(),repo=str(repo),original_plan=str(plan_path),original_plan_sha256=ORIGINAL,original_plan_modified=False,reviewed_binding_changes=changes,release_sha256=RELEASE,sealed_release_verified=True,receipts=evidence,reconciled_bindings_sha256=sha(raw(audit/'RECONCILED-BINDINGS.json')),native_warmup_sha256=sha(raw(audit/'NATIVE-WARMUP.json')),target_session=warmup['target_session'],native_warmup_sessions=warmup['coverage']['seed_sessions'],native_warmup_indicator_ready=warmup['indicator_warmup_ready'],cursor_sequence_observed=cursor['sequence'],migration_receipt_preserved=True,observer_status_snapshot=public,official_calendar_reverified=False,live_source_and_quote_qualification_complete=False,real_enrollment_or_activation_complete=False,legacy_maintenance_plan_reapproved=False,controller_paused_observed=True,services_changed=False,live_files_modified=False,production_execution_enabled=False,production_ready=False)
    save(audit/'RESULT.json',report);print(json.dumps(dict(status=report['status'],result=str(audit/'RESULT.json'),result_sha256=sha(raw(audit/'RESULT.json')),reconciled_binding_changes=len(changes),native_warmup_sessions=report['native_warmup_sessions'],native_warmup_indicator_ready=True,original_plan_modified=False,legacy_maintenance_plan_reapproved=False,live_source_and_quote_qualification_complete=False,production_execution_enabled=False,production_ready=False),indent=2))
if __name__=='__main__':
    try:main()
    except Exception as e:
        print(json.dumps(dict(status='READINESS_RECORD_BLOCKED',reason=str(e) if type(e) is ValueError else type(e).__name__,production_execution_enabled=False)));raise SystemExit(2)
