import math,json
from datetime import date,datetime,timezone
from zoneinfo import ZoneInfo
INDEX='NSE_INDEX|Nifty 50';IST=ZoneInfo('Asia/Kolkata')
def need(ok,code):
    if not ok:raise ValueError(code)
def positive(v):return type(v) in (int,float) and math.isfinite(v) and v>0
def stamp(v):
    if isinstance(v,str) and not v.isdigit():
        t=datetime.fromisoformat(v.replace('Z','+00:00'));need(t.tzinfo is not None and t.utcoffset() is not None,'NAIVE_QUOTE_TIMESTAMP_REJECTED');return t
    need(type(v) in (int,float,str) and not isinstance(v,bool),'QUOTE_TIMESTAMP_REQUIRED')
    n=float(v);need(math.isfinite(n) and 1e12<=n<1e14,'EPOCH_MILLISECONDS_REQUIRED');return datetime.fromtimestamp(n/1000,timezone.utc)
def quote_map(body,keys):
    need(isinstance(body,dict) and body.get('status')=='success' and isinstance(body.get('data'),dict),'QUOTE_RESPONSE_SCHEMA_REQUIRED');out={}
    for q in body['data'].values():
        need(isinstance(q,dict),'QUOTE_ROW_SCHEMA_REQUIRED');k=q.get('instrument_token')
        need(k in keys and k not in out,'QUOTE_IDENTITY_OR_DUPLICATE_ERROR');out[k]=q
    need(set(out)==set(keys),'QUOTE_COVERAGE_INCOMPLETE');return out

def basket(contracts,spot,today,selector=None):
    if selector is not None:
        selected=selector(contracts,spot,[-2,-1,0,1,2],1,today)
        result={}
        for row in selected['contracts']:
            key=row['instrument_key'];matches=[c for c in contracts if c.get('instrument_key')==key]
            need(len(matches)==1,'NATIVE_CONTRACT_IDENTITY_AMBIGUOUS');c=matches[0]
            need(key not in result,'DUPLICATE_NATIVE_CONTRACT')
            result[key]={k:c[k] for k in ('instrument_key','expiry','strike_price','instrument_type','lot_size','underlying_key','minimum_lot','freeze_quantity','tick_size')}
            result[key].update(offset=row['offset'],quantity=row['quantity'],atm_tie_rule=selected['atm_tie_rule'])
        need(len(result)==10,'TEN_NATIVE_CONTRACTS_REQUIRED');return result
    need(positive(spot),'POSITIVE_INDEX_PRICE_REQUIRED');lookup={}
    for c in contracts:
        if not isinstance(c,dict) or c.get('underlying_key')!=INDEX or c.get('exchange')!='NSE' or c.get('segment')!='NSE_FO' or c.get('instrument_type') not in {'CE','PE'}:continue
        if date.fromisoformat(c['expiry'])<today:continue
        need(positive(c.get('strike_price')) and type(c.get('lot_size')) is int and c['lot_size']>0,'VALID_CONTRACT_METADATA_REQUIRED')
        need(isinstance(c.get('instrument_key'),str) and c['instrument_key'].startswith('NSE_FO|'),'VALID_CONTRACT_KEY_REQUIRED')
        key=(c['expiry'],c['strike_price'],c['instrument_type']);need(key not in lookup,'AMBIGUOUS_CONTRACT');lookup[key]=c
    need(bool(lookup),'CURRENT_CONTRACTS_REQUIRED');expiry=min(k[0] for k in lookup)
    strikes=sorted({k[1] for k in lookup if k[0]==expiry and (expiry,k[1],'CE') in lookup and (expiry,k[1],'PE') in lookup})
    need(len(strikes)>=5,'FIVE_PAIRED_STRIKES_REQUIRED');i=min(range(len(strikes)),key=lambda i:(abs(strikes[i]-spot),-strikes[i]));need(i>=2 and i+2<len(strikes),'ATM_TWO_NEIGHBOURS_REQUIRED')
    result={}
    for strike in strikes[i-2:i+3]:
        for side in ('CE','PE'):
            c=lookup[expiry,strike,side];key=c['instrument_key'];need(key not in result,'DUPLICATE_CONTRACT_KEY');result[key]={k:c[k] for k in ('instrument_key','expiry','strike_price','instrument_type','lot_size','underlying_key')}
    return result

def decode(message,metadata):
    if isinstance(message,str):message=json.loads(message)
    need(isinstance(message,dict),'STREAM_MESSAGE_SCHEMA_REQUIRED')
    feeds=message.get('feeds')
    if not isinstance(feeds,dict) or not feeds:return {}
    at=stamp(message.get('currentTs'));rows={}
    for key,feed in feeds.items():
        if key not in metadata or not isinstance(feed,dict):continue
        full=feed.get('fullFeed') or {};body=full.get('marketFF') or {};ltpc=body.get('ltpc') or {};levels=(body.get('marketLevel') or {}).get('bidAskQuote') or [];depth=levels[0] if levels and isinstance(levels[0],dict) else {}
        rows[key]=dict(**metadata[key],ltp=number(ltpc.get('ltp')),bid=number(depth.get('bidP')),ask=number(depth.get('askP')),bid_quantity=number(depth.get('bidQ')),ask_quantity=number(depth.get('askQ')),feed_timestamp=at.isoformat(),last_trade_timestamp=ltpc.get('ltt'),timestamp_basis='UPSTOX_FEED_MESSAGE_TIME')
    return rows

def valid(q,now):
    try:age=(now-stamp(q.get('feed_timestamp'))).total_seconds()
    except (ValueError,TypeError,OverflowError):return False
    return 0<=age<=10 and all(positive(q.get(k)) for k in ('ltp','bid','ask','bid_quantity','ask_quantity')) and q['bid']<=q['ask']


def number(value):
    if isinstance(value,bool):return None
    try:value=float(value)
    except (ValueError,TypeError):return None
    return value if math.isfinite(value) and value>0 else None


def session_preflight(now,minimum_seconds=0):
    """Clock window only; this is not an exchange-holiday calendar check."""
    from datetime import time as walltime
    need(now.tzinfo is not None and now.utcoffset() is not None,'AWARE_SESSION_CLOCK_REQUIRED')
    local=now.astimezone(IST);start=datetime.combine(local.date(),walltime(9,15),tzinfo=IST);end=datetime.combine(local.date(),walltime(15,30),tzinfo=IST)
    reason='OPEN_CLOCK_WINDOW'
    if local.weekday()>=5:reason='WEEKEND'
    elif local<start:reason='BEFORE_SESSION_OPEN'
    elif local>=end:reason='AFTER_SESSION_CLOSE'
    elif (end-local).total_seconds()<minimum_seconds:reason='INSUFFICIENT_SESSION_TIME_FOR_VALIDATION'
    return dict(status=reason,clock_window_open=reason=='OPEN_CLOCK_WINDOW',assessed_at_ist=local.isoformat(),session_open_ist=start.isoformat(),session_close_ist=end.isoformat(),minimum_remaining_seconds=minimum_seconds,exchange_holiday_calendar_verified=False)
