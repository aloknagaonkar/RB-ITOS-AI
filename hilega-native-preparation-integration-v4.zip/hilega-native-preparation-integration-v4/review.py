"""Build disposable candidate from exact sealed payload and run actual Source guard tests."""
import argparse,ast,hashlib,importlib.util,json,os,subprocess,sys,tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
SOURCE='backend/market_lab/hilega_preparation_runtime_v1/source.py'
GUARD='backend/market_lab/hilega_exclusive_closed_route_v1.py'
NATIVE='backend/market_lab/hilega_native_preparation_contract_v1.py'
WORKER='runtime/worker_binding.py'

def need(ok,reason):
    if not ok:raise ValueError(reason)
def raw(p):
    need(not any(q.is_symlink() for q in (p,*p.parents)),'SYMLINK_REJECTED');return p.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def verify(package):
    for n,h in json.loads(raw(package/'MANIFEST.json')).items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts,'UNSAFE_PACKAGE_PATH');need(sha(raw(package/rel))==h,'PACKAGE_CHANGED')
def patch(text,old,new):
    need(text.count(old)==1,'EXACT_PATCH_SITE_REQUIRED');return text.replace(old,new)
def main():
    a=argparse.ArgumentParser();a.add_argument('--repo',type=Path,required=True);args=a.parse_args();repo=args.repo.resolve();verify(HERE)
    contract=repo/'hilega-native-preparation-contract-v1';transition=repo/'hilega-native-cursor-transition-v1';reader_package=repo/'hilega-source-reader-candidate-v3'
    for package in (contract,transition,reader_package):verify(package)
    plan=repo/'hilega-reader-install-preparation-w3lwp_la/INSTALLATION.json';need(sha(raw(plan))=='1fc67abdd3784899480bbb3a0f071aec4e3ddef811dcc61e4f2cd6a60568e762','INSTALLATION_PLAN_CHANGED');v=json.loads(raw(plan));base=Path(v['candidate'])
    mb=raw(base/'RELEASE-MANIFEST.json');need(sha(mb)==v['candidate_release_sha256'],'BASE_MANIFEST_CHANGED');manifest=json.loads(mb)
    audit=Path(tempfile.mkdtemp(prefix='hilega-native-transition-review-',dir=repo));audit.chmod(0o700);stage=audit/'candidate';stage.mkdir(mode=0o700)
    for n,h in manifest['files'].items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts,'UNSAFE_RELEASE_PATH');b=raw(base/rel);need(sha(b)==h,'BASE_FILE_CHANGED');p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True,mode=0o700);p.write_bytes(b);p.chmod(0o600)
    updates={}
    text=raw(stage/SOURCE).decode();text=patch(text,'from market_lab.hilega_production_simulator_bridge_v1 import verified_records,accepted,POLICY,VERSION','from market_lab.hilega_production_simulator_bridge_v1 import verified_records\nfrom market_lab.hilega_native_preparation_contract_v1 import accepted,POLICY,VERSION');updates[SOURCE]=text.encode()
    guard=raw(stage/GUARD).decode();tree=ast.parse(guard);nodes=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='STAGED_SOURCE_SHA256' for t in n.targets)];need(len(nodes)==1,'SOURCE_GUARD_PIN_REQUIRED');node=nodes[0];need(ast.literal_eval(node.value)==sha(raw(stage/SOURCE)),'ORIGINAL_SOURCE_GUARD_PIN_MISMATCH');guard=patch(guard,ast.get_source_segment(guard,node.value),repr(sha(updates[SOURCE])));updates[GUARD]=guard.encode()
    text=raw(contract/'contract.py').decode();text=patch(text,'class ContractBlocked(ValueError):pass','from .hilega_preparation_runtime_v1.evidence import Blocked as ContractBlocked');updates[NATIVE]=text.encode()
    text=raw(stage/WORKER).decode();text=patch(text,'from market_lab.hilega_production_simulator_bridge_v1 import verified_records,POLICY,VERSION','from market_lab.hilega_production_simulator_bridge_v1 import verified_records\n    from market_lab.hilega_native_preparation_contract_v1 import POLICY,VERSION');updates[WORKER]=text.encode()
    dependency='backend/market_lab/hilega_preparation_runtime_v1/dependencies.json';deps=json.loads(raw(stage/dependency));need(deps[WORKER]==sha(raw(stage/WORKER)),'WORKER_DEPENDENCY_PIN_MISMATCH')
    for n in (SOURCE,GUARD,NATIVE,WORKER):deps[n]=sha(updates[n])
    updates[dependency]=(json.dumps(deps,indent=2)+'\n').encode()
    for n,b in updates.items():
        if n.endswith('.py'):ast.parse(b)
        p=stage/n;p.write_bytes(b);p.chmod(0o600)
    files=dict(manifest['files']);files.update({n:sha(b) for n,b in updates.items()});candidate_manifest=dict(manifest,files=files,native_preparation_candidate=True,production_execution_enabled=False)
    (stage/'RELEASE-MANIFEST.json').write_text(json.dumps(candidate_manifest,indent=2)+'\n');(stage/'RELEASE-MANIFEST.json').chmod(0o600)
    # Snapshot verified journal records into a disposable journal. Never append to the real journal.
    sys.path.insert(0,str(contract));spec=importlib.util.spec_from_file_location('contract_reader_review',contract/'review.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    journal=repo/'data/live-observation/hilega-directional-v1/step-audit.jsonl'
    with m.reader(reader_package/'candidate.py')(journal) as records,(audit/'fixture-journal.jsonl').open('w') as out:
        for row in records:out.write(json.dumps(row)+'\n')
    (audit/'fixture-journal.jsonl').chmod(0o600)
    backup=repo/'hilega-reader-install-preparation-w3lwp_la/installer-transaction-p5bt03s9/application_db.sqlite';backup_sha=sha(raw(backup))
    env=dict(PATH=os.defpath,LANG='C.UTF-8',HOME=str(audit),PYTHONDONTWRITEBYTECODE='1',HILEGA_PRODUCTION_EXECUTION_ROUTE='PREPARATION_ONLY',HILEGA_PRODUCTION_WORKSPACE_MODE='SIMULATION_ONLY',HILEGA_PRODUCTION_SIM_BRIDGE_ENABLED='0',HILEGA_PREPARATION_CAPTURE_ON_SIGNAL='0',HILEGA_PREPARATION_ADAPTER_DB=str(audit/'UNUSED-ADAPTER.sqlite'))
    print('AUDIT: '+str(audit),flush=True)
    run=subprocess.run([sys.executable,'-B',str(HERE/'runner.py'),'--release',str(stage),'--audit',str(audit),'--backup',str(backup),'--transition-package',str(transition)],cwd=audit,env=env,capture_output=True,text=True,timeout=300)
    (audit/'PROCESS.json').write_text(json.dumps(dict(exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr),indent=2));print(run.stdout);print(run.stderr)
    need(sha(raw(backup))==backup_sha,'SAVED_BACKUP_CHANGED')
    for n,h in manifest['files'].items():need(sha(raw(base/n))==h,'SEALED_BASE_CHANGED')
    for n,h in files.items():need(sha(raw(stage/n))==h,'CANDIDATE_CHANGED_DURING_TEST')
    (audit/'CANDIDATE-CHANGES.json').write_text(json.dumps(dict(changed_files={n:dict(before=manifest['files'].get(n),after=sha(b)) for n,b in updates.items()},candidate_manifest_sha256=sha(raw(stage/'RELEASE-MANIFEST.json')),live_apply_available=False),indent=2))
    need(run.returncode==0,'ACTUAL_SOURCE_INTEGRATION_BLOCKED: '+str(audit))
if __name__=='__main__':main()
