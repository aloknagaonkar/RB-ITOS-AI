# Native preparation integration candidate v4

Disposable rehearsal only. No install or systemd commands. No credentials or live database access.

Builds a new candidate by copying all manifest-listed reader-successor files. Source imports the reviewed native event adapter, with its exceptions mapped to existing preparation Blocked. The exact source-content pin in the exclusive guard is updated to the new source hash; the guard's behavior is not relaxed. Worker heartbeat selection uses native policy identity. Updated dependency declarations explicitly bind the new adapter/source/guard and changed heartbeat wrapper. Legacy simulator policy code remains frozen and is not relabeled as native RSI. Full CLI/startup integration remains pending.

The runner uses the actual Source, exclusive_source_guard, closed_poll, controller Service and SimBroker on new disposable copies of the saved backup. It applies the explicit rehearsal transition to the disposable journal tail, then appends synthetic events only to the disposable journal. Scenarios: history no dispatch, paused entry plus repeated poll, fresh entry with deliberately unavailable evidence, stale, future, entry cutoff, and wrong native version. Some fixtures reconcile/resume the disposable controller only; no live controller is resumed. All finish paused. Network connections are denied and no tokens are provided. No changes to _entry or its risk/evidence checks are made.

This qualifies the tested Source guards only, not signed evidence-to-plan creation, ownership/authority, exit dispatch, full worker CLI, managed runtime health, or production execution. A pass does not authorize a live cursor migration. Capture actual VM output for review. Behavioral tests have not been run locally; only static AST/ZIP checks.

V2 corrects the fixture lifecycle: each disposable database uses native worker_lock, claim, heartbeat and finish. The copied STOPPED health is replaced through the real lease API before synthetic reconcile/resume. Heartbeat/source timestamps are explicit synthetic fixture times, not claims about the real market or real-journal freshness. The controller health gate, Source and entry controls are not bypassed or patched.

V3 extends the fixture with actual CLI two-start verification, closed EXIT and reversal refusal with replay checks, and a synthetic signed evidence-to-unsent-plan case. Synthetic signatures are not broker attestation. Special live ownership exits and managed service startup remain unqualified. Signed fixture validation fails closed on any dependency/schema mismatch; no risk gates are replaced.

V4 corrects only the fixture assertion: dispatch lookup uses the deterministic ID of the newly appended exit, checks its sequence/time, expects exactly one added dispatch, and verifies all historical dispatch row bytes are unchanged. Production candidate assembly and risk controls are unchanged. Earlier exit assertions selected the first historical row and were insufficient.
