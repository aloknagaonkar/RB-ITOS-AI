# Native bytecode forward repair installer

Run manage.py --repo "$PWD" --action check first. Check is read-only against live state and runs nine filesystem transaction scenarios on disposable paths. It binds repair plan 4c589f..., the VM pause-recovery receipt, current stopped-source state, exact committed cursor and receipt, cache inventory, source files, supervision configuration and payloads. A check lasts 30 minutes and prints CHECK.json plus SHA256. No live service changes occur during check.

Apply requires --action apply --check ABSOLUTE_CHECK_PATH --check-sha256 EXACT_SHA. It stops the managed writers and recovery service, verifies quiescence, backs up both databases, quarantines only the 44 exact recorded caches, replaces the wrapper and recovery unit, installs bound recovery payload, starts native pause recovery and companions, and verifies two new source-worker heartbeats. The strict no-extra-file manifest check remains. The wrapper disables bytecode before sealed imports. No migration rerun or database restoration occurs. Source may advance its cursor while paused; the migration receipt remains unchanged and cursor regression is rejected.

On failure it attempts to restore the original launcher/unit, retain caches in quarantine, restart old pause recovery and companions and leave the source stopped. Unexpected conflicts stop recovery for review. Power-loss recovery and systemd orchestration are not claimed by filesystem rehearsal. No real enrollment, production execution, source freshness, owned-position exits or strategy admission is certified. Independent policy observer restoration is a subsequent observation-only step after managed runtime verification.

Only AST and ZIP structure checked locally. Behavioral checks must run on the VM. Do not rerun the original native migration.

V2 fixes omitted systemd ExecStart for an absent stopped quote observer. Managed units still require all configuration fields; changes remain blocked. Four schema cases run alongside the five filesystem cases. V1 failing checks made no live changes.
