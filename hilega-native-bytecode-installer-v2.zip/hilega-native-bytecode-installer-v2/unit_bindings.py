"""Compare systemd configuration fields; only an absent quote observer is optional."""
FIELDS=('FragmentPath','DropInPaths','ExecStart')
OBSERVER='hilega-quote-observer.service'
def compare_units(current,before):
    for name,value in current.items():
        if name not in before:raise ValueError('UNIT_BASELINE_MISSING: '+name)
        baseline=before[name]
        optional=(name==OBSERVER and value.get('MainPID')=='0' and baseline.get('MainPID')=='0'
                  and value.get('ActiveState')=='inactive' and baseline.get('ActiveState')=='inactive'
                  and not value.get('FragmentPath') and not baseline.get('FragmentPath'))
        for key in FIELDS:
            if optional:
                if value.get(key,'')!=baseline.get(key,''):raise ValueError('UNIT_CONFIGURATION_CHANGED: '+name+':'+key)
            else:
                if key not in value or key not in baseline:raise ValueError('REQUIRED_UNIT_PROPERTY_MISSING: '+name+':'+key)
                if value[key]!=baseline[key]:raise ValueError('UNIT_CONFIGURATION_CHANGED: '+name+':'+key)
