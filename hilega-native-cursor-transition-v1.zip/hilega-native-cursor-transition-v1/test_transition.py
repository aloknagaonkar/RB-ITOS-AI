import json,sqlite3,tempfile,unittest
from pathlib import Path
from transition import transition,TransitionBlocked
class Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='hilega-native-transition-review-');self.root=Path(self.temp.name);self.db=self.root/'app.sqlite';self.rows=[{'record_hash':'first'},{'record_hash':'last'}];self.journal=self.root/'fixture.jsonl'
        with sqlite3.connect(self.db) as db:
            for table in ('control','preparation_route','preparation_source'):db.execute('CREATE TABLE '+table+'(id INTEGER PRIMARY KEY,data TEXT)')
            for table,value in [('control',dict(mode='PAUSED',production_execution_enabled=False,simulation_only=True,version=7,session_date='2026-11-25')),('preparation_route',dict(route='PREPARATION_ONLY')),('preparation_source',dict(path='/original/journal',sequence=1,hash='first'))]:db.execute('INSERT INTO '+table+' VALUES(1,?)',(json.dumps(value),))
            db.execute('CREATE TABLE sim_stop_state(id INTEGER PRIMARY KEY,generation INTEGER,handled INTEGER)');db.execute('INSERT INTO sim_stop_state VALUES(1,0,0)')
            db.execute('CREATE TABLE preparation_plans(id TEXT PRIMARY KEY)')
    def tearDown(self):self.temp.cleanup()
    def apply(self,**kwargs):return transition(self.db,self.rows,self.journal,sandbox=self.root,**kwargs)
    def cursor(self):
        with sqlite3.connect(self.db) as db:return json.loads(db.execute('SELECT data FROM preparation_source WHERE id=1').fetchone()[0])
    def test_success_and_idempotent_restart(self):
        result=self.apply();self.assertEqual(result['receipt']['old_cursor']['sequence'],1);self.assertEqual(self.cursor()['sequence'],2);self.assertEqual(self.apply()['status'],'EXISTING_REHEARSAL_TRANSITION_VERIFIED')
    def test_faults_leave_cursor_and_schema_unchanged(self):
        before=self.cursor()
        for stage in ('AFTER_RECEIPT_INSERT','AFTER_CURSOR_UPDATE'):
            def fail(at):
                if at==stage:raise RuntimeError('INJECTED')
            with self.assertRaises(RuntimeError):self.apply(checkpoint=fail)
            self.assertEqual(self.cursor(),before)
            with sqlite3.connect(self.db) as db:self.assertIsNone(db.execute("SELECT name FROM sqlite_master WHERE name='native_source_transition_rehearsal'").fetchone())
    def test_modified_prefix_rejected(self):
        self.rows[0]['record_hash']='changed'
        with self.assertRaisesRegex(TransitionBlocked,'SOURCE_PREFIX_REPLACED'):self.apply()
    def test_truncation_rejected(self):
        self.rows=[]
        with self.assertRaises(TransitionBlocked):self.apply()
    def test_nonempty_plan_rejected(self):
        with sqlite3.connect(self.db) as db:db.execute("INSERT INTO preparation_plans VALUES('pending')")
        with self.assertRaisesRegex(TransitionBlocked,'EMPTY_PREPARATION_BASELINE_REQUIRED'):self.apply()
    def test_armed_database_rejected(self):
        with sqlite3.connect(self.db) as db:
            c=json.loads(db.execute('SELECT data FROM control WHERE id=1').fetchone()[0]);c['mode']='ARMED';db.execute('UPDATE control SET data=?',(json.dumps(c),))
        with self.assertRaisesRegex(TransitionBlocked,'PAUSED_CLOSED_REQUIRED'):self.apply()
    def test_conflicting_transition_rejected(self):
        self.apply();self.rows.append({'record_hash':'new'})
        with self.assertRaisesRegex(TransitionBlocked,'EXISTING_TRANSITION_CONFLICT'):self.apply()
    def test_outside_sandbox_rejected(self):
        with self.assertRaisesRegex(TransitionBlocked,'DISPOSABLE_SANDBOX_REQUIRED'):transition(self.db,self.rows,self.journal,sandbox=self.root/'wrong')
if __name__=='__main__':unittest.main()
