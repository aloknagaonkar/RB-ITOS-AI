"""REHEARSAL ONLY: atomic, audited native source baseline in disposable databases."""
import hashlib,json,sqlite3
from pathlib import Path
POLICY='RSI_TWO_ROUTE_CONFIRMED_MIDPOINT'
VERSION='rsi-two-route-1.0.0-3m-native-confirmed-midpoint'
MODEL='HILEGA_NATIVE_SOURCE_TRANSITION_REHEARSAL_V1'
class TransitionBlocked(ValueError):pass
def need(ok,reason):
    if not ok:raise TransitionBlocked(reason)
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def digest(value):return hashlib.sha256(canonical(value).encode()).hexdigest()
def transition(database,records,journal,*,sandbox,checkpoint=lambda stage:None):
    database=Path(database).absolute();sandbox=Path(sandbox).absolute();journal=Path(journal).absolute()
    need(sandbox.name.startswith('hilega-native-transition-review-') and database.is_relative_to(sandbox),'DISPOSABLE_SANDBOX_REQUIRED')
    need(database.is_file() and not any(p.is_symlink() for p in (database,*database.parents)),'REGULAR_EXISTING_DISPOSABLE_DATABASE_REQUIRED')
    need(len(records)>0,'VERIFIED_NONEMPTY_SNAPSHOT_REQUIRED')
    with sqlite3.connect(database,isolation_level=None) as db:
        db.execute('BEGIN IMMEDIATE')
        try:
            tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            c=json.loads(db.execute('SELECT data FROM control WHERE id=1').fetchone()[0])
            route=json.loads(db.execute('SELECT data FROM preparation_route WHERE id=1').fetchone()[0])
            need(c['mode']=='PAUSED' and c['production_execution_enabled'] is False and c['simulation_only'] is True and route['route']=='PREPARATION_ONLY','PAUSED_CLOSED_REQUIRED')
            stop=db.execute('SELECT generation,handled FROM sim_stop_state WHERE id=1').fetchone()
            need(stop and stop[0]==stop[1],'NO_PENDING_STOP_REQUIRED')
            for name in ('intents','sim_orders','sim_fills','sim_allocation_reservations','preparation_plans','preparation_shadow_holds','preparation_outbox','preparation_request_bindings','preparation_cash_reservations'):
                if name in tables:need(db.execute('SELECT 1 FROM '+name+' LIMIT 1').fetchone() is None,'EMPTY_PREPARATION_BASELINE_REQUIRED')
            row=db.execute('SELECT data FROM preparation_source WHERE id=1').fetchone();need(row is not None,'EXISTING_SOURCE_CURSOR_REQUIRED');old=json.loads(row[0])
            tail=dict(path=str(journal),sequence=len(records),hash=records[-1]['record_hash'])
            if 'native_source_transition_rehearsal' in tables:
                stored=json.loads(db.execute('SELECT data FROM native_source_transition_rehearsal WHERE id=1').fetchone()[0])
                need(stored['model']==MODEL and stored['policy_id']==POLICY and stored['strategy_version']==VERSION and stored['new_cursor']==tail and old==tail,'EXISTING_TRANSITION_CONFLICT')
                db.rollback();return dict(status='EXISTING_REHEARSAL_TRANSITION_VERIFIED',receipt=stored)
            sequence=old.get('sequence');need(type(sequence) is int and 0<=sequence<=len(records),'SOURCE_CHANGED_OR_TRUNCATED')
            need(sequence==0 or records[sequence-1]['record_hash']==old.get('hash'),'SOURCE_PREFIX_REPLACED')
            need(sequence!=0 or old.get('hash') is None,'EMPTY_CURSOR_HASH_INVALID')
            receipt=dict(model=MODEL,policy_id=POLICY,strategy_version=VERSION,old_cursor=old,new_cursor=tail,controller_version=c['version'],session_date=c['session_date'],historical_records_baselined=len(records)-sequence,entry_permission=False,production_execution_enabled=False,disposable_only=True)
            receipt['transition_id']=digest(receipt)
            db.execute('CREATE TABLE native_source_transition_rehearsal(id INTEGER PRIMARY KEY CHECK(id=1),data TEXT NOT NULL)')
            db.execute('INSERT INTO native_source_transition_rehearsal VALUES(1,?)',(canonical(receipt),));checkpoint('AFTER_RECEIPT_INSERT')
            db.execute('UPDATE preparation_source SET data=? WHERE id=1',(canonical(tail),));checkpoint('AFTER_CURSOR_UPDATE')
            db.execute('COMMIT');return dict(status='DISPOSABLE_NATIVE_SOURCE_TRANSITION_PASS',receipt=receipt)
        except BaseException:
            if db.in_transaction:db.rollback()
            raise
