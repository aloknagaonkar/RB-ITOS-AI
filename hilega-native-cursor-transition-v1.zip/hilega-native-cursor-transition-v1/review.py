"""Run transition tests and rehearse against a saved backup; never opens live databases."""
import argparse,hashlib,importlib.util,json,os,sqlite3,subprocess,sys,tempfile
from pathlib import Path
from transition import transition
HERE=Path(__file__).resolve().parent

def raw(path):
    if any(p.is_symlink() for p in (path,*path.parents)):raise ValueError('SYMLINK_REJECTED')
    return path.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def verify(folder):
    for n,h in json.loads(raw(folder/'MANIFEST.json')).items():
        rel=Path(n)
        if rel.is_absolute() or '..' in rel.parts or sha(raw(folder/rel))!=h:raise ValueError('PACKAGE_CHANGED')
def tables(path):
    result={}
    with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
        for (name,) in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
            quoted='"'+name.replace('"','""')+'"';rows=sorted(repr(tuple(r)) for r in db.execute('SELECT * FROM '+quoted));result[name]=sha('\n'.join(rows).encode())
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);a=p.parse_args();repo=a.repo.resolve();verify(HERE)
    contract=repo/'hilega-native-preparation-contract-v1';verify(contract)
    reader_package=repo/'hilega-source-reader-candidate-v3';verify(reader_package)
    if sha(raw(reader_package/'candidate.py'))!='427bb464bd921a86696ff1e1fc2b140c5ee5234e0e12e227ac9b5f3fb9b3c384':raise ValueError('REVIEWED_READER_CHANGED')
    sys.path.insert(0,str(contract));spec=importlib.util.spec_from_file_location('native_contract_review',contract/'review.py');loader=importlib.util.module_from_spec(spec);spec.loader.exec_module(loader)
    source=repo/'hilega-reader-install-preparation-w3lwp_la/installer-transaction-p5bt03s9/application_db.sqlite';before_hash=sha(raw(source))
    audit=Path(tempfile.mkdtemp(prefix='hilega-native-transition-review-',dir=repo));audit.chmod(0o700)
    env=dict(PATH=os.defpath,LANG='C.UTF-8',HOME=str(audit),PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(audit))
    test=subprocess.run([sys.executable,'-B','-m','unittest','-v','test_transition'],cwd=HERE,env=env,capture_output=True,text=True,timeout=60)
    (audit/'TEST-PROCESS.json').write_text(json.dumps(dict(exit_code=test.returncode,stdout=test.stdout,stderr=test.stderr),indent=2));print(test.stdout+test.stderr,flush=True)
    if test.returncode:raise ValueError('TRANSITION_TEST_FAILED: '+str(audit))
    db_path=audit/'application.sqlite'
    with sqlite3.connect(source.as_uri()+'?mode=ro',uri=True) as src,sqlite3.connect(db_path) as dst:src.backup(dst)
    db_path.chmod(0o600);before=tables(db_path)
    with sqlite3.connect(db_path.as_uri()+'?mode=ro',uri=True) as db:old=json.loads(db.execute('SELECT data FROM preparation_source WHERE id=1').fetchone()[0])
    journal=repo/'data/live-observation/hilega-directional-v1/step-audit.jsonl'
    if old['path']!=str(journal):raise ValueError('SAVED_SOURCE_PATH_CHANGED')
    faults=[]
    with loader.reader(reader_package/'candidate.py')(journal) as records:
        for stage in ('AFTER_RECEIPT_INSERT','AFTER_CURSOR_UPDATE'):
            def fail(at):
                if at==stage:raise RuntimeError('INJECTED_TRANSITION_INTERRUPTION')
            try:transition(db_path,records,journal,sandbox=audit,checkpoint=fail)
            except RuntimeError:pass
            else:raise ValueError('FAULT_NOT_TRIGGERED')
            if tables(db_path)!=before:raise ValueError('REAL_BACKUP_TRANSITION_NOT_ROLLED_BACK')
            faults.append(stage)
        result=transition(db_path,records,journal,sandbox=audit)
        repeated=transition(db_path,records,journal,sandbox=audit)
    after=tables(db_path)
    if set(after)!=set(before)|{'native_source_transition_rehearsal'}:raise ValueError('UNEXPECTED_SCHEMA_CHANGE')
    if any(after[name]!=h for name,h in before.items() if name!='preparation_source'):raise ValueError('UNRELATED_DATABASE_STATE_CHANGED')
    if sha(raw(source))!=before_hash:raise ValueError('SAVED_BACKUP_CHANGED')
    report=dict(status='DISPOSABLE_NATIVE_CURSOR_TRANSITION_PASS',audit=str(audit),saved_backup_sha256=before_hash,old_sequence=old['sequence'],new_sequence=result['receipt']['new_cursor']['sequence'],historical_records_baselined=result['receipt']['historical_records_baselined'],transition_id=result['receipt']['transition_id'],faults_rolled_back=faults,repeated_transition_status=repeated['status'],original_tables_preserved_except_cursor=True,live_database_opened=False,live_cursor_modified=False,installed_sources_modified=False,services_changed=False,signals_executed=False,preparation_integration_verified=False,production_execution_enabled=False,live_apply_available=False)
    (audit/'TRANSITION-RECEIPT.json').write_text(json.dumps(result['receipt'],indent=2));(audit/'RESULT.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
