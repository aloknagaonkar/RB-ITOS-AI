# Native cursor transition rehearsal v1

REHEARSAL ONLY. This package refuses database targets outside a dedicated hilega-native-transition-review-* directory. Do not copy its rehearsal table into live state or edit the live cursor manually.

The explicit candidate transition checks the existing paused/closed control and route, handled stop generation, no pending plans/orders/holds/requests, and the saved cursor hash against a fully verified journal snapshot. One SQLite transaction records the old cursor and new tail, policy/version and controller version, then updates the disposable cursor. Faults after receipt insertion and after cursor update must roll back schema and cursor together. Repeated identical transition is idempotent; conflicting transitions reject.

review.py runs eight synthetic tests on the VM and repeats both interruption tests against a disposable copy of the saved pre-install backup. The saved backup is read-only, live databases are never opened. All original table contents except the disposable cursor must remain identical. Full journal chain verification uses the previously reviewed bounded reader. No old event is dispatched; the transition records the historical interval being baselined explicitly rather than labeling it processed/executed.

This validates a proposed transition mechanism, NOT a deployed migration, fresh-signal preparation, strategy ownership, risk policy, special exchange session handling or live qualification. Integration into the actual sealed Source and its guards remains pending. A later live plan must independently bind its own current cursor, controller state and journal tail under writer quiescence; this rehearsal receipt cannot authorize live cursor changes.

Only static syntax/ZIP inspection was performed locally. Behavioral tests are for the VM.
