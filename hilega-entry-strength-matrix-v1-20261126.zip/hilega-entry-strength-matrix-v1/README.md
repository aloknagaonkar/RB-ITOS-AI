# Every-entry moderate-strength matrix

Research only. Compare each of seven existing configurations with and without:

- Body >= 50% of completed 3m candle range.
- Each wick <= body.
- CE upper wick / PE lower wick <= 20% of range.
- Original colour, RSI, WMA/route and EMA30 gates still apply.

Default date is 6 November 2026. Run from the application repository root:

    .venv/bin/python -u -B hilega-entry-strength-matrix-v1/run.py --days 2026-11-06

Multiple prior sessions can be passed after --days. Incomplete/current sessions are rejected. This does not add RSI-only exits, zones or follow-ups to configurations that do not already have them. Each configuration keeps its own entry framework and exit rules. In confirmation configurations the actual follow-up entry candle also passes the universal strength test; existing setup strength requirements remain.

The seven base policies are current strategy, RSI exit only, RSI exit + EMA zones, strict/moderate confirmation outside zones, and strict/moderate allowing confirmed zone entries. Direct entries are filtered too. No live source file or global strategy evaluator is modified; engines are separate in-memory namespaces.

Inputs: fresh target history, with exact full-session validation. If fresh history is unavailable/incomplete, the runner can use validated same-day raw data from existing caches or previous research inputs, recording its path and hash. No padding, interpolation or replay-result cache reuse. Twenty reviewed prior sessions are read or recovered into the run's own research directory.

Outputs: index.html with paired comparison and trade filters, daily full 3m audits, trades.csv, per-day comparison.json, source/candle hashes and an upload ZIP. Results are NIFTY reference points, not option premiums or actual fills; fees/slippage excluded. A blocked opposite entry can change reversal timing and later ownership, so net effects are assessed through complete replay rather than simply removing losing rows.

Validation: mirrored moderate-strength unit checks; inherited strict/moderate confirmation tests; synthetic integration verifies all seven unfiltered policies accept a direct eligible weak candle while the paired filtered policy rejects it, without altering the original evaluator. Market results require the VM run.

The package changes no application code, .env, existing candle caches, journals, controls, services or orders. It writes only its own data/research output and makes read-only market-data requests.
