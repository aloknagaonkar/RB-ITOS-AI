#!/usr/bin/env python3
"""Compare seven policies with/without moderate strength on every entry.
Research only; no installed code, services, controls, existing caches or orders changed.
"""
import argparse,copy,csv,hashlib,html,importlib.util,json,os,sys,zipfile
from datetime import date,datetime
from pathlib import Path
HERE=Path(__file__).resolve().parent
MODES=[('CURRENT_STRATEGY','current',None),('RSI_EXIT_ONLY','rsi',None),
 ('RSI_EXIT_EMA_ZONES','old',None),('STRICT_OUTSIDE_ZONES','old',(70,70,15,True)),
 ('MODERATE_OUTSIDE_ZONES','old',(50,60,20,False)),
 ('STRICT_ALLOW_CONFIRMED_ZONE_ENTRIES','inside',(70,70,15,True)),
 ('MODERATE_ALLOW_CONFIRMED_ZONE_ENTRIES','inside',(50,60,20,False))]

def file_hash(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load_module(p,name):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def strength(f):
 o,h,l,c=(f[k] for k in ('open','high','low','close'));b=abs(c-o);span=h-l;u=h-max(o,c);w=min(o,c)-l;eps=1e-9
 return dict(body=b,span=span,upper=u,lower=w,valid=span>0 and l<=min(o,c)<=max(o,c)<=h,
             eps=eps)

def entry_filter(evaluator):
 def evaluate(f,side):
  ev=evaluator(f,side);s=strength(f);b,span,u,w=(s[k] for k in ('body','span','upper','lower'));eps=s['eps']
  checks=dict(valid_candle=s['valid'],body_at_least_50pct=span>0 and b+eps>=.5*span,
              upper_wick_not_above_body=u<=b+eps,lower_wick_not_above_body=w<=b+eps,
              adverse_wick_at_most_20pct=span>0 and (u if side=='CE' else w)<=.2*span+eps)
  ev['route_before_entry_strength']=ev['selected_route']
  ev['moderate_entry_strength']=dict(checks=checks,body_pct=100*b/span if span>0 else None,
                                    upper_wick_pct=100*u/span if span>0 else None,
                                    lower_wick_pct=100*w/span if span>0 else None)
  failed=[k for k,v in checks.items() if not v]
  for name,gates in ev['route_checks'].items():
   gates.update(checks)
   if failed:
    ev['eligible_routes'][name]=False;ev['route_blockers'][name].extend(failed)
  if failed:ev['selected_route']=None;ev['blockers']=list(ev['blockers'])+failed
  return ev
 return evaluate

def make_engine(original,h,inside,text,day,warm,kind,config,filtered):
 evaluator=entry_filter(original.evaluate_entry) if filtered else original.evaluate_entry
 if kind in ('current','rsi'):
  if kind=='current' and not filtered:return original.Engine(str(day),warm),None
  source=Path(original.__file__).read_text() if kind=='current' else text
  ns=dict(__name__=original.__package__+'.entry_matrix',__package__=original.__package__)
  exec(compile(source,'<entry-matrix>','exec'),ns);ns['evaluate_entry']=evaluator
  return ns['Engine'](str(day),warm),None
 h.Gate=inside.InsideGate if kind=='inside' else h._matrix_original_gate
 e,g=h.make_engine(original,text,day,warm,config);g.evaluator=evaluator
 return e,g

def self_test(h,inside):
 def ev(f,side):
  gates={'colour':f['close']>f['open'] if side=='CE' else f['close']<f['open']}
  return dict(selected_route='Normal Route' if all(gates.values()) else None,blockers=[],
   route_checks={'Normal Route':gates},eligible_routes={'Normal Route':all(gates.values())},route_blockers={'Normal Route':[]})
 for side,passing,failing in [('CE',(100,110,98,109),(100,115,98,109)),('PE',(109,110,98,100),(109,110,94,100))]:
  for values,expected in [(passing,True),(failing,False)]:
   f=dict(zip(('open','high','low','close'),values));result=entry_filter(ev)(f,side)
   assert (result['selected_route'] is not None)==expected
 f=dict(open=100,high=100,low=100,close=100)
 assert entry_filter(ev)(f,'CE')['selected_route'] is None
 inside.self_test(h)
 print('PASS: universal moderate entry body/wick filter in both directions; zero-range rejected; base entry evaluator unchanged.')

def main_html(root,pairs,trades,coverage):
 parts=['<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Every-entry strength comparison</title><style>body{font:14px/1.5 system-ui;background:#10232d;color:#e3edf2;margin:24px}h1,h2{color:#8de4c0}table{width:100%;border-collapse:collapse;white-space:nowrap}td,th{padding:10px;border-bottom:1px solid #3f5a67;text-align:right}td:first-child,th:first-child{text-align:left}th{background:#203947}.scroll{overflow:auto}select,button{padding:8px;background:#203947;color:white;border:1px solid #607b8b;margin:6px}a{color:#8dcfff}.pos{color:#8de4c0}.neg{color:#ff9c9c}pre{white-space:pre-wrap}@media print{body{background:white;color:black}.scroll{overflow:visible}select,button{display:none}}</style><h1>Moderate strength on every entry · seven paired comparisons</h1><p>Body ≥50% of range; each wick ≤body; CE upper wick / PE lower wick ≤20% of range. Colour, original RSI/EMA30/route gates and each configuration’s exit rules stay unchanged. A blocked opposite entry does not reverse the current trade. In confirmation variants the accepted follow-up also passes this universal entry filter; no new follow-up requirement is added to direct-entry variants.</p><p>All 14 runs per day share identical target candles and 20 verified seed sessions. Current strategy is the installed pure Engine, not executed-trade history. NIFTY points; option fills, fees and slippage excluded. No live changes.</p><div><label>Date <select id="day"><option value="">All dates</option></select></label><label>Configuration <select id="policy"><option value="">All seven</option></select></label><label>Direction <select id="side"><option value="">Both</option><option>CE</option><option>PE</option></select></label><label>Outcome <select id="outcome"><option value="">All</option><option>WIN</option><option>LOSS</option></select></label><button onclick="window.print()">Print / Save PDF</button></div><h2>Paired daily results</h2><div class="scroll"><table><tr><th>Date</th><th>Configuration</th><th>Base trades</th><th>Filtered trades</th><th>Base wins/losses</th><th>Filtered wins/losses</th><th>Base net</th><th>Filtered net</th><th>Net change</th><th>Base losing pts</th><th>Filtered losing pts</th><th>Loss reduction</th><th>Audit</th></tr><tbody id="pairs"></tbody></table></div><h2>Every entry / exit</h2><div class="scroll"><table><tr><th>Date</th><th>Configuration</th><th>Entry filter</th><th>Side</th><th>Route</th><th>Setup</th><th>Entry</th><th>Exit</th><th>Entry NIFTY</th><th>Exit NIFTY</th><th>Net</th><th>Outcome</th><th>Peak +</th><th>Giveback</th><th>Entry path</th><th>Exit reason</th></tr><tbody id="trades"></tbody></table></div><h2>Coverage</h2><pre>'+html.escape(json.dumps(coverage,indent=2))+'</pre><p>Paired totals use full daily outcomes; direction/outcome filters apply to the trade ledger only. Trade-count differences alone do not prove which individual losses were prevented: delayed entries, changed ownership and changed reversal timing can change later trades. Open each daily audit for both-direction 3m checks. Setup is original candle start. Peak sums are per-trade excursions, not simultaneous portfolio profit.</p><script>const D=PAYLOAD;const $=id=>document.getElementById(id),f=n=>Number(n).toFixed(2),sg=n=>(n>=0?"+":"")+f(n),cell=x=>"<td>"+x+"</td>";function options(id,values){values.forEach(v=>{const o=document.createElement("option");o.value=v;o.textContent=v;$(id).append(o)})}options("day",[...new Set(D.pairs.map(r=>r.day))]);options("policy",[...new Set(D.pairs.map(r=>r.policy))]);function render(){const ok=r=>(!$("day").value||r.day===$("day").value)&&(!$("policy").value||r.policy===$("policy").value);$("pairs").innerHTML=D.pairs.filter(ok).map(r=>"<tr>"+[r.day,r.policy,r.base.trades,r.filtered.trades,r.base.winners+"/"+r.base.losers,r.filtered.winners+"/"+r.filtered.losers,sg(r.base.net_points),sg(r.filtered.net_points),sg(r.net_change),f(r.base.gross_loss),f(r.filtered.gross_loss),sg(r.loss_reduction),"<a href=\\"days/"+r.day+"/audit.html\\">3m audit</a>"].map(cell).join("")+"</tr>").join("");$("trades").innerHTML=D.trades.filter(r=>ok(r)&&(!$("side").value||r.side===$("side").value)&&(!$("outcome").value||r.outcome===$("outcome").value)).map(r=>"<tr>"+[r.day,r.policy,r.entry_filter,r.side,r.route,r.setup,r.entry,r.exit,f(r.entry_price),f(r.exit_price),sg(r.net),r.outcome,f(r.peak),f(r.giveback),r.entry_path,r.reason].map(cell).join("")+"</tr>").join("")}for(const id of ["day","policy","side","outcome"])$(id).addEventListener("change",render);render();</script></html>']
 payload=json.dumps(dict(pairs=pairs,trades=trades),allow_nan=False).replace('<','\\u003c')
 (root/'index.html').write_text(''.join(parts).replace('PAYLOAD',payload))

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd());p.add_argument('--days',nargs='+',type=date.fromisoformat,default=[date(2026,11,6)]);p.add_argument('--self-test',action='store_true');a=p.parse_args()
 manifest=json.loads((HERE/'manifest.json').read_text())
 for name,sha in manifest['files'].items():
  if file_hash(HERE/name)!=sha:raise SystemExit('RESEARCH_FILE_HASH_MISMATCH:'+name)
 inside=load_module(HERE/'hilega-zone-entry-confirmation-v2-20261125.py','entry_matrix_inside')
 h=inside.load_helper(HERE/inside.HELPER);inside.InsideGate.helper=h;h._matrix_original_gate=h.Gate
 self_test(h,inside)
 if a.self_test:return
 repo=a.repo.resolve();os.chdir(repo);sys.path.insert(0,str(repo/'backend'))
 from dotenv import load_dotenv
 from market_lab.domain import IST
 from market_lab.hilega_rsi_two_route_v1 import engine as original
 from market_lab.hilega_rsi_two_route_v1.calendar import session_day,required_sessions,validate_rows,read_session
 from market_lab.hilega_rsi_two_route_v1.data import candidates,bars,digest
 from market_lab.upstox_live_shadow_sources_v1 import UpstoxLiveShadowSourcesV1
 text=h.load_engine(original);load_dotenv(repo/'.env');days=sorted(set(a.days))
 for d in days:
  if d>=datetime.now(IST).date():raise SystemExit('ONLY_COMPLETED_PRIOR_SESSIONS')
  if not session_day(d):raise SystemExit('NON_TRADING_SESSION:'+str(d))
 root=repo/'data/research'/('entry-strength-matrix-'+datetime.now(IST).strftime('%Y%m%dT%H%M%S%f'));(root/'inputs').mkdir(parents=True)
 source=UpstoxLiveShadowSourcesV1(os.environ.get('UPSTOX_ACCESS_TOKEN',''));memo={};evidence={};pairs=[];trades=[];coverage=[]
 def acquire(day,target=False):
  key=str(day)
  if key in memo and not target:return memo[key]
  rows=None;origin=None
  if target:
   print('  Fetch fresh target:',day,flush=True)
   try:
    items=source.historical_candles('NSE_INDEX|Nifty 50',day)
    raw=[dict(timestamp=c.timestamp.astimezone(IST).isoformat(),open=float(c.open),high=float(c.high),low=float(c.low),close=float(c.close),volume=getattr(c,'volume',None)) for c in sorted(items,key=lambda c:c.timestamp)]
    print('  Fetched candles:',len(raw),flush=True);rows=validate_rows(raw,day);origin='FRESH_BROKER_HISTORY'
   except Exception:pass
  paths=list(candidates(repo,day))
  paths+=sorted((repo/'data/research').glob('november-seven-configs-*/inputs/'+key+'.json'),reverse=True)
  paths+=sorted((repo/'data/research').glob('zone-entry-confirmation-*/inputs.json'),reverse=True)
  paths+=sorted((repo/'data/research').glob('zone-strength-*/inputs.json'),reverse=True)
  for path in paths:
   if rows is not None:break
   if not path.is_file():continue
   try:
    body=json.loads(path.read_text());raw=body.get('minutes') if 'minutes' in body else body.get('candles')
    if 'minutes' not in body and (body.get('session_date')!=key or body.get('underlying')!='NSE_INDEX|Nifty 50'):continue
    rows=validate_rows(raw,day);origin=str(path)
   except (OSError,ValueError,TypeError,KeyError):continue
  if rows is None:
   print('  Fetch missing warmup:',day,flush=True)
   try:items=source.historical_candles('NSE_INDEX|Nifty 50',day)
   except Exception as exc:raise ValueError('CANDLE_FETCH_FAILED:'+key+':'+type(exc).__name__) from None
   rows=validate_rows([dict(timestamp=c.timestamp.astimezone(IST).isoformat(),open=float(c.open),high=float(c.high),low=float(c.low),close=float(c.close),volume=getattr(c,'volume',None)) for c in sorted(items,key=lambda c:c.timestamp)],day);origin='FRESH_BROKER_HISTORY'
  memo[key]=rows;evidence[key]=dict(source=origin,sha256=digest(rows))
  (root/'inputs'/(key+'.json')).write_text(json.dumps(dict(session_date=key,underlying='NSE_INDEX|Nifty 50',candles=rows),allow_nan=False))
  return rows
 def save():
  report=dict(status='COMPLETE' if len([r for r in coverage if r['status']=='COMPLETE'])==len(days) else 'PARTIAL',expected_days=list(map(str,days)),coverage=coverage,paired_results=pairs,input_evidence=evidence,engine_sha256=file_hash(Path(original.__file__)),strategy_id=original.STRATEGY_ID,strategy_version=original.VERSION,moderate_body_min_pct=50,adverse_wick_max_pct=20,either_wick_max='BODY',live_changes=False)
  (root/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False));main_html(root,pairs,trades,coverage)
  if trades:
   with (root/'trades.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(trades[0]));w.writeheader();w.writerows(trades)
  return report
 try:
  for day in days:
   print('\nSESSION',day,flush=True);results={};daypairs=[];daytrades=[]
   try:
    minutes=acquire(day,True);prior=required_sessions(day);warm=[]
    print('  Loading 20 verified warmup sessions...',flush=True)
    for d in prior:warm.extend(bars(acquire(d),d))
    for name,kind,config in MODES:
     for filtered in (False,True):
      label=name+('__MODERATE_EVERY_ENTRY' if filtered else '__BASE')
      e,g=make_engine(original,h,inside,text,day,warm,kind,config,filtered)
      for b in bars(minutes,day):e.advance(b,minutes) if g is None else h.advance(e,g,b,minutes)
      if e.active:raise ValueError('SESSION_EXIT_MISSING')
      r=e.result();s=r['summary'];s.update(gross_loss=-sum(min(0,t['points']) for t in r['trades']),gross_profit=sum(max(0,t['points']) for t in r['trades']),confirmed_entries_inside_zones=sum((t['entry_evaluation'].get('confirmation_audit') or {}).get('phase')=='FOLLOWUP_CONFIRMED_INSIDE_ZONE' for t in r['trades']))
      results[label]=r
      print('\n'+label,flush=True);print('Side | Route | Setup | Entry | Exit | Entry NIFTY | Exit NIFTY | Net | Peak + | Giveback | Exit reason')
      for t in r['trades']:
       print(f"{t['side']} | {t['route_name']} | {t['entry_candle_start'][11:16]} | {t['entry_time'][11:16]} | {t['exit_time'][11:16]} | {t['entry_price']:.2f} | {t['exit_price']:.2f} | {t['points']:+.2f} | {t['peak_positive_points']:.2f} | {t['giveback_points']:.2f} | {'; '.join(t['exit_reasons'])}")
       daytrades.append(dict(day=str(day),policy=name,entry_filter='MODERATE_EVERY_ENTRY' if filtered else 'BASE',side=t['side'],route=t['route_name'],setup=t['entry_candle_start'][11:16],entry=t['entry_time'][11:16],exit=t['exit_time'][11:16],entry_price=t['entry_price'],exit_price=t['exit_price'],net=t['points'],outcome='WIN' if t['points']>0 else 'LOSS' if t['points']<0 else 'BREAKEVEN',peak=t['peak_positive_points'],giveback=t['giveback_points'],entry_path=(t['entry_evaluation'].get('confirmation_audit') or {}).get('phase','ORIGINAL_ENTRY'),reason='; '.join(t['exit_reasons'])))
      print('SUMMARY:',json.dumps(s),flush=True)
     base=results[name+'__BASE']['summary'];new=results[name+'__MODERATE_EVERY_ENTRY']['summary']
     daypairs.append(dict(day=str(day),policy=name,base=base,filtered=new,net_change=new['net_points']-base['net_points'],loss_reduction=base['gross_loss']-new['gross_loss']))
    out=root/'days'/str(day);out.mkdir(parents=True)
    meta=dict(day=str(day),target_sha256=digest(minutes),warmup_sessions=list(map(str,prior)),warmup_hashes={str(d):evidence[str(d)]['sha256'] for d in prior},engine_sha256=file_hash(Path(original.__file__)),mode='RESEARCH_ONLY')
    (out/'comparison.json').write_text(json.dumps(dict(metadata=meta,results=results),allow_nan=False));inside.make_html(out,results,meta)
    hp=out/'audit.html';ht=hp.read_text().replace('Strong entries inside EMA zones','Every-entry strength: 14-run daily audit').replace('Strong setup + follow-up: entries inside EMA zones','Every-entry strength: 14-run daily audit').replace('All variants retain the RSI5/RSI9 exit.','CURRENT_STRATEGY keeps original exits; other configurations retain their RSI-exit and zone rules. Each BASE is paired with MODERATE_EVERY_ENTRY, which additionally requires body >=50%, each wick <=body, adverse wick <=20% on every entry candle. Current/RSI-only policies have no zone confirmation; zone-only policy has no strength confirmation; strict/moderate zone policies retain their existing follow-up rules.').replace('Input: 375 verified target minutes and the same 20 prior sessions.',f'Input: {len(minutes)} verified target minutes and the same 20 prior sessions.')
    hp.write_text(ht)
    pairs.extend(daypairs);trades.extend(daytrades);coverage.append(dict(day=str(day),status='COMPLETE'))
   except Exception as exc:
    reason=str(exc)[:200] if isinstance(exc,ValueError) else type(exc).__name__;print('BLOCKED:',reason,flush=True)
    coverage.append(dict(day=str(day),status='BLOCKED',reason=reason))
    out=root/'days'/str(day);out.mkdir(parents=True,exist_ok=True);(out/'partial.json').write_text(json.dumps(results,allow_nan=False))
   save()
 finally:h.Gate=h._matrix_original_gate;source.close();report=save()
 print('\nPAIRED COMPARISON: positive loss_reduction means fewer losing points')
 for r in pairs:print(json.dumps(dict(day=r['day'],policy=r['policy'],base_net=round(r['base']['net_points'],2),filtered_net=round(r['filtered']['net_points'],2),net_change=round(r['net_change'],2),base_losses=r['base']['losers'],filtered_losses=r['filtered']['losers'],loss_reduction=round(r['loss_reduction'],2))),flush=True)
 zpath=root.with_suffix('.zip')
 with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
  for f in root.rglob('*'):
   if f.is_file():z.write(f,f.relative_to(root))
 print('STATUS:',report['status']);print('HTML:',root/'index.html');print('UPLOAD ZIP:',zpath)
 print('No live code, services, execution settings or orders changed.')
 if report['status']!='COMPLETE':raise SystemExit(2)

if __name__=='__main__':main()
