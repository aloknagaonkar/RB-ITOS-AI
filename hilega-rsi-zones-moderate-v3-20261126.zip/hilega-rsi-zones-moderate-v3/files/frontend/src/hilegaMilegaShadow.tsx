import HilegaVwapAudit from './hilegaVwapAudit'
import {sessionDay,dateOptions,recentAuditDays,selectedTradeDay,TradeDateFilter} from './hilegaTradeDates'
import HilegaPcrWorkspace from './hilegaPcrWorkspace'
import HilegaPcrAuditCard,{usePcrContext,strikeBias} from './hilegaPcrContext'
import HilegaExpiryWorkspace from './hilegaExpiryWorkspace'
import { useEffect, useMemo, useState, useRef } from 'react'
import {fetchLive,startLivePolling,useActiveLiveMarks} from './hilegaLivePolling'
import {LiveMarkHeaders,LiveMarkCells,LiveTradeTotal} from './hilegaActiveLiveMarkCells'
import HilegaDecisionTable,{type HilegaAudit} from './hilegaDecisionTable'
import {overlayDirectionalTradeMarkers} from './hilegaDirectionalTradeMarkerOverlay'
import {augmentDirectionalRowsWithTrades,overlayDirectionalAuditReports} from './hilegaDirectionalAuditOverlay'
import HilegaHistoricalReplay from './hilegaHistoricalReplay'
import HilegaUpstoxSandboxDashboard from './hilegaUpstoxSandboxDashboard'
import './liveShadow.css'

type Direction='BULLISH'|'BEARISH'|'NONE'|string

type DirectionalStatus = {
  strategy_id:string
  selected_live_shadow_strategy:string|null
  directional_mode_active:boolean
  observation_only:boolean
  execution_enabled:boolean
  paper_order_enabled:boolean
  option_selection_enabled:boolean
  step_audit_chain_ok:boolean|null
  step_audit_chain_issue:string|null
  current:{
    session_date:string
    state_available:boolean
    trade_owner:Direction
    bullish_state:string|null
    bearish_state:string|null
    bullish_armed:boolean|null
    bearish_armed:boolean|null
    last_completed_bar:string|null
  }
  latest_accepted_record:Record<string,any>|null
  latest_suppressed_record:Record<string,any>|null
  latest_state_session_date:string|null
}

type AuditReport = {
  checkpoint:string
  mode:string
  strategy:{state_before:string|null;state_after:string|null;selected_route:string|null;route_b_suppressed_by_route_a_priority:boolean|null;events_emitted:string[]}
  bar:{open:number|null;high:number|null;low:number|null;close:number|null;volume:number|null}
  indicators:{rsi9:number|null;ema3_rsi:number|null;wma21_rsi:number|null;previous_rsi9:number|null;previous_ema3_rsi:number|null;previous_wma21_rsi:number|null}
  conditions:Record<string,boolean|null>
  route_a:{eligible:boolean|null;pass:boolean|null;fail_reasons:string[]}
  route_b:{eligible:boolean|null;pass:boolean|null;fail_reasons:string[]}
  transitions:Array<Record<string,any>>
  option_candidate:Record<string,any>|null
  option_market_snapshot:Record<string,any>|null
  option_lifecycle:{start:Record<string,any>|null;updates:Array<Record<string,any>>;exit:Record<string,any>|null}
  audit_integrity:{chain_ok:boolean|null;chain_issue:string|null;records:Array<Record<string,any>>}
  safety:{observation_only:boolean;execution_enabled:boolean;paper_order_enabled:boolean}
}

type TradeLeg={
  relation_to_atm:number
  strike:number
  side?:string|null
  instrument_key:string
  entry_timestamp:string|null
  entry_open:number|null
  latest_completed_minute?:string|null
  latest_close:number|null
  current_points:number|null
  current_return_pct:number|null
  mfe_points:number|null
  mae_points:number|null
  exit_timestamp:string|null
  exit_open:number|null
  realized_points:number|null
  realized_return_pct:number|null
}

type Trade={
  direction:Direction
  option_side:'CE'|'PE'|string
  signal_bar:string
  signal_boundary?:string|null
  signal_spot?:number|null
  source:string|null
  expiry:string|null
  atm:number|null
  status:string
  complete:boolean
  issue?:string|null
  exit_reason?:string|null
  pending_exit_boundary?:string|null
  legs:TradeLeg[]
}

type Dashboard={
  account_pnl_rupees:null
  warning:string
  measurement:string
  coverage_note?:string
  trade_count:number
  complete_closed_count:number
  active_count:number
  incomplete_count:number
  pending_exit_count?:number
  trades:Trade[]
}

const directionalBase='/api/live-shadow/hilega-directional'
const bullishBase='/api/live-shadow/hilega-milega'

const getFrom=async<T,>(base:string,path:string):Promise<T>=>{
  const r=await fetchLive(base+path)
  if(!r.ok){const e=await r.json().catch(()=>null);throw new Error(e?.detail||'Hilega request failed')}
  return r.json()
}
const getDirectional=<T,>(path:string)=>getFrom<T>(directionalBase,path)
const getBullish=<T,>(path:string)=>getFrom<T>(bullishBase,path)

const detailedAudit=(cp:string):Promise<HilegaAudit>=>getBullish<AuditReport>('/audit-detail?checkpoint='+encodeURIComponent(cp)) as Promise<HilegaAudit>
const tm=(v:string|null|undefined)=>v?new Date(v).toLocaleTimeString('en-IN',{timeZone:'Asia/Kolkata',hour12:false}):'—'
const dt=(v:string|null|undefined)=>v?new Date(v).toLocaleString('en-IN',{timeZone:'Asia/Kolkata',hour12:false}):'—'
const num=(v:any,d=2)=>v==null?'—':Number(v).toLocaleString('en-IN',{maximumFractionDigits:d})
const words=(v:any)=>v==null?'—':String(v).replaceAll('_',' ')
const yn=(v:any)=>v==null?'NA':v?'YES':'NO'
const isEntry=(x:any)=>String(x?.event_type??'').startsWith('ENTRY_')
const isExit=(x:any)=>String(x?.event_type??'').includes('EXIT')
const firstEntry=(r:AuditReport)=>r.transitions.find(isEntry)??null
const firstExit=(r:AuditReport)=>r.transitions.find(isExit)??null
const lifecycleState=(r:AuditReport)=>r.option_lifecycle.exit?.status??r.option_lifecycle.updates.at(-1)?.status??r.option_lifecycle.start?.status??null

function AuditDetail({r}:{r:AuditReport}){
  const legs=(r.option_lifecycle.exit?.legs??r.option_lifecycle.updates.at(-1)?.legs??r.option_lifecycle.start?.legs??[]) as any[]
  const entry=firstEntry(r)
  const exit=firstExit(r)
  return <div className="hilega-audit-body">
    <HilegaVwapAudit at={String((r as any).audit_integrity?.decision_timestamp??(r.strategy as any)?.decision_timestamp??new Date(new Date(r.checkpoint).getTime()+300000).toISOString())}/>
    <HilegaPcrAuditCard at={new Date(new Date(r.checkpoint).getTime()+300000).toISOString()}/>
    <div className="shadow-detail-grid" style={{gridTemplateColumns:'repeat(auto-fit,minmax(210px,1fr))'}}>
      <span>Checkpoint <b>{dt(r.checkpoint)}</b></span><span>Route <b>{words(r.strategy.selected_route)}</b></span>
      <span>State <b>{words(r.strategy.state_before)} → {words(r.strategy.state_after)}</b></span>
      <span>Entry <b>{entry?`${num(entry.price)} @ ${tm(entry.event_time??r.checkpoint)}`:'—'}</b><small>{entry?words(entry.source??entry.event_type):'No entry at this checkpoint'}</small></span>
      <span>Exit <b>{exit?`${num(exit.price)} @ ${tm(exit.event_time??r.checkpoint)}`:'—'}</b><small>{exit?words(exit.exit_reason??exit.source??exit.event_type):'No exit at this checkpoint'}</small></span>
      <span>Close <b>{num(r.bar.close)}</b></span>
      <span>RSI9 <b>{num(r.indicators.rsi9)}</b></span><span>EMA3 RSI <b>{num(r.indicators.ema3_rsi)}</b></span><span>WMA21 RSI <b>{num(r.indicators.wma21_rsi)}</b></span>
       <span>Previous RSI9 <b>{num(r.indicators.previous_rsi9)}</b></span><span>Previous EMA3 RSI <b>{num(r.indicators.previous_ema3_rsi)}</b></span><span>Previous WMA21 RSI <b>{num(r.indicators.previous_wma21_rsi)}</b></span>
       {r.conditions.wma21_slope_required&&<><span>WMA21 slope change <b>{num(r.conditions.wma21_slope_change,4)}</b><small>Current minus previous completed 5m candle; no minimum threshold</small></span><span>Bullish WMA rising <b>{yn(r.conditions.bullish_wma21_rising)}</b></span><span>Bearish WMA falling <b>{yn(r.conditions.bearish_wma21_falling)}</b></span><span>WMA slope gate <b>{yn(r.conditions.bullish_wma21_slope_pass??r.conditions.bearish_wma21_slope_pass)}</b><small>{String(r.conditions.bullish_wma21_slope_rejection||r.conditions.bearish_wma21_slope_rejection||'No slope rejection')}</small></span></>}
      <span>RSI↑EMA <b>{yn(r.conditions.rsi_cross_ema_up)}</b></span><span>RSI↓WMA <b>{yn(r.conditions.rsi_cross_wma_down)}</b></span><span>RSI&gt;50 <b>{yn(r.conditions.rsi_gt_50)}</b></span>
      <span>RSI&gt;WMA <b>{yn(r.conditions.rsi_gt_wma)}</b></span><span>EMA&gt;WMA <b>{yn(r.conditions.ema_gt_wma)}</b></span><span>RSI rising <b>{yn(r.conditions.rsi_rising)}</b></span><span>EMA rising <b>{yn(r.conditions.ema_rising)}</b></span>
      <span>Route A <b>{yn(r.route_a.pass)}</b><small>{r.route_a.fail_reasons.join(', ')||'No failures'}</small></span>
      <span>Route B <b>{yn(r.route_b.pass)}</b><small>{r.route_b.fail_reasons.join(', ')||'No failures'}</small></span>
      <span>A priority <b>{yn(r.strategy.route_b_suppressed_by_route_a_priority)}</b></span>
      <span>Expiry <b>{String(r.option_candidate?.expiry??'—')}</b></span><span>ATM <b>{num(r.option_candidate?.atm,0)}</b></span>
      <span>Candidate status <b>{words(r.option_candidate?.status)}</b></span><span>Market snapshot <b>{words(r.option_market_snapshot?.status)}</b></span>
      <span>Lifecycle <b>{words(lifecycleState(r))}</b></span><span>Audit chain <b>{r.audit_integrity.chain_ok?'HEALTHY':'CHECK'}</b></span>
    </div>
    {legs.length>0&&<div className="hilega-audit-section"><b>ATM±2 CE entry / exit audit — independent shadow observations, not executed P&L</b><div className="shadow-table-scroll"><table className="shadow-table"><thead><tr><th>Role</th><th>Strike</th><th>CE entry price</th><th>CE exit price</th><th>Live premium</th><th>Realized pts</th><th>Realized %</th><th>Unrealized pts</th><th>MFE</th><th>MAE</th></tr></thead><tbody>{legs.map((x:any)=><tr key={x.instrument_key}><td>{x.relation_to_atm===0?'ATM':`ATM${x.relation_to_atm>0?'+':''}${x.relation_to_atm}`}</td><td>{num(x.strike,0)} CE</td><td>{num(x.entry_open)}</td><td>{num(x.exit_open)}</td><td>{num(x.latest_close)}</td><td>{num(x.realized_points)}</td><td>{x.realized_return_pct==null?"—":`${num(x.realized_return_pct)}%`}</td><td>{num(x.current_points)}</td><td>{num(x.mfe_points)}</td><td>{num(x.mae_points)}</td></tr>)}</tbody></table></div></div>}
    <div className="hilega-audit-section"><b>Option data availability</b><p>Only exact causal 1-minute option prices are displayed. Missing values mean unavailable or incomplete, not zero P&L.</p><div className="shadow-detail-grid"><span>Lifecycle issue <b>{String(r.option_lifecycle.exit?.issue??r.option_lifecycle.updates.at(-1)?.issue??r.option_lifecycle.start?.issue??"None recorded")}</b></span><span>Execution <b>DISABLED</b></span><span>Quantity <b>NONE</b></span></div></div><div className="hilega-audit-section"><b>Transitions</b><pre>{JSON.stringify(r.transitions,null,2)}</pre></div>
    <div className="hilega-audit-section"><b>Audit integrity</b><pre>{JSON.stringify(r.audit_integrity,null,2)}</pre></div>
  </div>
}

const role=(r:number)=>r===0?'ATM':`ATM${r>0?'+':''}${r}`
const signed=(v:number|null|undefined)=>v==null?'—':`${v>0?'+':''}${num(v)}`
const plusMinutes=(v:string|null|undefined,m:number)=>{
  if(!v)return null
  const ms=new Date(v).getTime()
  return Number.isFinite(ms)?new Date(ms+m*60_000).toISOString():null
}
const candleWindow=(v:string|null|undefined)=>{
  if(!v)return '—'
  return `${tm(v).slice(0,5)}–${tm(plusMinutes(v,5)).slice(0,5)}`
}
const firstLegTime=(t:Trade,key:'entry_timestamp'|'exit_timestamp')=>t.legs.map(l=>l[key]).find(Boolean)??null
const latestAccepted=(s:DirectionalStatus|null)=>{
  const a=(s?.latest_accepted_record?.payload?.accepted_events??[]) as string[]
  return a.length?a.map(words).join(', '):'—'
}


function sameCheckpoint(a:string|null|undefined,b:string|null|undefined){
  if(!a||!b)return false
  const ams=new Date(a).getTime()
  const bms=new Date(b).getTime()
  if(Number.isFinite(ams)&&Number.isFinite(bms))return ams===bms
  return a===b
}

function attachDirectionalTradeAuditMetadata(
  reports:HilegaAudit[],
  trades:Trade[],
):HilegaAudit[]{
  return reports.map(report=>{
    const trade=(trades??[]).find(t=>sameCheckpoint(t.signal_bar,report.checkpoint))
    if(!trade)return report

    const lifecycleStart={
      model:'DIRECTIONAL_TRADE_DASHBOARD_OVERLAY',
      direction:trade.direction,
      option_side:trade.option_side,
      signal_bar:trade.signal_bar,
      signal_boundary:trade.signal_boundary??null,
      signal_spot:trade.signal_spot??null,
      source:trade.source,
      expiry:trade.expiry,
      atm:trade.atm,
      status:trade.status,
      issue:trade.issue??null,
      active:String(trade.status).toUpperCase()==='ACTIVE',
      latest_completed_minute:trade.legs.map(x=>x.latest_completed_minute).filter(Boolean).at(-1)??null,
      pending_exit_boundary:trade.pending_exit_boundary??null,
      exit_reason:trade.exit_reason??null,
      legs:trade.legs??[],
    }

    const lifecycleExit=trade.exit_reason
      ? {...lifecycleStart,status:trade.status,exit_reason:trade.exit_reason}
      : null

    return {
      ...report,
      strategy:{...(report.strategy??{}),option_side:trade.option_side},
      option_candidate:{
        ...(report.option_candidate??{}),
        model:'DIRECTIONAL_TRADE_DASHBOARD_METADATA',
        direction:trade.direction,
        side:trade.option_side,
        expiry:trade.expiry,
        atm:trade.atm,
        signal_spot:trade.signal_spot??null,
        signal_boundary:trade.signal_boundary??null,
        source:trade.source,
        status:trade.status,
        issue:trade.issue??null,
      },
      option_market_snapshot:{
        ...(report.option_market_snapshot??{}),
        model:'DIRECTIONAL_TRADE_DASHBOARD_METADATA',
        status:trade.status,
        direction:trade.direction,
        side:trade.option_side,
        signal_boundary:trade.signal_boundary??null,
        issue:trade.issue??null,
      },
      option_lifecycle:{
        ...(report.option_lifecycle??{}),
        start:lifecycleStart,
        updates:report.option_lifecycle?.updates??[],
        exit:lifecycleExit,
      },
    } as HilegaAudit
  })
}

export default function HilegaMilegaShadow(){
  const [workspaceMode,setWorkspaceMode]=useState<'LIVE'|'HISTORICAL_REPLAY'>('LIVE')
  const [status,setStatus]=useState<DirectionalStatus|null>(null)
  const [rows,setRows]=useState<AuditReport[]>([])
  const [dashboard,setDashboard]=useState<Dashboard|null>(null)
  const [expanded,setExpanded]=useState<string|null>(null)
  const [detail,setDetail]=useState<AuditReport|null>(null)
  const [auditLoading,setAuditLoading]=useState(false)
  const [error,setError]=useState('')
  const [tradeDate,setTradeDate]=useState('')
  const [gapChecks,setGapChecks]=useState<Record<string,any>[]>([])
  const liveMarks=useActiveLiveMarks()
  const dashboardRef=useRef<Dashboard|null>(null)
  const auditBaseRef=useRef<HilegaAudit[]>([])
  const directionalRef=useRef<any[]>([])
  const [uiUpdates,setUiUpdates]=useState<Record<string,string>>({})

  useEffect(()=>{
    let active=true;const failures:Record<string,string>={};const controller=new AbortController()
    const wrap=(name:string,fn:()=>Promise<void>)=>async()=>{
      try{await fn();delete failures[name];if(active)setUiUpdates(v=>({...v,[name]:new Date().toISOString()}))}
      catch(e){failures[name]=name+': '+(e as Error).message}
      if(active)setError(Object.values(failures).join(' · '))
    }
    const current=()=>active
    const stopStatus=startLivePolling(wrap('Status',async()=>{
      const s=await getDirectional<DirectionalStatus>('/status?fast=true');if(active)setStatus(s)
    }),10000)
    const stopTrades=startLivePolling(wrap('Trades',async()=>{
      const d=await getDirectional<Dashboard>('/trade-dashboard');if(active){dashboardRef.current=d;setDashboard(d)}
    }),5000)
    const stopChecks=startLivePolling(wrap('Entry checks',async()=>{
      const g=await getDirectional<{rows:Record<string,any>[]}>('/wma-gap-evaluations?limit=100');if(active)setGapChecks(g.rows)
    }),5000)
    const stopAudit=startLivePolling(wrap('Decision candles',async()=>{
      const day=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date())
      const dr=await fetchLive('/api/live-shadow/hilega-directional-candles/live?audit_only=true&session_date='+day,controller.signal)
      if(!dr.ok)throw new Error('Decision audit HTTP '+dr.status+': '+await dr.text())
      const directional=await dr.clone().json()
      const combined=(directional.rows??[]).some((r:any)=>r.strategy_id==='HILEGA_RSI_TWO_ROUTE_CONFIRMED_MIDPOINT')
      const results=await Promise.allSettled([
        combined?Promise.resolve([] as AuditReport[]):getBullish<AuditReport[]>('/audit-index?limit=200'),
        Promise.resolve(dr),
      ])
      let errors:string[]=[]
      if(results[0].status==='fulfilled')auditBaseRef.current=results[0].value as HilegaAudit[]
      else errors.push('base audit: '+String(results[0].reason))
      if(results[1].status==='fulfilled'&&results[1].value.ok){directionalRef.current=(await results[1].value.json()).rows??[]}
      else errors.push('directional audit request failed')
      if(errors.length===2)throw new Error(errors.join(' · '))
      const a=auditBaseRef.current;const d=dashboardRef.current??({trades:[]} as unknown as Dashboard)
      const active=current
    let merged=a as HilegaAudit[]
    if(directionalRef.current.length){
      const rawRows=directionalRef.current
      const directionalRows=[...augmentDirectionalRowsWithTrades(rawRows.filter((r:any)=>!['HILEGA_WMA_GAP_V2_LIVE_SHADOW','HILEGA_RSI_TWO_ROUTE_CONFIRMED_MIDPOINT'].includes(r.strategy_id)),d.trades??[]),...rawRows.filter((r:any)=>['HILEGA_WMA_GAP_V2_LIVE_SHADOW','HILEGA_RSI_TWO_ROUTE_CONFIRMED_MIDPOINT'].includes(r.strategy_id))]
      merged=overlayDirectionalAuditReports(a as HilegaAudit[],directionalRows)
    }
    const v2Reports=merged.filter(r=>['HILEGA_WMA_GAP_V2_LIVE_SHADOW','HILEGA_RSI_TWO_ROUTE_CONFIRMED_MIDPOINT'].includes(r.strategy?.strategy_id))
    merged=overlayDirectionalTradeMarkers(merged.filter(r=>!['HILEGA_WMA_GAP_V2_LIVE_SHADOW','HILEGA_RSI_TWO_ROUTE_CONFIRMED_MIDPOINT'].includes(r.strategy?.strategy_id)),d.trades??[])
    merged=attachDirectionalTradeAuditMetadata(merged,d.trades??[])
    if(active())setRows([...merged.filter(r=>!v2Reports.some(v=>v.checkpoint.slice(0,10)===r.checkpoint.slice(0,10))),...v2Reports].sort((a,b)=>b.checkpoint.localeCompare(a.checkpoint)) as AuditReport[])
      if(errors.length)throw new Error(errors.join(' · '))
    }),5000)
    return()=>{active=false;controller.abort();stopStatus();stopTrades();stopChecks();stopAudit()}
  },[])

  useEffect(()=>{
    if(!expanded)return
    let active=true
    const stop=startLivePolling(async()=>{
      try{const r=await getBullish<AuditReport>('/audit-detail?checkpoint='+encodeURIComponent(expanded));if(active)setDetail(r)}
      catch{/* Existing recorded detail stays visible; panel polling continues. */}
    },10000)
    return()=>{active=false;stop()}
  },[expanded])

  const activity=useMemo(()=>rows.filter(r=>r.transitions.length>0||(r.strategy.events_emitted||[]).length>0),[rows])
  const entries=useMemo(()=>activity.flatMap(r=>r.transitions.filter(isEntry).map(t=>({r,t}))),[activity])
  const exits=useMemo(()=>activity.flatMap(r=>r.transitions.filter(isExit).map(t=>({r,t}))),[activity])
  const latestEntry=entries[0]??null
  const latestExit=exits[0]??null
  const activePcr=usePcrContext()
  const activeTrades=useMemo(()=>dashboard?.trades.filter(t=>String(t.status).toUpperCase()==='ACTIVE')??[],[dashboard])
  const allExitedTrades=useMemo(()=>dashboard?.trades.filter(t=>String(t.status).toUpperCase()!=='ACTIVE')??[],[dashboard])
  const tradeDates=dateOptions(allExitedTrades.map(t=>sessionDay(t.signal_bar)))
  const selectedDate=selectedTradeDay(tradeDate,tradeDates)
  const exitedTrades=allExitedTrades.filter(t=>sessionDay(t.signal_bar)===selectedDate)
  const auditDays=recentAuditDays(rows.map(r=>sessionDay(r.checkpoint)))
  const liveAuditRows=rows.filter(r=>auditDays.includes(sessionDay(r.checkpoint)))


  const openTradeAudit=async(checkpoint:string)=>{
    if(expanded===checkpoint){setExpanded(null);setDetail(null);return}
    const cached=rows.find(r=>r.checkpoint===checkpoint)
    setExpanded(checkpoint);setDetail(cached??null);setAuditLoading(true)
    try{const response=await getBullish<AuditReport>('/audit-detail?checkpoint='+encodeURIComponent(checkpoint));setDetail(response);setError('')}
    catch(e){setError(`Detailed trade audit failed: ${(e as Error).message}`)}finally{setAuditLoading(false)}
  }

  const modeSelector=<div className="hime-controls hilega-mode-selector" role="group" aria-label="Hilega workspace mode">
    <button aria-pressed={workspaceMode==='LIVE'} onClick={()=>setWorkspaceMode('LIVE')}>Live shadow</button>
    <button aria-pressed={workspaceMode==='HISTORICAL_REPLAY'} onClick={()=>setWorkspaceMode('HISTORICAL_REPLAY')}>Historical replay</button>
  </div>

  if(workspaceMode==='HISTORICAL_REPLAY')return <div className="shadow-page hilega-page">
    {modeSelector}
    <HilegaHistoricalReplay/>
  </div>

  return <div className="shadow-page hilega-page">
    {modeSelector}
    {error&&<div className="banner error">{error}</div>}

    <div className="shadow-safety"><b>Active strategy: {status?.selected_live_shadow_strategy??'Loading'}</b><span>Structural exit · exit-first processing</span></div>
    {['HILEGA_WMA_GAP_V2_LIVE_SHADOW','HILEGA_RSI_TWO_ROUTE_CONFIRMED_MIDPOINT'].includes(status?.selected_live_shadow_strategy??'')&&<section className="panel">
      <h2>{status?.selected_live_shadow_strategy} · entry decision audit</h2>
      <p>Completed 3-minute RSI Two Route: Normal Route needs any two RSI votes plus WMA21(RSI9); WMA_bypass needs all five RSI votes. Every entry also requires moderate candle strength and a close outside both EMA10/EMA30 no-entry zones. Both RSI5 and RSI9 crossing the opposite side of 50 can close an existing trade. Existing trade cards and manual controls remain below.</p>
      <div style={{overflowX:'auto'}}><table><thead><tr><th>Decision time</th><th>Direction</th><th>Route</th><th>RSI votes</th><th>Close</th><th>EMA30 High</th><th>EMA30 Low</th><th>WMA21 RSI9</th><th>Decision / blockers</th></tr></thead>
      <tbody>{gapChecks.slice().reverse().map((r,i)=>{const p=r.payload??{},f=p.frame??{};return <tr key={r.record_hash??i}><td>{tm(p.decision_timestamp)}</td><td>{p.direction}</td><td>{p.route_name??'—'}</td><td>{p.rsi_pass_count??'—'}/5</td><td>{num(f.close)}</td><td>{num(f.ema30_high)}</td><td>{num(f.ema30_low)}</td><td>{num(f.wma21_rsi9)}</td><td>{p.status} · {(p.reasons??[]).join(', ')||'All entry rules passed'}</td></tr>})}</tbody></table></div>
      {!gapChecks.length&&<p>No current-session V2 evaluations yet.</p>}
    </section>}
    <HilegaExpiryWorkspace/>
    <HilegaPcrWorkspace/>

    <HilegaUpstoxSandboxDashboard/>
    <p>Automatic updates · trades 5s · decisions 5s · live marks 2s. Last successful updates: {Object.entries(uiUpdates).map(([name,at])=>name+' '+tm(at)).join(' · ')||'Connecting…'}</p>

    <div className="shadow-safety">
      <b>HILEGA-MILEGA · OBSERVATION ONLY</b>
      <span>Execution disabled</span>
      <span>Paper orders disabled</span>
      <span>No CE/PE selector</span>
      <span>Audit chain {status?.step_audit_chain_ok===null?'verification deferred':status?.step_audit_chain_ok?'healthy':'check'}</span>
    </div>

    {status?.current.state_available===false&&<div className="hilega-dashboard-warning">
      No live decision has been recorded for {status.current.session_date}. The panels below retain saved records; the latest state is from {status.latest_state_session_date??'an earlier session'} and is not today's state. Check that today's worker and market-data feed are running.
    </div>}

    <div className="shadow-metrics hilega-dashboard-summary">
      <article><span>Trade owner</span><b>{words(status?.current.trade_owner??'NONE')}</b><small>Exclusive directional owner</small></article>
      <article><span>Bullish state</span><b>{words(status?.current.bullish_state)}</b><small>Armed {status?.current.bullish_armed?'YES':'NO'}</small></article>
      <article><span>Bearish state</span><b>{words(status?.current.bearish_state)}</b><small>Armed {status?.current.bearish_armed?'YES':'NO'}</small></article>
      <article><span>Last accepted event</span><b>{latestAccepted(status)}</b><small>{dt(status?.latest_accepted_record?.event_time)}</small></article>
      <article><span>Last entry detected</span><b>{latestEntry?dt(latestEntry.t.event_time??latestEntry.r.checkpoint):'—'}</b><small>{latestEntry?`Route ${words(latestEntry.r.strategy.selected_route)} · NIFTY ${num(latestEntry.t.price)}`:'No bullish audit entry recorded'}</small></article>
      <article><span>Last exit detected</span><b>{latestExit?dt(latestExit.t.event_time??latestExit.r.checkpoint):'—'}</b><small>{latestExit?`${words(latestExit.t.exit_reason??latestExit.t.event_type)} · NIFTY ${num(latestExit.t.price)}`:'No bullish audit exit recorded'}</small></article>
      <article><span>Completed 5-leg lifecycles</span><b>{dashboard?.complete_closed_count??'—'}</b><small>{dashboard?`${dashboard.active_count} active · ${dashboard.pending_exit_count??0} pending exact exit · ${dashboard.incomplete_count} incomplete`:'Dashboard loading'}</small></article>
    </div>

    <section className="panel shadow-panel">
      <div className="panel-heading"><div><h2>Active option shadow trade</h2><p>The existing trade view now supports bullish CE or bearish PE without changing the layout.</p></div><span className="pill teal">{activeTrades.length?`${activeTrades.length} ACTIVE`:'NO ACTIVE TRADE'}</span></div>
      {!dashboard?<div className="empty">Loading active trade…</div>:!activeTrades.length?<div className="empty">No active option shadow trade.</div>:<div className="hilega-ledger">
        {activeTrades.map(t=>{
          const isOpen=expanded===t.signal_bar
          const entryTime=firstLegTime(t,'entry_timestamp')
          const side=t.option_side
          return <article className="hilega-trade-card" key={`${t.direction}-${t.signal_bar}`}>
            <div className="hilega-trade-head"><div>
              <b>{words(t.direction)} · {side} · Signal candle {candleWindow(t.signal_bar)}</b> · {words(t.source)} <span className="shadow-stage">ACTIVE</span>
              <small>Session {sessionDay(t.signal_bar)} · Decision boundary {tm(t.signal_boundary??plusMinutes(t.signal_bar,5))} · {side} entry {tm(entryTime)} · Expiry {t.expiry??'—'} · ATM {num(t.atm,0)} · Signal NIFTY {num(t.signal_spot)}</small>
            </div>{t.direction==='BULLISH'&&<button onClick={()=>void openTradeAudit(t.signal_bar)}>{isOpen?'Hide audit':'Audit ▾'}</button>}</div>
            <LiveTradeTotal trade={t} find={liveMarks.find}/>
            {t.issue&&<div className="hilega-dashboard-warning">Data limitation: {t.issue}</div>}
            {t.legs.length>0&&<div className="shadow-table-scroll"><table className="shadow-table hilega-economics-table"><thead><tr><th>{side}</th><th>Entry time</th><th>Entry premium</th><th>Latest premium</th><th>Current pts</th><th>Current %</th><th>Combined bias</th><th>MFE</th><th>MAE</th><LiveMarkHeaders/></tr></thead><tbody>{t.legs.map(l=><tr key={l.instrument_key}><td>{role(l.relation_to_atm)} · {num(l.strike,0)} {side}</td><td>{tm(l.entry_timestamp)}</td><td>{num(l.entry_open)}</td><td>{num(l.latest_close)}</td><td className={l.current_points==null?'':l.current_points>=0?'positive':'negative'}>{signed(l.current_points)}</td><td>{l.current_return_pct==null?'—':`${signed(l.current_return_pct)}%`}</td><td>{strikeBias(activePcr,l.strike,l.instrument_key)}</td><td>{num(l.mfe_points)}</td><td>{num(l.mae_points)}</td><LiveMarkCells mark={liveMarks.find(t,l.instrument_key)}/></tr>)}</tbody></table></div>}
            {isOpen&&<div className="hilega-inline-audit"><h3>Full detailed bullish audit · {t.signal_bar}</h3>{auditLoading&&<p>Refreshing detailed audit…</p>}{detail&&<AuditDetail r={detail}/>}</div>}
          </article>
        })}
      </div>}
    </section>

    <section className="panel shadow-panel">
      <div className="panel-heading"><div><h2>Hilega candle-by-candle decision audit</h2>
        <p>Today and the previous available session only. Older dates remain in historical replay.</p></div>
        <span className="pill teal">LIVE · OBSERVATION ONLY</span></div>
      <p>Sessions: {auditDays.join(" · ")} · {liveAuditRows.length} checkpoints</p>
      <HilegaDecisionTable reports={liveAuditRows as HilegaAudit[]} mode="LIVE"
        fetchDetail={async checkpoint=>{
          const local=rows.find(r=>r.checkpoint===checkpoint)

          if(local?.mode==='LIVE_DIRECTIONAL'){
            return local as HilegaAudit
          }

          return detailedAudit(checkpoint)
        }}
        emptyMessage="No completed live strategy checkpoints available yet." />
    </section>

    <section className="panel shadow-panel">
      <div className="panel-heading"><div><h2>Exited option shadow trades</h2><p>Same existing trade cards, now combined across bullish CE and bearish PE lifecycles.</p></div><span className="pill teal">{exitedTrades.length} EXITED</span></div>
      <TradeDateFilter value={selectedDate} dates={tradeDates} onChange={d=>{setTradeDate(d);setExpanded(null);setDetail(null)}}><span>{exitedTrades.length} of {allExitedTrades.length} exited records · active trades remain visible above</span></TradeDateFilter>
      {dashboard?.coverage_note&&<div className="hilega-dashboard-warning">{dashboard.coverage_note}</div>}
      {!dashboard?<div className="empty">Loading exited trades…</div>:!exitedTrades.length?<div className="empty">No exited option shadow trades for this session.</div>:<div className="hilega-ledger">
        {exitedTrades.map(t=>{
          const isOpen=expanded===t.signal_bar
          const entryTime=firstLegTime(t,'entry_timestamp')
          const exitTime=firstLegTime(t,'exit_timestamp')
          const side=t.option_side
          return <article className="hilega-trade-card" key={`${t.direction}-${t.signal_bar}`}>
            <div className="hilega-trade-head"><div>
              <b>{words(t.direction)} · {side} · Signal candle {candleWindow(t.signal_bar)}</b> · {words(t.source)} <span className="shadow-stage">{words(t.status)}</span>
              <small>Session {sessionDay(t.signal_bar)} · Decision boundary {tm(t.signal_boundary??plusMinutes(t.signal_bar,5))} · {side} entry {tm(entryTime)} · {side} exit {tm(exitTime)} · Expiry {t.expiry??'—'} · ATM {num(t.atm,0)} · Signal NIFTY {num(t.signal_spot)} · Exit reason {words(t.exit_reason)}</small>
            </div>{t.direction==='BULLISH'&&<button onClick={()=>void openTradeAudit(t.signal_bar)}>{isOpen?'Hide audit':'Audit ▾'}</button>}</div>
            {String(t.status).toUpperCase()==='PENDING_EXACT_EXIT'&&<div className="hilega-dashboard-warning">Underlying strategy has exited. Awaiting the exact causal {side} exit-minute OPEN at {tm(t.pending_exit_boundary)}. Realized premium points remain unavailable until exact prices are recorded.</div>}
            {t.issue&&<div className="hilega-dashboard-warning">Data limitation: {t.issue}</div>}
            {t.legs.length>0&&<div className="shadow-table-scroll"><table className="shadow-table hilega-economics-table"><thead><tr><th>{side}</th><th>Entry time</th><th>Entry premium</th><th>Exit time</th><th>Exit premium</th><th>Realized pts</th><th>Realized %</th><th>MFE</th><th>MAE</th></tr></thead><tbody>{t.legs.map(l=><tr key={l.instrument_key}><td>{role(l.relation_to_atm)} · {num(l.strike,0)} {side}</td><td>{tm(l.entry_timestamp)}</td><td>{num(l.entry_open)}</td><td>{tm(l.exit_timestamp)}</td><td>{num(l.exit_open)}</td><td className={l.realized_points==null?'':l.realized_points>=0?'positive':'negative'}>{signed(l.realized_points)}</td><td>{l.realized_return_pct==null?'—':`${signed(l.realized_return_pct)}%`}</td><td>{num(l.mfe_points)}</td><td>{num(l.mae_points)}</td></tr>)}</tbody></table></div>}
            {isOpen&&t.direction==='BULLISH'&&<div className="hilega-inline-audit"><h3>Full detailed bullish audit · {t.signal_bar}</h3>{auditLoading&&<p>Refreshing detailed audit…</p>}{detail&&<AuditDetail r={detail}/>}</div>}
          </article>
        })}
      </div>}
    </section>
  </div>
}

