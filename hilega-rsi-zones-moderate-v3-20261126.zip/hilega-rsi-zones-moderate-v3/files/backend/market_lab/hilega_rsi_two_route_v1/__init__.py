STRATEGY_ID = "HILEGA_RSI_TWO_ROUTE_CONFIRMED_MIDPOINT"
VERSION = "rsi-two-route-1.1.0-3m-rsi-exit-ema-zones-moderate"
