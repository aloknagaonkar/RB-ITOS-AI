"""Shared production entry gates for RSI exit + EMA zones + moderate entry.
No IO or transport. The archived reference evaluator remains available for research.
"""
from math import isfinite
from .reference import Indicators as BaseIndicators, evaluate_entry as base_entry

CONFIGURATION='RSI_EXIT_EMA_ZONES__MODERATE_EVERY_ENTRY'
class Indicators(BaseIndicators):
    def __init__(self):
        super().__init__(); self.h10=None; self.l10=None
    def update(self,bar):
        frame=super().update(bar);alpha=2/11
        self.h10=float(bar['high']) if self.h10 is None else alpha*float(bar['high'])+(1-alpha)*self.h10
        self.l10=float(bar['low']) if self.l10 is None else alpha*float(bar['low'])+(1-alpha)*self.l10
        return dict(frame,ema10_high=self.h10,ema10_low=self.l10)

def evaluate_entry(frame,side):
    if side not in ('CE','PE'):raise ValueError('INVALID_DIRECTION')
    ev=base_entry(frame,side);ev['route_before_entry_strength']=ev['selected_route']
    o,h,l,c=(frame[k] for k in ('open','high','low','close'));body=abs(c-o);span=h-l;upper=h-max(o,c);lower=min(o,c)-l;eps=1e-9
    valid=all(isinstance(v,(int,float)) and not isinstance(v,bool) and isfinite(v) for v in (o,h,l,c)) and span>0 and l<=min(o,c)<=max(o,c)<=h
    checks=dict(valid_candle=valid,body_at_least_50pct=valid and body+eps>=.5*span,
        upper_wick_not_above_body=upper<=body+eps,lower_wick_not_above_body=lower<=body+eps,
        adverse_wick_at_most_20pct=valid and (upper if side=='CE' else lower)<=.2*span+eps)
    ev['moderate_entry_strength']=dict(checks=checks,body_pct=100*body/span if valid else None,
        upper_wick_pct=100*upper/span if valid else None,lower_wick_pct=100*lower/span if valid else None)
    failed=[k for k,v in checks.items() if not v]
    for name,gates in ev['route_checks'].items():
        gates.update(checks)
        if failed:ev['eligible_routes'][name]=False;ev['route_blockers'][name].extend(failed)
    if failed:ev['selected_route']=None;ev['blockers']+=failed
    levels=('ema10_high','ema10_low','ema30_high','ema30_low')
    ready=all(isinstance(frame.get(k),(int,float)) and not isinstance(frame[k],bool) and isfinite(frame[k]) for k in levels)
    zones=[]
    if ready:
        zones=[name for name,a,b in [('EMA10_HIGH_EMA30_LOW',frame['ema10_high'],frame['ema30_low']),
            ('EMA10_LOW_EMA30_HIGH',frame['ema10_low'],frame['ema30_high'])] if min(a,b)<=c<=max(a,b)]
    ev['confirmation_audit']=dict(zones=zones,phase='BASELINE',original_route=ev['selected_route'],setup_time=None)
    zone_pass=ready and not zones
    # Retain original route diagnostics and add the independent zone gate.
    for name,gates in ev['route_checks'].items():
        gates['zone_confirmation_gate']=zone_pass
        if not zone_pass:
            ev['eligible_routes'][name]=False;ev['route_blockers'][name].append('zone_confirmation_gate')
    if not zone_pass:
        ev['selected_route']=None;ev['blockers'].append('NO_NEW_ENTRY_ZONE' if ready else 'EMA_ZONE_INDICATORS_NOT_READY')
    return ev
