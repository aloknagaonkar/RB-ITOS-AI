import importlib.util, json, os, sys, unittest
from copy import deepcopy
from datetime import datetime,timedelta
from pathlib import Path
from types import SimpleNamespace
from market_lab.hilega_rsi_two_route_v1 import VERSION
from market_lab.hilega_rsi_two_route_v1.policy import evaluate_entry,Indicators
from market_lab.hilega_rsi_two_route_v1.engine import Engine

def frame(side='CE',**kw):
    bull=side=='CE'
    f=dict(open=100 if bull else 109,high=110,low=99,close=109 if bull else 100,
        ema30_high=105,ema30_low=104,ema10_high=106,ema10_low=103,wma21_rsi9=60 if bull else 40,
        **{'rsi'+str(p):60 if bull else 40 for p in (5,9,14,21,28)})
    f.update(kw);return f

def market(frames,day='2026-11-26'):
    start=datetime.fromisoformat(day+'T09:15:00+05:30');bars=[];minutes=[]
    for i,f in enumerate(frames):
        t=start+timedelta(minutes=3*i);bar={k:f[k] for k in ('open','high','low','close')};bars.append(dict(start=t.isoformat(),**bar))
        for j in range(3):minutes.append(dict(timestamp=(t+timedelta(minutes=j)).isoformat(),**bar))
    t=start+timedelta(minutes=3*len(frames));minutes.append(dict(timestamp=t.isoformat(),**{k:frames[-1][k] for k in ('open','high','low','close')}))
    class Supplied:
        def __init__(self):self.i=0
        def update(self,bar):
            f=frames[self.i];self.i+=1;return {k:v for k,v in f.items() if k not in ('open','high','low','close')}
    return bars,minutes,Supplied

def engine_run(frames):
    bars,minutes,tracker=market(frames);e=Engine('2026-11-26');e.tracker=tracker()
    for bar in bars:e.advance(bar,minutes)
    return e

class EntryRules(unittest.TestCase):
    def test_normal_and_bypass_both_sides(self):
        for side in ('CE','PE'):
            f=frame(side,rsi14=50,rsi21=50,rsi28=50)
            self.assertEqual(evaluate_entry(f,side)['selected_route'],'Normal Route')
            f=frame(side,wma21_rsi9=40 if side=='CE' else 60)
            self.assertEqual(evaluate_entry(f,side)['selected_route'],'WMA_bypass')
            f['rsi28']=50;self.assertIsNone(evaluate_entry(f,side)['selected_route'])
    def test_every_entry_strength_including_direct_and_opposite(self):
        for side in ('CE','PE'):
            self.assertIsNotNone(evaluate_entry(frame(side),side)['selected_route'])
            f=frame(side,high=120 if side=='CE' else 110,low=99 if side=='CE' else 90)
            self.assertIsNone(evaluate_entry(f,side)['selected_route'])
            self.assertIn('adverse_wick_at_most_20pct',evaluate_entry(f,side)['blockers'])
    def test_equality_body_and_wick_allowed(self):
        for side in ('CE','PE'):
            f=frame(side,open=103 if side=='CE' else 108,close=108 if side=='CE' else 103,high=110,low=100,
                    ema30_high=102,ema30_low=104,ema10_high=101,ema10_low=102)
            ev=evaluate_entry(f,side)
            self.assertTrue(ev['moderate_entry_strength']['checks']['body_at_least_50pct'])
            self.assertTrue(ev['moderate_entry_strength']['checks']['adverse_wick_at_most_20pct'] if side=='CE' else True)
    def test_zones_inclusive_and_order_independent_both_directions(self):
        for side in ('CE','PE'):
            for a,b,c in [(102,106,104),(106,102,104),(102,106,102),(102,106,106)]:
                f=frame(side,close=c,ema10_high=a,ema30_low=b)
                ev=evaluate_entry(f,side);self.assertIn('EMA10_HIGH_EMA30_LOW',ev['confirmation_audit']['zones']);self.assertIsNone(ev['selected_route'])
            f=frame(side,ema10_low=100,ema30_high=110)
            self.assertIn('EMA10_LOW_EMA30_HIGH',evaluate_entry(f,side)['confirmation_audit']['zones'])
    def test_missing_zone_indicator_blocks_and_zero_range_rejected(self):
        self.assertIsNone(evaluate_entry(frame(ema10_high=None),'CE')['selected_route'])
        ev=evaluate_entry(frame(open=100,high=100,low=100,close=100),'CE')
        self.assertFalse(ev['moderate_entry_strength']['checks']['valid_candle'])

class Lifecycle(unittest.TestCase):
    def test_standalone_rsi_exit_without_midpoint_wma_or_price(self):
        for side in ('CE','PE'):
            f=frame(side,rsi5=40 if side=='CE' else 60,rsi9=40 if side=='CE' else 60,rsi14=50,rsi21=50,rsi28=50,
                ema30_high=120,ema30_low=90)
            e=engine_run([frame(side),f]);self.assertEqual(e.trades[0]['exit_reasons'],['RSI5_RSI9_MOMENTUM']);self.assertIsNone(e.active)
            self.assertFalse(e.trades[0]['exit_checks']['signal_midpoint_price_breach'])
            self.assertFalse(e.trades[0]['exit_checks']['all_three_exit'])
    def test_one_rsi_or_equality_does_not_exit(self):
        for side in ('CE','PE'):
            for key in ('rsi5','rsi9'):
                f=frame(side,rsi5=40 if side=='CE' else 60,rsi9=40 if side=='CE' else 60,rsi14=50,rsi21=50,rsi28=50)
                f[key]=50;e=engine_run([frame(side),f]);self.assertFalse(e.trades);self.assertEqual(e.active['side'],side)
    def test_zone_and_weak_candle_never_exit_owner(self):
        f=frame('CE',close=108,open=107.5,ema10_high=110,ema30_low=100)
        e=engine_run([frame('CE'),f]);self.assertEqual(e.active['side'],'CE');self.assertFalse(e.trades)
    def test_reversal_must_pass_zone_and_strength_exit_first(self):
        e=engine_run([frame('CE'),frame('PE')]);self.assertEqual(e.audits[1]['events'][0]['event'],'EXIT');self.assertEqual(e.audits[1]['events'][1]['event'],'ENTRY');self.assertEqual(e.active['side'],'PE')
        f=frame('PE',ema10_high=110,ema30_low=99,rsi5=50,rsi9=50,rsi14=40,rsi21=40,rsi28=40)
        e=engine_run([frame('CE'),f]);self.assertEqual(e.active['side'],'CE');self.assertFalse(e.trades)
    def test_external_activation_blocks_entry_without_blocking_exit(self):
        bars,rows,cls=market([frame('CE'),frame('CE',rsi5=40,rsi9=40,rsi14=50,rsi21=50,rsi28=50)])
        e=Engine('2026-11-26');e.tracker=cls();e.advance(bars[0],rows);e.advance(bars[1],rows,entry_block_reason='ACTIVATION_PENDING');self.assertEqual(len(e.trades),1);self.assertIsNone(e.active)
    def test_snapshot_roundtrip_and_version_guard(self):
        e=Engine('2026-11-26',[dict(start='2026-11-25T09:15:00+05:30',open=100,high=110,low=90,close=100)])
        state=e.snapshot();self.assertEqual(Engine.restore(state).snapshot(),state)
        self.assertEqual(e.tracker.h10,110);state['strategy_version']='OLD'
        with self.assertRaisesRegex(ValueError,'VERSION_MISMATCH'):Engine.restore(state)

class NativeParity(unittest.TestCase):
    def test_native_adapter_shares_engine_in_both_directions(self):
        from market_lab.hilega_three_minute_v1 import hilega_combined_policy_v1 as p
        from market_lab.hilega_milega_strategy_v1 import FiveMinuteBar
        f=[frame('CE'),frame('PE'),frame('PE',rsi5=60,rsi9=60,rsi14=50,rsi21=50,rsi28=50)]
        bars,rows,cls=market(f);t=p.PriceFrames();t.tracker=cls();t.minute_rows=rows;g=p.make_gate(t.frames)
        class Canonical:
            bullish=SimpleNamespace(previous_indicators=SimpleNamespace(ema3_rsi=50))
            def on_bar(self,bar):
                from dataclasses import dataclass
                @dataclass
                class Decision:
                    accepted_events:tuple=();suppressed_events:tuple=();trade_owner_after:str='NONE'
                return Decision()
        c=Canonical();out=[]
        for b in bars:out.append(p.advance_boundary(c,g,FiveMinuteBar(datetime.fromisoformat(b['start']),b['open'],b['high'],b['low'],b['close']),None,t))
        expected=engine_run(f)
        self.assertEqual(len(t.engine.trades),len(expected.trades))
        for actual,want in zip(t.engine.trades,expected.trades):
            for key in ('side','route_name','entry_time','exit_time','entry_price','exit_price','points','exit_reasons','peak_positive_points','giveback_points'):
                self.assertEqual(actual[key],want[key],key)
        self.assertTrue(all(len(r['checks'])==2 for r in out))
        from market_lab.hilega_rsi_two_route_v1.native_inspection import inspection
        inspected=inspection(dict(checks=out[0]['checks'],exit_validation=None));self.assertTrue(any(r['label'].endswith('EMA zone entry gate') for r in inspected))
        self.assertEqual(p.VERSION,VERSION);self.assertTrue(p.RULES['rsi_momentum_exit'])

if __name__=='__main__':unittest.main()
