import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import manage
class AuthorizedNativeCutover(unittest.TestCase):
 def report(self,**counts):return dict(status='BLOCKED_EXISTING_POSITIONS_OR_REQUESTS',counts=dict(native_active_owner=1,open_legs=0,pending_fill_orders=0,observer_open_positions=0,**counts))
 def test_flag_is_required_and_native_count_is_preserved(self):
  r=self.report()
  with self.assertRaises(ValueError):manage.validate_flat_report(r)
  out=manage.validate_flat_report(r,True)
  self.assertTrue(out['native_owner_cutover_authorized']);self.assertEqual(out['counts']['native_active_owner'],1);self.assertEqual(r['status'],'BLOCKED_EXISTING_POSITIONS_OR_REQUESTS')
 def test_no_external_or_unknown_blocker_can_be_waived(self):
  for key in ['open_legs','pending_fill_orders','uncertain_requests','legacy_open_trades','pending_manual_exits','observer_pending','observer_undelivered_events','observer_open_positions','unexpected_position']:
   r=self.report();r['counts'][key]=1
   with self.assertRaises(ValueError,msg=key):manage.validate_flat_report(r,True)
 def test_bad_counts_and_status_fail_closed(self):
  for value in [-1,True,'0',None]:
   r=self.report();r['counts']['open_legs']=value
   with self.assertRaises(ValueError):manage.validate_flat_report(r,True)
  r=self.report();r['status']='UNKNOWN'
  with self.assertRaises(ValueError):manage.validate_flat_report(r,True)
if __name__=='__main__':unittest.main()
