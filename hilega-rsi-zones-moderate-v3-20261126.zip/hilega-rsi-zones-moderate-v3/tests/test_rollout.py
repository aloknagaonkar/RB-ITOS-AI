import importlib.util,json,os,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch,MagicMock
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))
import manage
import check_flat
class RolloutGuards(unittest.TestCase):
 def test_execution_settings_are_preserved_byte_for_byte(self):
  for selected in ('HILEGA_V2_ALIGNMENT_DUAL_EXIT',manage.NEW):
   raw=('LIVE_SHADOW_STRATEGY='+selected+'\nHILEGA_PRODUCTION_WORKSPACE_MODE=SIMULATION_ONLY\nSECRET=never-print\n').encode()
   self.assertEqual(manage.selected_env(raw),raw)
 def test_other_strategy_cannot_be_overwritten(self):
  with self.assertRaises(ValueError):manage.selected_env(b'LIVE_SHADOW_STRATEGY=OTHER\n')
 def test_failed_prepare_never_installs_or_stops_services(self):
  with tempfile.TemporaryDirectory() as tmp,patch.object(sys,'argv',['manage.py','--install','--repo',tmp]),patch.object(manage,'prepare',side_effect=ValueError('SOURCE_CHANGED')),patch.object(manage,'apply') as apply,patch.object(manage,'ctl') as ctl:
   with self.assertRaises(ValueError):manage.main()
   apply.assert_not_called();ctl.assert_not_called()
 def test_cutover_ceil_to_complete_bar_start(self):
  from datetime import datetime
  at=datetime.fromisoformat('2026-11-26T10:51:01+05:30')
  self.assertEqual(manage.cutover_boundary(at).isoformat(),'2026-11-26T10:54:00+05:30')
 def probe(self,owner='NONE',pending=False,opened=False):
  old=Path.cwd()
  with tempfile.TemporaryDirectory() as tmp:
   try:
    os.chdir(tmp);root=Path('data/live-observation/hilega-strike-observation-v1');root.mkdir(parents=True)
    (root/'publisher-state.json').write_text(json.dumps(dict(pending={'x':{}} if pending else {},deliveries={})))
    import sqlite3
    db=sqlite3.connect(root/'observer.sqlite3');db.execute('CREATE TABLE state(is_open INTEGER)');db.execute('INSERT INTO state VALUES(?)',(int(opened),));db.commit();db.close()
    response=MagicMock();response.__enter__.return_value=response;response.read.return_value=json.dumps(dict(current=dict(trade_owner=owner))).encode()
    with patch.object(check_flat,'legacy_probe',return_value=dict(counts={'open_legs':0},broker_requests_sent=False)),patch('urllib.request.urlopen',return_value=response):return check_flat.probe()
   finally:os.chdir(old)
 def test_native_owner_blocks_cutover(self):self.assertEqual(self.probe('BULLISH')['status'],'BLOCKED_EXISTING_POSITIONS_OR_REQUESTS')
 def test_pending_observer_and_open_observer_block_cutover(self):
  self.assertEqual(self.probe(pending=True)['status'],'BLOCKED_EXISTING_POSITIONS_OR_REQUESTS')
  self.assertEqual(self.probe(opened=True)['status'],'BLOCKED_EXISTING_POSITIONS_OR_REQUESTS')
 def test_flat_native_and_observer_allow_cutover(self):self.assertEqual(self.probe()['status'],'LOCAL_LEDGERS_FLAT')
 def test_observer_contract_uses_new_version_and_ignores_old_journal_rows(self):
  spec=importlib.util.spec_from_file_location('native_contract',HERE/'files/hilega_policy_live/native_contract.py');contract=importlib.util.module_from_spec(spec);sys.modules['native_contract']=contract;spec.loader.exec_module(contract)
  spec=importlib.util.spec_from_file_location('updated_native_routing',HERE/'files/hilega_policy_live/native_routing.py');routing=importlib.util.module_from_spec(spec);spec.loader.exec_module(routing)
  self.assertEqual(contract.VERSION,manage.VERSION)
  routing.on_row(None,dict(payload=dict(strategy_id=manage.NEW,policy_id=manage.POLICY,strategy_version=manage.OLD_VERSION)))
  with self.assertRaises(contract.ContractBlocked):routing.on_row(None,dict(payload=dict(strategy_id=manage.NEW,policy_id=manage.POLICY,strategy_version='unexpected')))
if __name__=='__main__':unittest.main()
