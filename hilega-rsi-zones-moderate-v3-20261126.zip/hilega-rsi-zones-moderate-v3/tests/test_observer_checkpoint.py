import importlib.util,sys,unittest
from pathlib import Path
from datetime import datetime
from types import SimpleNamespace
HERE=Path(__file__).resolve().parents[1]
class ObserverCheckpoint(unittest.TestCase):
 def setUp(self):
  for name,filename in [('native_contract','native_contract.py'),('checkpoint_routing','native_routing.py')]:
   spec=importlib.util.spec_from_file_location(name,HERE/'files/hilega_policy_live'/filename);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
  self.routing=sys.modules['checkpoint_routing'];self.error=sys.modules['native_contract'].ContractBlocked
 def test_checkpoint_envelope_preserves_vm_fix(self):
  r=self.routing
  for at in ['09:15','15:29']:r.minute_time('2026-11-26T'+at+':00+05:30',checkpoint=True)
  for at in ['09:14','15:30']:
   with self.assertRaises(self.error):r.minute_time('2026-11-26T'+at+':00+05:30',checkpoint=True)
 def test_availability_envelope_remains_strict(self):
  r=self.routing
  for at in ['09:16','15:30']:r.minute_time('2026-11-26T'+at+':00+05:30')
  for at in ['09:15','15:31']:
   with self.assertRaises(self.error):r.minute_time('2026-11-26T'+at+':00+05:30')
 def test_first_completed_minute_is_price_only(self):
  r=self.routing;observer=SimpleNamespace(state={'closes':{},'pending':{}})
  row=dict(stage='COMBINED_PRICE_OBSERVATION',status='PROCESSED',checkpoint='2026-11-26T09:15:00+05:30',event_time='2026-11-26T09:16:00+05:30',payload=dict(strategy_id=r.STRATEGY,policy_id=r.POLICY,strategy_version=r.VERSION,decision_timestamp='2026-11-26T09:16:00+05:30',accepted_events=[],nifty_close=25800,reconstructed=False))
  r.on_row(observer,row,current=datetime.fromisoformat('2026-11-26T09:17:00+05:30'))
  self.assertEqual(list(observer.state['closes'].values()),[25800.0]);self.assertEqual(observer.state['pending'],{})
  row['checkpoint']='2026-11-26T09:16:00+05:30'
  with self.assertRaises(self.error):r.on_row(observer,row,current=datetime.fromisoformat('2026-11-26T09:17:00+05:30'))
if __name__=='__main__':unittest.main()
