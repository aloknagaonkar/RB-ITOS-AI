"""Actual Source guards on disposable state; no live databases, network or credentials."""
import argparse,hashlib,json,os,shutil,socket,sqlite3,subprocess,sys,uuid,copy
from contextlib import ExitStack
from datetime import datetime
from pathlib import Path

def deny_network(*a,**k):raise RuntimeError('NETWORK_DISABLED_FOR_REHEARSAL')
socket.socket.connect=deny_network;socket.socket.connect_ex=deny_network;socket.create_connection=deny_network

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--release',type=Path,required=True);ap.add_argument('--audit',type=Path,required=True);ap.add_argument('--backup',type=Path,required=True);ap.add_argument('--transition-package',type=Path,required=True);a=ap.parse_args()
    root=a.release.resolve();audit=a.audit.resolve();sys.path[:0]=[str(root/'backend'),str(root/'runtime'),str(a.transition_package)]
    from transition import transition
    from market_lab.hilega_production_foundation.core import Store,SimBroker,Service
    from market_lab.hilega_preparation_runtime_v1.source import Source
    from market_lab.hilega_exclusive_closed_route_v1 import closed_poll
    from market_lab.hilega_production_simulator_bridge_v1 import verified_records
    from market_lab.hilega_production_bridge_health_v1 import worker_lock,claim,heartbeat,finish
    from market_lab.hilega_native_preparation_contract_v1 import POLICY,VERSION,ENTRIES,EXITS
    journal=audit/'fixture-journal.jsonl';size=journal.stat().st_size
    outcomes=[]
    def counts(path):
        with sqlite3.connect(path) as db:
            names={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            return {n:db.execute('SELECT COUNT(*) FROM '+n).fetchone()[0] if n in names else 0 for n in ('preparation_consumed','preparation_events','preparation_plans','preparation_shadow_holds','preparation_outbox','intents','sim_orders','sim_fills')}
    with ExitStack() as leases, verified_records(journal) as history:
        last=history[-1]['record_hash'];sequence=len(history)
        # Exercise the actual complete CLI twice, with a migrated disposable cursor.
        cli=audit/'worker-startup';cli.mkdir(mode=0o700);cli_db=cli/'application.sqlite';shutil.copyfile(a.backup,cli_db)
        transition(cli_db,history,journal,sandbox=audit);empty=cli/'empty.env';empty.write_text('');runs=[]
        for attempt in range(2):
            env=dict(os.environ,HILEGA_PRODUCTION_SIM_DB=str(cli_db),HILEGA_PRODUCTION_SIM_BRIDGE_ENABLED='1',HILEGA_PREPARATION_ADAPTER_DB=str(cli/'unused-adapter.sqlite'))
            code='import runpy,socket,sys\ndef deny(*a,**k):raise RuntimeError("NETWORK_DISABLED_FOR_REHEARSAL")\nsocket.socket.connect=deny;socket.socket.connect_ex=deny;socket.create_connection=deny\np=sys.argv[1];sys.argv=sys.argv[1:];runpy.run_path(p,run_name="__main__")'
            run=subprocess.run([sys.executable,'-B','-c',code,str(root/'closed_worker_launcher.py'),'--once','--env-file',str(empty),'--source',str(journal)],cwd=cli,env=env,capture_output=True,text=True,timeout=90)
            (cli/('process-'+str(attempt)+'.json')).write_text(json.dumps(dict(exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr),indent=2))
            assert run.returncode==0,('FULL_WORKER_STARTUP_FAILED',run.stdout,run.stderr)
            with sqlite3.connect(cli_db) as db:
                health=json.loads(db.execute('SELECT data FROM sim_bridge_health WHERE id=1').fetchone()[0]);control=json.loads(db.execute('SELECT data FROM control WHERE id=1').fetchone()[0])
            assert health['phase']=='STOPPED' and control['mode']=='PAUSED' and control['production_execution_enabled'] is False
            runs.append(health['run_id'])
        assert runs[0]!=runs[1] and counts(cli_db)['preparation_plans']==0
        outcomes.append(dict(scenario='full_worker_restart',passed=True,source_freshness_qualified=False));print(json.dumps(outcomes[-1]),flush=True)
        for scenario in ('history','paused_and_replay','fresh_evidence_denied','stale','future','entry_clock','wrong_version','exit_only','reversal','signed_plan'):
            with journal.open('r+b') as f:f.truncate(size)
            folder=audit/scenario;folder.mkdir(mode=0o700);database=folder/'application.sqlite';shutil.copyfile(a.backup,database);database.chmod(0o600)
            transition(database,history,journal,sandbox=audit)
            initial=counts(database);clock=[datetime.fromisoformat('2026-11-25T10:02:59+05:30')]
            store=Store(database);service=Service(store,SimBroker(store),lambda:clock[0],worker_start=False)
            requests=[]
            def provider():
                requests.append('REQUESTED')
                if scenario=='signed_plan':return copy.deepcopy(bundle),fixture.PIN
                raise RuntimeError('NO_EVIDENCE_IN_REHEARSAL')
            leases.enter_context(worker_lock(database));run_id=claim(service)
            source=Source(service,run_id=run_id,provider=provider)
            if scenario not in ('history','paused_and_replay','wrong_version','exit_only','reversal'):
                if scenario=='entry_clock':clock[0]=datetime.fromisoformat('2026-11-25T14:54:59+05:30')
                heartbeat(service,run_id,source_at=clock[0].isoformat())
                for action in ('reconcile','resume'):
                    c=store.control();service.command(action,request_id=uuid.uuid4().hex,expected_version=c['version'],actor='DISPOSABLE_NATIVE_TEST',session_date=c['session_date'])
                assert store.control()['mode']=='ARMED','SYNTHETIC_ARM_FAILED'
            clock[0]=datetime.fromisoformat('2026-11-25T14:57:00+05:30' if scenario=='entry_clock' else '2026-11-25T10:03:00+05:30')
            if scenario=='signed_plan':
                import synthetic_evidence as fixture
                fixture.T=datetime.fromisoformat('2026-11-25T10:03:00+05:30')
                bundle=fixture.bundle()
                def dates(value):
                    if isinstance(value,dict):return {k:dates(v) for k,v in value.items()}
                    if isinstance(value,list):return [dates(v) for v in value]
                    if isinstance(value,str):return value.replace('2026-10-26','2026-11-25').replace('2026-10-27','2026-12-01')
                    return value
                bundle=dates(bundle);fixture.resign_cash(bundle)
                adapter=folder/'adapter.sqlite'
                with sqlite3.connect(adapter) as db:
                    db.executescript('CREATE TABLE meta(id INTEGER PRIMARY KEY,data TEXT);CREATE TABLE requests(id TEXT);CREATE TABLE attempts(id TEXT);CREATE TABLE receipts(id TEXT);')
                    db.execute('INSERT INTO meta VALUES(1,?)',(json.dumps(dict(scope=fixture.PIN['scope'],mode='LIVE_CLOSED')),))
                os.environ['HILEGA_PREPARATION_ADAPTER_DB']=str(adapter)
                clock[0]=datetime.fromisoformat('2026-11-25T10:03:03+05:30')
                try:fixture.validate(bundle,fixture.PIN,as_of=clock[0].isoformat())
                except Exception as e:
                    print(json.dumps(dict(scenario=scenario,stage='SIGNED_FIXTURE_VALIDATION',error_type=type(e).__name__,reason=str(e) if str(e).replace('_','').isalnum() else 'DETAILS_SUPPRESSED')),flush=True)
                    raise
            if scenario!='history':
                stamp={'stale':'2026-11-25T09:18:00+05:30','future':'2026-11-25T10:06:00+05:30','entry_clock':'2026-11-25T14:57:00+05:30'}.get(scenario,'2026-11-25T10:03:00+05:30');name=next(iter(ENTRIES))
                names=[next(iter(EXITS))] if scenario=='exit_only' else [list(ENTRIES)[1],next(iter(EXITS))] if scenario=='reversal' else [name]
                row=dict(sequence=sequence+1,previous_hash=last,stage='DIRECTIONAL_DECISION',status='PROCESSED',payload=dict(policy_id=POLICY,strategy_version='UNREVIEWED_NATIVE_VERSION' if scenario=='wrong_version' else VERSION,reconstructed=False,decision_timestamp=stamp,accepted_events=names,event_details=[dict(event_type=n,event_time=stamp,entry_time=stamp,exit_reason='SYNTHETIC_EXIT') for n in names]))
                row['record_hash']=hashlib.sha256(json.dumps(row,sort_keys=True,separators=(',',':'),ensure_ascii=False,default=str).encode()).hexdigest()
                with journal.open('a') as f:f.write(json.dumps(row)+'\n')
            heartbeat(service,run_id,source_at=clock[0].isoformat())
            error=None
            try:result=closed_poll(source,journal)
            except Exception as e:error=str(e)
            if scenario=='wrong_version':assert error=='SOURCE_POLICY_OR_VERSION_MISMATCH',(scenario,error)
            else:assert error is None,(scenario,error)
            after=counts(database)
            assert all(after[n]==initial[n] for n in ('intents','sim_orders','sim_fills')),'UNEXPECTED_ORDER'
            assert all(after[n]==initial[n]+(1 if scenario=='signed_plan' else 0) for n in ('preparation_plans','preparation_shadow_holds','preparation_outbox')),'UNEXPECTED_PREPARATION_COUNT'
            if scenario=='history':
                assert after==initial and not requests,'HISTORY_REPLAYED'
                reason='HISTORY_BASELINED_WITHOUT_DISPATCH'
            elif scenario in ('exit_only','reversal'):
                with store.db() as db:
                    dispatch=json.loads(db.execute('SELECT data FROM preparation_exit_dispatch').fetchone()[0])
                assert dispatch['dispatch_status']=='REFUSED_CLOSED' and dispatch['orders_sent'] is False and dispatch['automatic_execution_eligible'] is False
                assert dispatch['reversal_entry_suppressed']==(scenario=='reversal') and not requests
                assert after['preparation_consumed']==initial['preparation_consumed']+(2 if scenario=='reversal' else 1)
                closed_poll(source,journal);assert counts(database)==after,'EXIT_REPLAY_CHANGED_STATE'
                reason='EXIT_OR_REVERSAL_REQUIRES_LIVE_OWNERSHIP'
            elif scenario=='signed_plan':
                assert len(requests)==1
                with store.db() as db:
                    plan=json.loads(db.execute('SELECT data FROM preparation_plans').fetchone()[0]);outbox=json.loads(db.execute('SELECT data FROM preparation_outbox').fetchone()[0])
                assert plan['status']=='EVIDENCE_LINKED_UNSENT' and plan['production_execution_enabled'] is False and outbox['request_body'] is None
                closed_poll(source,journal);assert counts(database)==after and len(requests)==1,'PLAN_REPLAY_CHANGED_STATE'
                reason='SYNTHETIC_SIGNED_EVIDENCE_LINKED_UNSENT'
            elif scenario=='wrong_version':
                assert after['preparation_consumed']==initial['preparation_consumed'] and not requests
                reason=error
            else:
                with store.db() as db:
                    event=json.loads(db.execute('SELECT data FROM preparation_events ORDER BY seq DESC LIMIT 1').fetchone()[0])
                reason={'paused_and_replay':'CONTROLLER_PAUSED_OR_STOP_PENDING','fresh_evidence_denied':'EVIDENCE_PROVIDER_UNAVAILABLE','stale':'SIGNAL_STALE_FUTURE_OR_PRE_RESUME','future':'SIGNAL_STALE_FUTURE_OR_PRE_RESUME','entry_clock':'ENTRY_CLOCK_WINDOW_CLOSED'}[scenario]
                assert reason in event['reasons'],(scenario,event['reasons'])
                assert len(requests)==(1 if scenario=='fresh_evidence_denied' else 0),'UNEXPECTED_EVIDENCE_REQUEST'
                assert after['preparation_consumed']==initial['preparation_consumed']+1
                if scenario=='paused_and_replay':
                    closed_poll(source,journal);assert counts(database)==after,'REPLAY_MUTATED_STATE'
            assert store.control()['mode']=='PAUSED','FIXTURE_LEFT_ARMED'
            assert finish(service,run_id),'FIXTURE_LEASE_FINISH_FAILED'
            outcomes.append(dict(scenario=scenario,passed=True,reason=reason));print(json.dumps(outcomes[-1]),flush=True)
    report=dict(status='DISPOSABLE_NATIVE_SOURCE_GUARD_INTEGRATION_PASS',scenarios=outcomes,actual_sealed_source_guard_executed=True,native_disposable_worker_lease_used=True,health_times_synthetic=True,synthetic_database_arm_only=True,signed_evidence_to_unsent_plan_verified=True,evidence_fixture_only=True,exit_dispatch_verified=True,exit_scope="REFUSED_CLOSED_WITHOUT_OWNERSHIP",full_worker_startup_verified=True,managed_service_health_verified=False,live_database_opened=False,live_cursor_modified=False,services_changed=False,production_execution_enabled=False,live_apply_available=False)
    (audit/'RESULT.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
