"""Atomic observer file transaction; no database writes, service actions or network."""
import hashlib,json,os,tempfile
from pathlib import Path
def need(ok,reason):
    if not ok:raise ValueError(reason)
def raw(p):
    need(p.is_absolute() and not any(q.is_symlink() for q in (p,*p.parents)),'REGULAR_ABSOLUTE_PATH_REQUIRED');return p.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def atomic(p,b,mode=0o600):
    need(not any(q.is_symlink() for q in (p,*p.parents)),'SYMLINK_REJECTED');fd,name=tempfile.mkstemp(dir=p.parent)
    try:
        os.fchmod(fd,mode)
        with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
        os.replace(name,p);fd=os.open(p.parent,os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    finally:
        if os.path.exists(name):os.unlink(name)
def install(entries,audit,checkpoint=lambda name:None):
    originals=[]
    for i,e in enumerate(entries):
        p=e['path'];old=raw(p) if p.exists() else None
        need((sha(old) if old is not None else None)==e['before_sha256'],'TARGET_CHANGED')
        mode=(p.stat().st_mode&0o777) if old is not None else 0o600
        originals.append((p,old,mode))
        if old is not None:atomic(audit/('original-'+str(i)),old)
    atomic(audit/'ORIGINALS.json',(json.dumps([dict(path=str(p),sha256=sha(b) if b is not None else None,mode=m) for p,b,m in originals],indent=2)+'\n').encode())
    try:
        for i,(e,(_,_,mode)) in enumerate(zip(entries,originals),1):
            current=raw(e['path']) if e['path'].exists() else None
            need((sha(current) if current is not None else None)==e['before_sha256'],'TARGET_CHANGED_DURING_INSTALL')
            atomic(e['path'],e['after'],mode);checkpoint('AFTER_FILE_'+str(i))
        return originals
    except BaseException:
        restore(entries,originals);raise

def restore(entries,originals):
    for e,(p,b,mode) in reversed(list(zip(entries,originals))):
        current=raw(p) if p.exists() else None
        need((sha(current) if current is not None else None) in {sha(e['after']),sha(b) if b is not None else None},'RESTORE_CONFLICT')
        if b is None:
            if p.exists():
                p.unlink();fd=os.open(p.parent,os.O_DIRECTORY)
                try:os.fsync(fd)
                finally:os.close(fd)
        else:atomic(p,b,mode)
