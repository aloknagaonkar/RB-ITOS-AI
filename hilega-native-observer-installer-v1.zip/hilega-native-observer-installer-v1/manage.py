"""Install exact native observer proposal while stopped; never start or enable trading."""
import argparse,fcntl,hashlib,importlib.util,json,os,sqlite3,subprocess,sys,tempfile,time
from contextlib import ExitStack
from pathlib import Path
from files import need,raw,sha,atomic,install,restore
HERE=Path(__file__).resolve().parent
PLAN_SHA='2aa428ce7dcc4b8a0ce16e8788f4dccb6d02b22363f3a5697853a5ae2525ab60'
def encoded(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def load(p):return json.loads(raw(p))
def save(p,v):atomic(p,encoded(v))
def verify(folder):
    for n,h in load(folder/'MANIFEST.json').items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts and sha(raw(folder/rel))==h,'PACKAGE_CHANGED')
def stopped(repo):
    targets={str(repo/'scripts/hilega_policy_observer_service.py').encode(),str(repo/'hilega_policy_live/publisher.py').encode()}
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name)==os.getpid():continue
        try:
            if p.stat().st_uid==os.getuid():need(not targets.intersection((p/'cmdline').read_bytes().split(b'\0')),'OBSERVER_MUST_REMAIN_STOPPED')
        except (FileNotFoundError,ProcessLookupError):pass

def observer_db(p):
    path=Path(p['observer_db']);need(path.is_file() and not any(q.is_symlink() for q in (path,*path.parents)),'REGULAR_DATABASE_REQUIRED')
    with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN');need(db.execute('SELECT COUNT(*) FROM state WHERE is_open!=0').fetchone()[0]==0,'OPEN_OBSERVATIONS')
        snapshot={n:db.execute('SELECT * FROM '+n+' ORDER BY '+k).fetchall() for n,k in (('seen','id'),('state','id'),('outbox','seq'),('cursor','key'))}
    need(sha(encoded(snapshot))==p['observer_database_rows_sha256'],'OBSERVER_DATABASE_CHANGED')

def application(repo):
    path=repo/'data/research/hilega-production-workspace/sim.sqlite';need(path.is_file() and not any(q.is_symlink() for q in (path,*path.parents)),'REGULAR_APPLICATION_DATABASE_REQUIRED')
    with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN');c=json.loads(db.execute('SELECT data FROM control WHERE id=1').fetchone()[0]);r=json.loads(db.execute('SELECT data FROM preparation_route WHERE id=1').fetchone()[0])
    need(c['mode']=='PAUSED' and c['production_execution_enabled'] is False and c['simulation_only'] is True and r['route']=='PREPARATION_ONLY','PAUSED_CLOSED_REQUIRED')

def check_inputs(p,folder,repo):
    stopped(repo);application(repo);observer_db(p)
    for n,h in p['bindings'].items():need(sha(raw(Path(n)))==h,'BOUND_SOURCE_CHANGED')
    for n,h in p['payload_hashes'].items():
        need(Path(n).name==n and sha(raw(folder/'payload'/n))==h,'PAYLOAD_CHANGED')
    need(sha(raw(Path(p['state_path'])))==p['state_sha256'] and sha(raw(folder/'original-state.json'))==p['state_sha256'],'OBSERVER_STATE_CHANGED')
    need(sha(raw(folder/'archived-exit-requests.json'))==p['archived_exits_sha256'],'EXIT_ARCHIVE_CHANGED')
    need(sha(raw(Path(p['review'])))==p['review_sha256'],'REVIEW_CHANGED')
    for n in ('native_routing.py','native_contract.py'):need(not (repo/'hilega_policy_live'/n).exists(),'ROUTING_TARGET_EXISTS')
    proposed=load(folder/'payload/publisher-state.json');old=load(folder/'original-state.json');need(not any(proposed.get(n) for n in ('pending','deliveries','exits','closes')),'EXACT_EMPTY_TRANSITION_REQUIRED')
    expected=dict(old,sequence=p['baseline_sequence'],previous_hash=p['baseline_previous_hash'],offset=p['baseline_offset'],source_identity=p['source_identity'],pending={},deliveries={},exits={},closes={});need(proposed==expected,'PROPOSED_STATE_SCOPE_CHANGED')
    need(len(load(folder/'archived-exit-requests.json'))==p['exit_requests_archived'] and load(folder/'archived-exit-requests.json')==old.get('exits',{}),'EXIT_HISTORY_NOT_PRESERVED')
    contract=repo/'hilega-native-preparation-contract-v1';reader=repo/'hilega-source-reader-candidate-v3';verify(contract);verify(reader);sys.path.insert(0,str(contract));s=importlib.util.spec_from_file_location('installer_reader',contract/'review.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
    journal=Path(p['journal']);need(journal==repo/'data/live-observation/hilega-directional-v1/step-audit.jsonl','EXACT_JOURNAL_REQUIRED')
    stat=journal.stat();need(not any(q.is_symlink() for q in (journal,*journal.parents)) and [stat.st_dev,stat.st_ino]==p['source_identity'] and stat.st_size==p['baseline_offset'],'JOURNAL_CHANGED_REPLAN')
    with v.reader(reader/'candidate.py')(journal) as rows:need(len(rows)==p['baseline_sequence'] and rows[-1]['record_hash']==p['baseline_previous_hash'],'JOURNAL_PREFIX_CHANGED')
    need(journal.stat().st_size==p['baseline_offset'],'JOURNAL_CHANGED_DURING_CHECK')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);ap.add_argument('--action',choices=('check','apply'),default='check');ap.add_argument('--check',type=Path);ap.add_argument('--check-sha256');a=ap.parse_args();repo=a.repo.resolve();verify(HERE)
    folder=repo/'hilega-native-observer-transition-plan-zgqgq4hn';path=folder/'PLAN.json';need(sha(raw(path))==PLAN_SHA,'EXACT_TRANSITION_PLAN_REQUIRED');p=load(path)
    need(p['model']=='HILEGA_NATIVE_OBSERVER_TRANSITION_PROPOSAL_V1' and p['repo']==str(repo) and p['production_execution_enabled'] is False,'EXACT_OBSERVER_PLAN_REQUIRED')
    data=repo/'data/live-observation/hilega-strike-observation-v1';need(Path(p['state_path'])==data/'publisher-state.json' and Path(p['observer_db'])==data/'observer.sqlite3','EXACT_OBSERVER_DESTINATIONS_REQUIRED')
    with ExitStack() as locks:
        # These are the supervisor, collector and observation-store writer locks.
        for name in ('supervisor.lock','integration.lock','shadow_strike_obs.jsonl.lock'):
            lock=data/name;need(not any(q.is_symlink() for q in (lock,*lock.parents)),'LOCK_SYMLINK');fd=os.open(lock,os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600);held=locks.enter_context(os.fdopen(fd,'r+'));fcntl.flock(held,fcntl.LOCK_EX|fcntl.LOCK_NB)
        journal=locks.enter_context(Path(p['journal']).open('rb'));fcntl.flock(journal,fcntl.LOCK_SH)
        check_inputs(p,folder,repo)
        if a.action=='check':
            audit=Path(tempfile.mkdtemp(prefix='observer-installer-check-',dir=folder));audit.chmod(0o700)
            r=subprocess.run([sys.executable,'-B',str(HERE/'rehearse.py'),'--output',str(audit/'rehearsal')],capture_output=True,text=True,timeout=60);save(audit/'REHEARSAL-PROCESS.json',dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));print(r.stdout+r.stderr,flush=True);need(r.returncode==0,'INSTALL_REHEARSAL_FAILED')
            # Import/configuration-only CLI probe on a clean staged copy. No constructor/run/start_stream.
            stage=audit/'probe';stage.mkdir(mode=0o700)
            for n in ('publisher.py','native_routing.py','native_contract.py'):atomic(stage/n,raw(folder/'payload'/n))
            for n in ('observer.py','active_marks.py'):atomic(stage/n,raw(repo/'hilega_policy_live'/n))
            env=dict(PATH=os.defpath,LANG='C.UTF-8',HOME=str(audit),PYTHONDONTWRITEBYTECODE='1')
            r=subprocess.run([sys.executable,'-B',str(stage/'publisher.py'),'--check','--config',str(repo/'hilega_policy_live/config.json')],cwd=stage,env=env,capture_output=True,text=True,timeout=60);save(audit/'IMPORT-CHECK.json',dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));need(r.returncode==0,'CANDIDATE_IMPORT_CHECK_FAILED: '+str(audit));probe=json.loads(r.stdout);need(probe['observation_only'] is True and probe['execution_enabled'] is False,'OBSERVATION_ONLY_PROBE_REQUIRED')
            check_inputs(p,folder,repo);check=dict(status='NATIVE_OBSERVER_INSTALL_CHECK_PASS',created_at=time.time(),plan_sha256=PLAN_SHA,installer_manifest_sha256=sha(raw(HERE/'MANIFEST.json')),rehearsal_sha256=sha(raw(audit/'REHEARSAL-PROCESS.json')),import_check_sha256=sha(raw(audit/'IMPORT-CHECK.json')),candidate_configuration_status=probe['status'],observer_started=False,production_execution_enabled=False);save(audit/'CHECK.json',check)
            print(json.dumps(dict(status=check['status'],check=str(audit/'CHECK.json'),check_sha256=sha(raw(audit/'CHECK.json')),candidate_configuration_status=probe['status'],observer_state_modified=False,observer_started=False,production_execution_enabled=False),indent=2));return
        need(a.check and a.check_sha256,'EXACT_CHECK_REQUIRED');cp=a.check.absolute();need(sha(raw(cp))==a.check_sha256,'CHECK_CHANGED');check=load(cp)
        need(check['status']=='NATIVE_OBSERVER_INSTALL_CHECK_PASS' and check['plan_sha256']==PLAN_SHA and check['installer_manifest_sha256']==sha(raw(HERE/'MANIFEST.json')),'CHECK_SCOPE_CHANGED');need(0<=time.time()-check['created_at']<=1800,'CHECK_EXPIRED');need(check['rehearsal_sha256']==sha(raw(cp.parent/'REHEARSAL-PROCESS.json')) and check['import_check_sha256']==sha(raw(cp.parent/'IMPORT-CHECK.json')),'CHECK_PROOF_CHANGED')
        audit=Path(tempfile.mkdtemp(prefix='observer-install-transaction-',dir=folder));audit.chmod(0o700);print('AUDIT: '+str(audit),flush=True)
        def phase(s):save(audit/'TRANSACTION.json',dict(phase=s,application_cursor_modified=False,database_restore_performed=False,observer_started=False,production_execution_enabled=False))
        for n in ('original-state.json','archived-exit-requests.json'):atomic(audit/n,raw(folder/n))
        with sqlite3.connect(Path(p['observer_db']).as_uri()+'?mode=ro',uri=True) as src,sqlite3.connect(audit/'observer-backup.sqlite3') as dst:src.backup(dst)
        (audit/'observer-backup.sqlite3').chmod(0o600)
        entries=[]
        for n in ('publisher.py','native_routing.py','native_contract.py','publisher-state.json'):
            dest=Path(p['state_path']) if n=='publisher-state.json' else repo/'hilega_policy_live'/n
            entries.append(dict(path=dest,before_sha256=sha(raw(dest)) if dest.exists() else None,after=raw(folder/'payload'/n)))
        originals=None;phase('BACKUPS_COMPLETE_OBSERVER_STOPPED')
        try:
            check_inputs(p,folder,repo);originals=install(entries,audit)
            for e in entries:need(sha(raw(e['path']))==sha(e['after']),'POST_INSTALL_FILE_CHANGED')
            observer_db(p);application(repo);stopped(repo);phase('NATIVE_OBSERVER_INSTALLED_STOPPED')
            report=dict(status='NATIVE_OBSERVER_INSTALLED_STOPPED',audit=str(audit),observer_baseline_sequence=p['baseline_sequence'],archived_exit_requests=p['exit_requests_archived'],observer_history_preserved=True,observer_database_modified=False,application_cursor_modified=False,observer_started=False,publishing_health_verified=False,live_qualification_complete=False,production_execution_enabled=False);save(audit/'RESULT.json',report);print(json.dumps(report,indent=2))
        except BaseException:
            phase('INSTALL_FAILED_RESTORING_FILES')
            try:
                stopped(repo)
                if originals is not None:restore(entries,originals)
                for e in entries:
                    current=sha(raw(e['path'])) if e['path'].exists() else None
                    need(current==e['before_sha256'],'FILE_RESTORE_NOT_VERIFIED')
                need(sha(raw(Path(p['state_path'])))==p['state_sha256'],'STATE_RESTORE_NOT_VERIFIED');observer_db(p);phase('ORIGINAL_FILES_AND_STATE_RESTORED_OBSERVER_STOPPED')
            except BaseException:phase('RECOVERY_REQUIRES_REVIEW_OBSERVER_START_FORBIDDEN')
            raise
if __name__=='__main__':
    try:main()
    except Exception as e:
        print(json.dumps(dict(status='NATIVE_OBSERVER_INSTALL_BLOCKED',reason=str(e) if type(e) is ValueError else type(e).__name__,production_execution_enabled=False)));raise SystemExit(2)
