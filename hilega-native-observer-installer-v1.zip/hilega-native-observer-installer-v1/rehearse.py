"""Disposable real file transaction, never live files or services."""
import argparse,json
from pathlib import Path
from files import install,sha

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();a.output.mkdir(mode=0o700);results=[]
    for fault in ('SUCCESS','AFTER_FILE_1','AFTER_FILE_2','AFTER_FILE_3','AFTER_FILE_4','changed_target'):
        folder=a.output/fault;folder.mkdir(mode=0o700);audit=folder/'audit';audit.mkdir(mode=0o700);entries=[]
        for i in range(4):
            p=folder/str(i);b=b'original' if i in (0,3) else None
            if b is not None:p.write_bytes(b)
            entries.append(dict(path=p,before_sha256=sha(b) if b is not None else None,after=b'candidate'))
        if fault=='changed_target':entries[0]['path'].write_bytes(b'changed')
        def checkpoint(name):
            if name==fault:raise RuntimeError('INJECTED')
        failed=False
        try:install(entries,audit,checkpoint)
        except (RuntimeError,ValueError):failed=True
        assert failed==(fault!='SUCCESS')
        for i,e in enumerate(entries):
            p=e['path']
            if fault=='SUCCESS':assert p.read_bytes()==b'candidate'
            elif i in (0,3):assert p.read_bytes()==(b'changed' if fault=='changed_target' and i==0 else b'original')
            else:assert not p.exists()
        results.append(dict(scenario=fault,passed=True))
    report=dict(status='DISPOSABLE_OBSERVER_FILE_INSTALL_PASS',scenarios=results,services_changed=False,database_writes_performed=False,process_crash_or_power_loss_recovery_verified=False)
    (a.output/'RESULT.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
