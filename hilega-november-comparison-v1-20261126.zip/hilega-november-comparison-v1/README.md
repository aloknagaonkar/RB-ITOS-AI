# November 2026 matched strategy research

Run from the repository root:

    .venv/bin/python -u -B hilega-november-comparison-v1/run.py --through 2026-11-25

The package compares the installed current Engine, RSI exit only, RSI exit plus EMA zones, strict/moderate confirmation outside zones, and strict/moderate confirmation allowing inside-zone entries.

All sessions use identical target candles and 20 verified prior sessions. Target candles are fetched fresh; valid prior-session raw caches are read without modification. Missing or invalid warmup candles are fetched into this run's own research folder. No replay result cache is reused. Session selection uses the installed reviewed 2026 calendar, including the special 8 November session. Future/current incomplete days are rejected.

Results are written beneath data/research/november-seven-configs-TIMESTAMP. Open index.html after unzipping the output ZIP. Date/configuration/direction filters cover monthly totals, day-wise metrics and all trades. Each day links to a full both-direction 3-minute audit. report.json identifies blocked sessions; daily-summary.csv and trades.csv support external analysis. Inputs and their hashes are retained for reproducibility.

A day enters matched totals only if all seven variants finish successfully. Partial runs are labeled PARTIAL_OR_RUNNING and return exit code 2. Only COMPLETE represents all expected sessions. Peak sums are per-trade excursions, not a simultaneous equity peak. Research NIFTY points exclude option fills, fees and slippage; this is not actual trading history. Current strategy is the installed pure Engine with its existing exits, before any of these research modifications. Intraday deployment cutovers/manual actions are not reconstructed.

No installed source, .env, existing candle caches, live journals, controls, services or broker orders are modified. This package makes read-only market-data requests and writes its own research results.
