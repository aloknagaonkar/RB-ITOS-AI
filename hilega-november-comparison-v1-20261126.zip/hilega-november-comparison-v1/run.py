#!/usr/bin/env python3
"""November research comparison. Writes only its own data/research directory."""
import argparse, csv, hashlib, html, importlib.util, json, os, sys, zipfile
from datetime import date, datetime, timedelta
from pathlib import Path

VARIANTS=[
 ('CURRENT_STRATEGY','current',None),
 ('RSI_EXIT_ONLY','rsi',None),
 ('RSI_EXIT_EMA_ZONES','old',None),
 ('STRICT_OUTSIDE_ZONES','old',(70,70,15,True)),
 ('MODERATE_OUTSIDE_ZONES','old',(50,60,20,False)),
 ('STRICT_ALLOW_CONFIRMED_ZONE_ENTRIES','inside',(70,70,15,True)),
 ('MODERATE_ALLOW_CONFIRMED_ZONE_ENTRIES','inside',(50,60,20,False))]
HERE=Path(__file__).resolve().parent

def imported(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

def code_hash(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def metrics(r):
    s=dict(r['summary']);trades=r['trades']
    s.update(gross_profit=sum(max(0,t['points']) for t in trades),
             gross_loss=-sum(min(0,t['points']) for t in trades),
             confirmed_entries_inside_zones=sum((t['entry_evaluation'].get('confirmation_audit') or {}).get('phase')=='FOLLOWUP_CONFIRMED_INSIDE_ZONE' for t in trades))
    return s

def write_csv(path,rows,fields):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)

def monthly_html(root,daily,trades,calendar_rows,status):
    payload=json.dumps(dict(daily=daily,trades=trades,calendar=calendar_rows),allow_nan=False).replace('<','\\u003c')
    template='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Hilega November strategy comparison</title><style>:root{color-scheme:dark}body{background:#10232d;color:#e3edf2;font:15px/1.5 system-ui;margin:26px}h1,h2{color:#8de4c0}p,small{max-width:1150px}select,button{background:#213b49;color:white;padding:9px;border:1px solid #516d7c;margin:5px}label{display:inline-block}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;white-space:nowrap;font-size:13px}td,th{padding:10px;text-align:right;border-bottom:1px solid #405a68}th{background:#203a48}td:first-child,th:first-child{text-align:left}.pos{color:#8de4c0}.neg{color:#ff999f}a{color:#8dcfff}.note{padding:15px;background:#203a48;border-left:3px solid #d5b674}details{margin:15px 0}small{color:#b3c7d2}@media print{body{background:white;color:black}select,button{display:none}.scroll{overflow:visible}table{font-size:9px;white-space:normal}th{background:#eee;color:black}.pos{color:green}.neg{color:#b00000}}</style><h1>November 2026 · Seven strategy configurations</h1><p class="note">STATUS_TEXT. Full-day research, not executed-trade history. Current strategy means the installed shared Engine with its existing exits. Other variants add the RSI5/RSI9 exit. NIFTY points; option premiums, fees and slippage are excluded. No live changes.</p><p>Every variant uses the same validated target candles and exactly 20 verified prior sessions. Completed 3m signals; next 1m OPEN reference fills, final 15:29 CLOSE. EMA no-entry zones use the completed close. Strict: setup/follow-up body ≥70%, each wick ≤15%. Moderate: setup ≥50%, follow-up ≥60%, adverse wick ≤20%. Confirmation applies when the setup range touches its directional zone. Direct entries beyond that zone do not require candle strength. Only the next candle may confirm; original setup midpoint retained.</p><p>Inside-zone variants waive zone clearance only for a valid strong follow-up; RSI, route and original EMA30 price requirements still apply. Both confirmed-inside and outside variants keep their direct-entry gates matched. Summed peaks are individual trade excursions, not a simultaneous portfolio maximum.</p><div><label>Date <select id="day"><option value="">All tested dates</option></select></label><label>Configuration <select id="variant"><option value="">All configurations</option></select></label><label>Trend <select id="side"><option value="">Both</option><option value="CE">Bullish / CE</option><option value="PE">Bearish / PE</option></select></label><button onclick="window.print()">Print / Save PDF</button></div><h2>Filtered comparison</h2><p id="coverage"></p><div class="scroll"><table><thead><tr><th>Configuration</th><th>Sessions</th><th>Trades</th><th>Wins</th><th>Losses</th><th>Gross profit</th><th>Gross loss</th><th>Net</th><th>Peak sum</th><th>Giveback</th><th>Δ vs current</th><th>Inside-zone entries</th></tr></thead><tbody id="totals"></tbody></table></div><h2>Day-wise results</h2><div class="scroll"><table><thead><tr><th>Date</th><th>Configuration</th><th>Trades</th><th>Wins</th><th>Losses</th><th>Net</th><th>Peak +</th><th>Giveback</th><th>Δ vs current</th><th>Audit</th></tr></thead><tbody id="days"></tbody></table></div><h2>Every entry / exit</h2><div class="scroll"><table><thead><tr><th>Date</th><th>Configuration</th><th>Direction</th><th>Route</th><th>Setup</th><th>Entry</th><th>Exit</th><th>Entry NIFTY</th><th>Exit NIFTY</th><th>Net</th><th>Peak +</th><th>Giveback</th><th>Entry path</th><th>Exit reason</th></tr></thead><tbody id="trades"></tbody></table></div><h2>Coverage / skipped sessions</h2><pre id="calendar"></pre><p><small>Unzip the complete report before opening it so daily audit links work. Each daily audit includes every completed 3-minute candle, both directions, indicator values, setup/follow-up checks and exit decisions. CSV files support further analysis. Incomplete/failed days are explicitly reported and excluded from full matched totals.</small></p><script>const D=PAYLOAD;const $=id=>document.getElementById(id),f=n=>Number(n).toFixed(2),sg=n=>(n>=0?'+':'')+f(n),cell=v=>'<td>'+v+'</td>',net=n=>'<td class="'+(n>=0?'pos':'neg')+'">'+sg(n)+'</td>';const variants=[...new Set(D.daily.map(r=>r.variant))];[...new Set(D.daily.map(r=>r.day))].sort().forEach(d=>{const o=document.createElement('option');o.value=d;o.textContent=d;$('day').append(o)});variants.forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v;$('variant').append(o)});function render(){const day=$('day').value,v=$('variant').value,side=$('side').value;const scope=D.daily.filter(r=>(!day||r.day===day));const ts=D.trades.filter(r=>(!day||r.day===day)&&(!side||r.side===side));const sums={};scope.forEach(r=>{const a=ts.filter(t=>t.day===r.day&&t.variant===r.variant);const val={day:r.day,variant:r.variant,trades:a.length,winners:a.filter(t=>t.net>0).length,losers:a.filter(t=>t.net<0).length,net:a.reduce((x,t)=>x+t.net,0),peak:a.reduce((x,t)=>x+t.peak,0),giveback:a.reduce((x,t)=>x+t.giveback,0),gross_profit:a.reduce((x,t)=>x+Math.max(t.net,0),0),gross_loss:a.reduce((x,t)=>x-Math.min(t.net,0),0),inside:a.filter(t=>t.entry_path==='FOLLOWUP_CONFIRMED_INSIDE_ZONE').length};sums[r.day+'|'+r.variant]=val});const base=Object.values(sums).filter(r=>r.variant==='CURRENT_STRATEGY').reduce((s,r)=>s+r.net,0);$('totals').innerHTML=variants.filter(x=>!v||x===v).map(x=>{const a=Object.values(sums).filter(r=>r.variant===x),sum=k=>a.reduce((n,r)=>n+r[k],0);return '<tr>'+cell(x)+cell(a.length)+cell(sum('trades'))+cell(sum('winners'))+cell(sum('losers'))+cell(f(sum('gross_profit')))+cell(f(sum('gross_loss')))+net(sum('net'))+cell(f(sum('peak')))+cell(f(sum('giveback')))+net(sum('net')-base)+cell(sum('inside'))+'</tr>'}).join('');$('days').innerHTML=Object.values(sums).filter(r=>!v||r.variant===v).map(r=>'<tr>'+cell(r.day)+cell(r.variant)+cell(r.trades)+cell(r.winners)+cell(r.losers)+net(r.net)+cell(f(r.peak))+cell(f(r.giveback))+net(r.net-(sums[r.day+'|CURRENT_STRATEGY']?.net||0))+cell('<a href="days/'+r.day+'/audit.html">3m audit</a>')+'</tr>').join('');$('trades').innerHTML=ts.filter(r=>!v||r.variant===v).map(r=>'<tr>'+[r.day,r.variant,r.side,r.route,r.setup,r.entry,r.exit,f(r.entry_price),f(r.exit_price)].map(cell).join('')+net(r.net)+[f(r.peak),f(r.giveback),r.entry_path,r.reason].map(cell).join('')+'</tr>').join('');$('coverage').textContent=new Set(scope.map(r=>r.day)).size+' completed matched sessions in view. Configurations are alternative backtests; do not add their totals together.';$('calendar').textContent=D.calendar.map(r=>r.day+' · '+r.status+(r.reason?' · '+r.reason:'')).join('\\n')}['day','variant','side'].forEach(id=>$(id).addEventListener('change',render));render();</script></html>'''
    (root/'index.html').write_text(template.replace('STATUS_TEXT',html.escape(status)).replace('PAYLOAD',payload))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,default=Path.cwd());p.add_argument('--through',type=date.fromisoformat,default=date(2026,11,25));p.add_argument('--self-test',action='store_true');a=p.parse_args()
    manifest=json.loads((HERE/'manifest.json').read_text())
    for filename,expected in manifest['files'].items():
        if code_hash(HERE/filename)!=expected:raise SystemExit('RESEARCH_FILE_HASH_MISMATCH:'+filename)
    inside=imported(HERE/'hilega-zone-entry-confirmation-v2-20261125.py','inside_month_helper')
    h=inside.load_helper(HERE/inside.HELPER);inside.InsideGate.helper=h;inside.self_test(h)
    if a.self_test:return
    repo=a.repo.resolve();os.chdir(repo);sys.path.insert(0,str(repo/'backend'))
    from dotenv import load_dotenv
    from market_lab.domain import IST
    from market_lab.hilega_rsi_two_route_v1 import engine as original
    from market_lab.hilega_rsi_two_route_v1.calendar import session_day,required_sessions,validate_rows,read_session
    from market_lab.hilega_rsi_two_route_v1.data import candidates,bars,digest
    from market_lab.upstox_live_shadow_sources_v1 import UpstoxLiveShadowSourcesV1
    if a.through.year!=2026 or a.through.month!=11:raise SystemExit('NOVEMBER_2026_ONLY')
    today=datetime.now(IST).date()
    if a.through>=today:raise SystemExit('USE_COMPLETED_PRIOR_DAYS_ONLY; choose --through before today')
    text=h.load_engine(original);load_dotenv(repo/'.env')
    root=repo/'data/research'/('november-seven-configs-'+datetime.now(IST).strftime('%Y%m%dT%H%M%S%f'));root.mkdir(parents=True)
    (root/'inputs').mkdir();memo={};input_hashes={};daily=[];trades=[];calendar_rows=[];old_gate=h.Gate
    source=UpstoxLiveShadowSourcesV1(os.environ.get('UPSTOX_ACCESS_TOKEN',''))
    def get(day,refresh=False):
        key=str(day)
        if key in memo and not refresh:return memo[key]
        rows=None;origin=None
        if not refresh:
            for path in candidates(repo,day):
                if path.exists():
                    try:rows=read_session(path,day);origin=str(path);break
                    except (ValueError,KeyError,TypeError,OSError):pass
        if rows is None:
            print('  Fetching verified candle session:',day,flush=True)
            try:items=source.historical_candles('NSE_INDEX|Nifty 50',day)
            except Exception as exc:raise ValueError('CANDLE_FETCH_FAILED:'+key+':'+type(exc).__name__) from None
            rows=[dict(timestamp=c.timestamp.astimezone(IST).isoformat(),open=float(c.open),high=float(c.high),low=float(c.low),close=float(c.close),volume=getattr(c,'volume',None)) for c in sorted(items,key=lambda c:c.timestamp)]
            rows=validate_rows(rows,day);origin='FRESH_READ_ONLY_BROKER_HISTORY'
        memo[key]=rows;input_hashes[key]=dict(sha256=digest(rows),source=origin)
        (root/'inputs'/(key+'.json')).write_text(json.dumps(dict(session_date=key,underlying='NSE_INDEX|Nifty 50',candles=rows),allow_nan=False))
        return rows
    targets=[];cursor=date(2026,11,1)
    while cursor<=a.through:
        if session_day(cursor):targets.append(cursor)
        else:calendar_rows.append(dict(day=str(cursor),status='CALENDAR_NON_SESSION'))
        cursor+=timedelta(days=1)
    print('Research output:',root,flush=True)
    print('Expected sessions:',', '.join(map(str,targets)),flush=True)
    def checkpoint():
        complete=sum(r['status']=='COMPLETE' for r in calendar_rows)
        status='COMPLETE' if complete==len(targets) else 'PARTIAL_OR_RUNNING'
        report=dict(status=status,through=str(a.through),expected_sessions=len(targets),completed_sessions=complete,calendar=sorted(calendar_rows,key=lambda r:r['day']),daily=daily,input_hashes=input_hashes,
                    strategy_id=original.STRATEGY_ID,strategy_version=original.VERSION,engine_sha256=code_hash(Path(original.__file__)),configuration_files_unchanged=True,services_restarted=False,orders_sent=False)
        (root/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False))
        write_csv(root/'daily-summary.csv',daily,['day','variant','trades','winners','losers','net_points','peak_positive_points','giveback_points','gross_profit','gross_loss','confirmed_entries_inside_zones'])
        write_csv(root/'trades.csv',trades,['day','variant','side','route','setup','entry','exit','entry_price','exit_price','net','peak','giveback','entry_path','reason'])
        monthly_html(root,daily,trades,report['calendar'],status+' · through '+str(a.through))
        return report
    try:
        for number,day in enumerate(targets,1):
            print(f'\nSESSION {number}/{len(targets)}: {day}',flush=True)
            day_results={}
            try:
                target=get(day,refresh=True)
                prior=required_sessions(day);warm=[]
                for d in prior:warm.extend(bars(get(d),d))
                for name,kind,config in VARIANTS:
                    print('  Running:',name,flush=True)
                    if kind=='current':engine=original.Engine(str(day),warm);gate=None
                    elif kind=='rsi':
                        ns=dict(__name__=original.__package__+'.monthly_rsi_only',__package__=original.__package__)
                        exec(compile(text,'<monthly-rsi-only>','exec'),ns);engine=ns['Engine'](str(day),warm);gate=None
                    else:
                        h.Gate=inside.InsideGate if kind=='inside' else old_gate
                        engine,gate=h.make_engine(original,text,day,warm,config)
                    for bar in bars(target,day):
                        if gate is None:engine.advance(bar,target)
                        else:h.advance(engine,gate,bar,target)
                    if engine.active:raise ValueError('SESSION_EXIT_MISSING')
                    r=engine.result();r['summary']=metrics(r);day_results[name]=r
                    s=r['summary'];print(f"    PASS trades={s['trades']} net={s['net_points']:+.2f} peak={s['peak_positive_points']:.2f} giveback={s['giveback_points']:.2f}",flush=True)
                dayroot=root/'days'/str(day);dayroot.mkdir(parents=True)
                metadata=dict(day=str(day),minute_sha256=digest(target),warmup_sessions=[str(d) for d in prior],warmup_hashes={str(d):input_hashes[str(d)]['sha256'] for d in prior},engine_sha256=code_hash(Path(original.__file__)),mode='RESEARCH_ONLY')
                (dayroot/'comparison.json').write_text(json.dumps(dict(metadata=metadata,results=day_results),allow_nan=False))
                inside.make_html(dayroot,day_results,metadata)
                # Replace the generic per-day introduction to cover all seven variants accurately.
                hp=dayroot/'audit.html';ht=hp.read_text().replace('Strong entries inside EMA zones','Seven-configuration daily audit').replace('Strong setup + follow-up: entries inside EMA zones','Seven-configuration daily audit').replace('All variants retain the RSI5/RSI9 exit.','CURRENT_STRATEGY retains the installed original exits. The other six variants add the RSI5/RSI9 exit. RSI_EXIT_ONLY has no EMA10 zone filter or strength confirmation. RSI_EXIT_EMA_ZONES blocks closes in either zone without strength confirmation.').replace('Input: 375 verified target minutes and the same 20 prior sessions.',f'Input: {len(target)} verified target minutes and the same 20 prior sessions.')
                hp.write_text(ht)
                for name,r in day_results.items():
                    daily.append(dict(day=str(day),variant=name,**r['summary']))
                    for t in r['trades']:
                        trades.append(dict(day=str(day),variant=name,side=t['side'],route=t['route_name'],setup=t['entry_candle_start'][11:16],entry=t['entry_time'][11:16],exit=t['exit_time'][11:16],entry_price=t['entry_price'],exit_price=t['exit_price'],net=t['points'],peak=t['peak_positive_points'],giveback=t['giveback_points'],entry_path=(t['entry_evaluation'].get('confirmation_audit') or {}).get('phase','ORIGINAL_ENTRY'),reason='; '.join(t['exit_reasons'])))
                calendar_rows.append(dict(day=str(day),status='COMPLETE'))
            except Exception as exc:
                reason=str(exc)[:200] if isinstance(exc,ValueError) else type(exc).__name__
                print('  BLOCKED:',reason,flush=True)
                calendar_rows.append(dict(day=str(day),status='BLOCKED',reason=reason))
                # Preserve partial evidence without including an unmatched day in totals.
                fail=root/'days'/str(day);fail.mkdir(parents=True,exist_ok=True)
                (fail/'partial.json').write_text(json.dumps(day_results,allow_nan=False))
            checkpoint()
    finally:
        h.Gate=old_gate;source.close();report=checkpoint()
    print('\nMATCHED MONTH TOTALS',flush=True)
    for name,_,_ in VARIANTS:
        ss=[r for r in daily if r['variant']==name]
        print(json.dumps(dict(variant=name,sessions=len(ss),trades=sum(r['trades'] for r in ss),winners=sum(r['winners'] for r in ss),losers=sum(r['losers'] for r in ss),net_points=round(sum(r['net_points'] for r in ss),2),peak_positive_points=round(sum(r['peak_positive_points'] for r in ss),2),giveback_points=round(sum(r['giveback_points'] for r in ss),2),gross_loss=round(sum(r['gross_loss'] for r in ss),2))),flush=True)
    zpath=root.with_suffix('.zip')
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
        for path in root.rglob('*'):
            if path.is_file():z.write(path,path.relative_to(root))
    print('STATUS:',report['status']);print('HTML:',root/'index.html');print('REPORT:',root/'report.json');print('UPLOAD ZIP:',zpath)
    print('Research only. No installed files, execution settings, services or orders changed.')
    if report['status']!='COMPLETE':raise SystemExit(2)

if __name__=='__main__':main()
