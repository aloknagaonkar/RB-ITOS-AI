"""Closed reader repair transaction. Check never changes installed files/services."""
import argparse, fcntl, hashlib, importlib.util, json, os, shlex, sqlite3, stat, subprocess, sys, tempfile, time
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PLAN_HASH='1fc67abdd3784899480bbb3a0f071aec4e3ddef811dcc61e4f2cd6a60568e762'
RECOVERY='hilega-closed-pause-recovery.service'
def need(ok,reason):
    if not ok: raise ValueError(reason)
def raw(p):
    p=Path(p);need(p.is_absolute() and p.is_file() and not any(q.is_symlink() for q in (p,*p.parents)),'REGULAR_FILE_REQUIRED');return p.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(raw(p))
def atomic(p,b,mode=0o600):
    need(not any(q.is_symlink() for q in (p,*p.parents)),'SYMLINK_REJECTED')
    fd,tmp=tempfile.mkstemp(prefix='.reader-repair-',dir=p.parent)
    try:
        os.fchmod(fd,mode)
        with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
        os.replace(tmp,p)
        fd=os.open(p.parent,os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
def save(p,v):atomic(p,(json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
def command(args,timeout=60):
    r=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
    need(r.returncode==0,'COMMAND_FAILED: '+args[0]);return r.stdout
def ctl(action,unit):command(['systemctl','--user',action,unit],100)
def properties(unit):
    out=command(['systemctl','--user','--no-pager','--full','show',unit,'--property=ActiveState,SubState,MainPID,FragmentPath,DropInPaths,ExecStart'])
    return dict(l.split('=',1) for l in out.splitlines() if '=' in l)
def seal(root,digest):
    b=raw(root/'RELEASE-MANIFEST.json');need(sha(b)==digest,'RELEASE_MANIFEST_CHANGED');v=json.loads(b)
    for name,h in v['files'].items():
        rel=Path(name);need(not rel.is_absolute() and '..' not in rel.parts,'UNSAFE_PATH');need(sha(raw(root/rel))==h,'RELEASE_FILE_CHANGED')
    actual=set()
    for p in root.rglob('*'):
        need(not p.is_symlink(),'RELEASE_SYMLINK')
        if p.is_file():actual.add(p.relative_to(root).as_posix())
    need(actual==set(v['files'])|{'RELEASE-MANIFEST.json'},'UNMANIFESTED_FILE')
    reg=load(root/'runtime/FACTORY-REGISTRATION.json');need(reg['enabled'] is False and reg['production_execution_enabled'] is False,'DISABLED_FACTORY_REQUIRED')
    reg=load(root/'CLOSED-REGISTRATION.json');need(reg['mode']=='CLOSED_PREPARATION_ONLY' and reg['execution_factory_configured'] is False and reg['production_execution_enabled'] is False,'CLOSED_REGISTRATION_REQUIRED')
def module(path,name):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def helper(repo):
    tool=repo/'hilega-group1-rollout-v1'
    for n,h in load(tool/'MANIFEST.json').items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts,'UNSAFE_TOOL_PATH');need(sha(raw(tool/rel))==h,'MAINTENANCE_TOOL_CHANGED')
    sys.path[:0]=[str(tool),str(repo/'hilega-production-application-deployment')]
    return module(tool/'maintenance_primitives.py','repair_primitives'),module(tool/'rollout.py','repair_rollout')
def baseline(p,m):
    m.require_empty_closed_baseline(Path(p['application_db']),Path(p['adapter_db']))
    with sqlite3.connect(Path(p['application_db']).as_uri()+'?mode=ro',uri=True) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN')
        c=json.loads(db.execute('SELECT data FROM control WHERE id=1').fetchone()[0]);r=json.loads(db.execute('SELECT data FROM preparation_route WHERE id=1').fetchone()[0])
        need(c['mode']=='PAUSED' and c['production_execution_enabled'] is False and c['simulation_only'] is True and r['route']=='PREPARATION_ONLY','CLOSED_PAUSED_REQUIRED')
    return c
# The same atomic replacement/restore primitives below are exercised with injected faults.
def replace_pair(entries,checkpoint=lambda n:None):
    for i,(path,b,mode) in enumerate(entries):atomic(path,b,mode);checkpoint(i+1)
def restore_pair(entries):
    for path,b,mode in reversed(entries):atomic(path,b,mode)
def transaction_tests(folder):
    for fault in (1,2,None):
        case=folder/('case-'+str(fault));case.mkdir(mode=0o700)
        paths=[case/'worker',case/'unit'];old=[b'original-worker',b'original-unit'];new=[b'candidate-worker',b'candidate-unit']
        for p,b in zip(paths,old):atomic(p,b)
        def checkpoint(n):
            if n==fault:raise RuntimeError('INJECTED_REPLACEMENT_FAILURE')
        try:replace_pair([(p,b,0o600) for p,b in zip(paths,new)],checkpoint)
        except RuntimeError:restore_pair([(p,b,0o600) for p,b in zip(paths,old)])
        need([raw(p) for p in paths]==(old if fault else new),'TRANSACTION_REHEARSAL_FAILED')
        need(all(stat.S_IMODE(p.stat().st_mode)==0o600 for p in paths),'PRIVATE_MODES_LOST')
    return dict(replacement_fault_cases=2,successful_pair_case=1,service_failure_rehearsed=False)
def prepare(args):
    repo=args.repo.resolve();path=repo/'hilega-reader-install-preparation-w3lwp_la/INSTALLATION.json'
    need(sha(raw(path))==PLAN_HASH,'INSTALLATION_PLAN_CHANGED');p=load(path);p['adapter_db']=str(repo/'data/research/hilega-broker-adapter-closed/adapter.sqlite');folder=path.parent
    need(Path(p['worker_destination'])==repo/'scripts/hilega_production_simulator_bridge.py','REPO_SCOPE_CHANGED')
    need(Path(p['recovery_unit_destination'])==Path.home()/'.config/systemd/user'/RECOVERY,'UNIT_SCOPE_CHANGED')
    need(Path(p['proposed_release_destination'])==repo/'data/runtime/hilega-closed-releases'/p['candidate_release_sha256'],'RELEASE_SCOPE_CHANGED')
    for n,h in load(HERE/'MANIFEST.json').items():need(sha(raw(HERE/n))==h,'INSTALLER_CHANGED')
    for n,h in p['payload_hashes'].items():need(sha(raw(folder/'payload'/n))==h,'PAYLOAD_CHANGED')
    seal(Path(p['candidate']),p['candidate_release_sha256']);seal(Path(p['old_release']),Path(p['old_release']).name)
    return repo,p,folder

def main():
    a=argparse.ArgumentParser();a.add_argument('--repo',type=Path,required=True);a.add_argument('--action',choices=['check','apply'],default='check');a.add_argument('--check',type=Path);a.add_argument('--check-sha256');args=a.parse_args()
    repo,p,folder=prepare(args);m,old=helper(repo)
    lock=repo/'.hilega-closed-rollout.lock';need(not lock.is_symlink(),'LOCK_SYMLINK')
    fd=os.open(lock,os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'r+') as held:
        fcntl.flock(held,fcntl.LOCK_EX|fcntl.LOCK_NB)
        c=baseline(p,m);units={u:properties(u) for u in (*m.UNITS,RECOVERY,'hilega-quote-observer.service')}
        need(units[m.UNITS[0]]['ActiveState'] in {'failed','inactive'} and int(units[m.UNITS[0]]['MainPID'])==0,'FAILED_SOURCE_BASELINE_REQUIRED')
        need(all(units[u]['ActiveState']=='active' and int(units[u]['MainPID'])>0 for u in m.UNITS[1:]),'COMPANION_NOT_RUNNING')
        need(units[RECOVERY]['ActiveState']=='active' and not units[RECOVERY]['DropInPaths'],'EXACT_ACTIVE_RECOVERY_REQUIRED')
        need(int(units['hilega-quote-observer.service']['MainPID'])==0,'QUOTE_OBSERVER_MUST_BE_STOPPED')
        need(sha(raw(Path(p['worker_destination'])))==p['old_worker_sha256'] and sha(raw(Path(p['recovery_unit_destination'])))==p['old_recovery_unit_sha256'],'INSTALLED_BINDING_CHANGED')
        need(not Path(p['proposed_release_destination']).exists() and not Path(p['new_recovery_folder']).exists(),'DESTINATION_EXISTS')
        bindings={}
        for v in units.values():
            for n in ([v['FragmentPath']] if v['FragmentPath'] else [])+shlex.split(v['DropInPaths']):bindings[n]=sha(raw(Path(n)))
        supervision=Path.home()/'hilega-persistent-supervision-stage-v1'
        permit=load(supervision/'MIGRATION_APPROVED.json')
        need(permit.get('config_sha256')==sha(raw(supervision/'config-private.json')) and permit.get('runner_sha256')==sha(raw(supervision/'runner.py')),'SUPERVISION_APPROVAL_CHANGED')
        for n in ('runner.py','config-private.json','MIGRATION_APPROVED.json'):bindings[str(supervision/n)]=sha(raw(supervision/n))
        for n in ('CONFIG.json','live_recovery.py'):bindings[str(Path(p['old_recovery_folder'])/n)]=sha(raw(Path(p['old_recovery_folder'])/n))
        state=dict(controller_version=c['version'],session_date=c['session_date'],units=units,bindings=bindings)
        if args.action=='check':
            recovery_receipt=load(folder/'recovery-rehearsal-32bsab1i/PROCESS.json')
            need(recovery_receipt['exit_code']==0 and recovery_receipt['installation_plan_sha256']==PLAN_HASH,'PASSING_RECOVERY_REHEARSAL_REQUIRED')
            need(json.loads(recovery_receipt['stdout'])['status']=='LIVE_ADAPTER_SYNTHETIC_REHEARSAL_PASS','RECOVERY_REHEARSAL_NOT_PASSED')
            audit=Path(tempfile.mkdtemp(prefix='installer-check-',dir=folder));audit.chmod(0o700)
            tests=transaction_tests(audit)
            receipt=dict(status='READER_REPAIR_INSTALLER_CHECK_PASS',created_at=time.time(),installation_plan_sha256=PLAN_HASH,installer_manifest_sha256=sha(raw(HERE/'MANIFEST.json')),state=state,tests=tests,services_changed=False,production_execution_enabled=False)
            save(audit/'CHECK.json',receipt);print(json.dumps(dict(check=str(audit/'CHECK.json'),check_sha256=sha(raw(audit/'CHECK.json')),**receipt),indent=2));return
        need(args.check and args.check_sha256,'EXACT_CHECK_REQUIRED');need(sha(raw(args.check.absolute()))==args.check_sha256,'CHECK_CHANGED');check=load(args.check.absolute())
        need(check['status']=='READER_REPAIR_INSTALLER_CHECK_PASS' and check['installation_plan_sha256']==PLAN_HASH and check['installer_manifest_sha256']==sha(raw(HERE/'MANIFEST.json')),'CHECK_SCOPE_CHANGED')
        need(0<=time.time()-check['created_at']<=1800,'CHECK_EXPIRED');need(check['state']==state,'BASELINE_CHANGED_RECHECK')
        audit=Path(tempfile.mkdtemp(prefix='installer-transaction-',dir=folder));audit.chmod(0o700)
        originals=[(Path(p['worker_destination']),raw(Path(p['worker_destination'])),stat.S_IMODE(Path(p['worker_destination']).stat().st_mode)),(Path(p['recovery_unit_destination']),raw(Path(p['recovery_unit_destination'])),stat.S_IMODE(Path(p['recovery_unit_destination']).stat().st_mode))]
        for i,(_,b,_) in enumerate(originals):atomic(audit/('original-'+str(i)),b)
        def phase(value):save(audit/'TRANSACTION.json',dict(phase=value,production_execution_enabled=False,automatic_database_restore=False))
        print('AUDIT: '+str(audit),flush=True);phase('STOPPING')
        try:
            for u in m.UNITS:ctl('stop',u)
            ctl('stop',RECOVERY)
            need(all(int(properties(u)['MainPID'])==0 and properties(u)['ActiveState']=='inactive' for u in (*m.UNITS,RECOVERY)),'QUIESCENCE_FAILED')
            m.no_unmanaged_python(repo);baseline(p,m)
            for n,h in bindings.items():need(sha(raw(Path(n)))==h,'BOUND_FILE_CHANGED')
            for key in ('application_db','adapter_db'):
                m.backup_database(Path(p[key]),audit/(key+'.sqlite'))
                with sqlite3.connect((audit/(key+'.sqlite')).as_uri()+'?mode=ro',uri=True) as db:need(db.execute('PRAGMA integrity_check').fetchone()[0]=='ok','BACKUP_INVALID')
            phase('BACKED_UP_SERVICES_STOPPED')
            # New immutable destinations only. Retained even on rollback for audit.
            dest=Path(p['proposed_release_destination']);dest.mkdir(mode=0o700)
            src=Path(p['candidate']);manifest=load(src/'RELEASE-MANIFEST.json')
            for name in [*manifest['files'],'RELEASE-MANIFEST.json']:
                path=dest/name;path.parent.mkdir(parents=True,exist_ok=True,mode=0o700);atomic(path,raw(src/name))
            seal(dest,p['candidate_release_sha256'])
            recovery=Path(p['new_recovery_folder']);recovery.mkdir(mode=0o700)
            for name in ('CONFIG.json','live_recovery.py'):atomic(recovery/name,raw(folder/'payload'/name))
            replacements=[(originals[0][0],raw(folder/'payload/worker.py'),originals[0][2]),(originals[1][0],raw(folder/'payload/recovery.service'),originals[1][2])]
            phase('REPLACING_BINDINGS');replace_pair(replacements)
            command(['systemctl','--user','daemon-reload']);phase('STARTING_CLOSED_RECOVERY');ctl('start',RECOVERY);baseline(p,m)
            previous=old.read_health(Path(p['application_db']))['run_id']
            for u in reversed(m.UNITS[1:]):ctl('start',u)
            old.wait_inventory(repo)
            command(['systemctl','--user','reset-failed',m.UNITS[0]]);ctl('start',m.UNITS[0])
            old.wait_health(Path(p['application_db']),previous,m.Systemd(),list(m.UNITS),timeout=90);baseline(p,m)
            need(sha(raw(originals[0][0]))==p['new_worker_sha256'] and sha(raw(originals[1][0]))==p['new_recovery_unit_sha256'],'POST_INSTALL_HASH_CHANGED')
            phase('CLOSED_READER_REPAIR_RUNNING');print(json.dumps(dict(status='CLOSED_READER_REPAIR_RUNNING',audit=str(audit),controller_resumed=False,production_execution_enabled=False,fresh_signal_preparation_verified=False),indent=2))
        except BaseException:
            phase('FAILURE_STOPPING_FOR_ROLLBACK')
            try:
                for u in m.UNITS:ctl('stop',u)
                ctl('stop',RECOVERY);restore_pair(originals);command(['systemctl','--user','daemon-reload']);ctl('start',RECOVERY);baseline(p,m)
                for u in reversed(m.UNITS[1:]):ctl('start',u)
                old.wait_inventory(repo);baseline(p,m);phase('ROLLED_BACK_SOURCE_LEFT_STOPPED')
            except BaseException:
                # Do not start the source after any rollback failure.
                phase('ROLLBACK_REQUIRES_REVIEW_SOURCE_STOP_REQUESTED')
                try:ctl('stop',m.UNITS[0])
                except Exception:pass
            raise
if __name__=='__main__':
    try:main()
    except Exception as e:
        print(json.dumps(dict(status='READER_REPAIR_INSTALLER_BLOCKED',reason=str(e) if type(e) is ValueError else type(e).__name__,production_execution_enabled=False)),flush=True);raise SystemExit(2)
