# Hilega closed reader repair installer v1

For the exact INSTALLATION.json SHA 1fc67abdd3784899480bbb3a0f071aec4e3ddef811dcc61e4f2cd6a60568e762 on the VM.

Run check first:

    .venv/bin/python -B hilega-reader-repair-installer-v1/manage.py --repo "$PWD" --action check

Check verifies installation payload, both sealed releases, disabled registrations, paused empty application and closed adapter, failed source and active companions, stopped quote observer, unit definitions, supervision approval hashes, and the previous synthetic recovery receipt. Two injected pair-replacement failures and a successful pair replacement run against disposable files. No installed file or service is changed. The common maintenance lock may be created.

Check DOES NOT prove the complete service orchestration or process crash recovery. No behavioral tests were run by the author; VM execution is required. A passing check is not activation or production certification. Return CHECK.json and its SHA for review before using apply.

Apply exists for a reviewed fresh check (30-minute expiry), but is not the requested first command. It compares all recorded service state and binding hashes, stops the six closed services and recovery, verifies process quiescence, creates consistent database backups, installs the new immutable release and recovery directory privately, replaces launcher and recovery unit, reloads systemd, runs closed pause recovery, starts companions then source, and verifies distinct worker heartbeats. No resume, authority grant, broker order, or credential change is performed.

On an ordinary exception, it requests all services stopped, restores the original launcher/unit, reloads systemd, runs the old pause recovery and restarts companions. The source remains stopped. Restored old code still has the size limit. Rollback failure is recorded and requires review. Database backups are never automatically restored. New release directories remain for audit. Abrupt termination/power loss is not automatically recovered; inspect TRANSACTION.json before another operation. Existing old warmup baseline hashes are never rewritten.
