"""Post-commit forward repair proposal and no-bytecode wrapper rehearsal. No live writes."""
import argparse,hashlib,importlib.util,json,os,sqlite3,subprocess,sys,tempfile,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
PROPOSAL_SHA='ff6dd6ea0b27525c514cd9f9d38856a791278edb1e10f6fb718974633f69cd0f'
RELEASE='e21825cbe956c8d13492684861dee2e00a2e48d17c79d0a9f6418e615d956b75'
RECOVERY='hilega-closed-pause-recovery.service'
def need(ok,reason):
    if not ok:raise ValueError(reason)
def raw(p):
    need(p.is_absolute() and p.is_file() and not any(q.is_symlink() for q in (p,*p.parents)),'REGULAR_FILE_REQUIRED');return p.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(raw(p))
def encode(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def put(p,b):
    p.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    with p.open('xb') as f:f.write(b)
    p.chmod(0o600)
def verify(root):
    for n,h in load(root/'MANIFEST.json').items():
        rel=Path(n);need(not rel.is_absolute() and '..' not in rel.parts and sha(raw(root/rel))==h,'PACKAGE_CHANGED')
def properties(unit):
    r=subprocess.run(['systemctl','--user','--no-pager','--full','show',unit,'--property=ActiveState,SubState,MainPID,FragmentPath,DropInPaths,ExecStart'],capture_output=True,text=True,timeout=15,check=True);return dict(l.split('=',1) for l in r.stdout.splitlines() if '=' in l)
def inventory(root,manifest):
    expected=set(manifest['files'])|{'RELEASE-MANIFEST.json'};extras={}
    for path in root.rglob('*'):
        need(not path.is_symlink(),'RELEASE_SYMLINK')
        if not path.is_file():continue
        rel=path.relative_to(root).as_posix()
        if rel in expected:continue
        need(path.suffix=='.pyc' and path.parent.name=='__pycache__','NON_BYTECODE_EXTRA_REQUIRES_REVIEW')
        try:source=Path(importlib.util.source_from_cache(str(path)))
        except ValueError:raise ValueError('NONSTANDARD_CACHE_REQUIRES_REVIEW') from None
        need(source.is_relative_to(root) and source.relative_to(root).as_posix() in manifest['files'],'CACHE_WITHOUT_MANIFESTED_SOURCE')
        extras[rel]=dict(sha256=sha(raw(path)),size=path.stat().st_size,source=source.relative_to(root).as_posix())
    for n,h in manifest['files'].items():need(sha(raw(root/n))==h,'MANIFESTED_SOURCE_CHANGED')
    return extras

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--repo',type=Path,required=True);a=ap.parse_args();repo=a.repo.resolve();verify(HERE)
    proposal=repo/'hilega-native-migration-plan-on2233ej/PLAN.json';need(sha(raw(proposal))==PROPOSAL_SHA,'ORIGINAL_PROPOSAL_CHANGED');p=load(proposal);dest=Path(p['destination']);need(dest==repo/'data/runtime/hilega-closed-releases'/RELEASE,'EXACT_RELEASE_REQUIRED')
    mb=raw(dest/'RELEASE-MANIFEST.json');need(sha(mb)==RELEASE,'MANIFEST_CHANGED');manifest=json.loads(mb);extras=inventory(dest,manifest)
    clean=Path(p['candidate']);need(raw(clean/'RELEASE-MANIFEST.json')==mb,'CANDIDATE_MANIFEST_CHANGED');need(not inventory(clean,manifest),'CLEAN_CANDIDATE_HAS_EXTRAS')
    failed=proposal.parent/'native-install-transaction-fcdjn7p0';need(load(failed/'TRANSACTION.json')['phase']=='FILES_RESTORED_CURSOR_COMMITTED_SOURCE_STOPPED','EXPECTED_POST_COMMIT_ROLLBACK_REQUIRED')
    for n,h in p['payload_hashes'].items():need(sha(raw(proposal.parent/'payload'/n))==h,'PROPOSAL_PAYLOAD_CHANGED')
    tool=repo/'hilega-group1-rollout-v1';verify(tool);spec=importlib.util.spec_from_file_location('bytecode_repair_primitives',tool/'maintenance_primitives.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    app=Path(p['application_db']);adapter=Path(p['adapter_db']);m.require_empty_closed_baseline(app,adapter)
    with sqlite3.connect(app.as_uri()+'?mode=ro',uri=True) as db:
        db.execute('PRAGMA query_only=ON');db.execute('BEGIN');control=json.loads(db.execute('SELECT data FROM control WHERE id=1').fetchone()[0]);cursor=json.loads(db.execute('SELECT data FROM preparation_source WHERE id=1').fetchone()[0]);receipt=json.loads(db.execute('SELECT data FROM hilega_native_source_transition_v1 WHERE id=1').fetchone()[0])
    need(control['mode']=='PAUSED' and control['production_execution_enabled'] is False and control['simulation_only'] is True,'PAUSED_CLOSED_REQUIRED');need(receipt['proposal_sha256']==PROPOSAL_SHA and receipt['release_sha256']==RELEASE and receipt['new_cursor']==p['proposed_baseline'],'COMMITTED_RECEIPT_CHANGED');need(cursor['sequence']>=receipt['new_cursor']['sequence'] and cursor['path']==receipt['new_cursor']['path'],'CURSOR_REGRESSION_OR_PATH_CHANGED')
    states={n:properties(n) for n in (*m.UNITS,RECOVERY,'hilega-quote-observer.service')};need(states[m.UNITS[0]]['ActiveState'] in {'inactive','failed'} and int(states[m.UNITS[0]]['MainPID'])==0,'SOURCE_STOPPED_REQUIRED');need(all(states[n]['ActiveState']=='active' and int(states[n]['MainPID'])>0 for n in m.UNITS[1:]),'COMPANION_STATE_CHANGED');need(states[RECOVERY]['ActiveState']=='active' and int(states['hilega-quote-observer.service']['MainPID'])==0,'RECOVERY_OR_OBSERVER_STATE_CHANGED')
    old_worker=raw(Path(p['worker']));old_unit=raw(Path(p['recovery_unit']));need(sha(old_worker)==p['old_worker_sha256'] and sha(old_unit)==p['old_recovery_unit_sha256'],'RESTORED_FILE_BINDINGS_CHANGED')
    base_worker=raw(proposal.parent/'payload/worker.py');anchor=b'import hashlib,json,runpy,os,sys\n';need(base_worker.count(anchor)==1 and b'sys.dont_write_bytecode' not in base_worker,'EXACT_WRAPPER_PATCH_REQUIRED');new_worker=base_worker.replace(anchor,anchor+b'sys.dont_write_bytecode=True\n')
    config=load(proposal.parent/'payload/CONFIG.json');need(config['bundle']==str(dest) and config['production_execution_enabled'] is False,'EXACT_NATIVE_RECOVERY_REQUIRED');config['worker_sha256']=sha(new_worker);new_config=encode(config);new_recovery=Path(p['new_recovery_folder']).parent/sha(new_config);need(not new_recovery.exists(),'NEW_RECOVERY_DESTINATION_REQUIRED')
    base_unit=raw(proposal.parent/'payload/recovery.service');old_id=Path(p['new_recovery_folder']).name;need(base_unit.count(old_id.encode())==3,'EXACT_NATIVE_RECOVERY_UNIT_REQUIRED');new_unit=base_unit.replace(old_id.encode(),new_recovery.name.encode())
    contract=repo/'hilega-native-preparation-contract-v1';reader=repo/'hilega-source-reader-candidate-v3';verify(contract);verify(reader);sys.path.insert(0,str(contract));spec=importlib.util.spec_from_file_location('bytecode_reader',contract/'review.py');loader=importlib.util.module_from_spec(spec);spec.loader.exec_module(loader)
    with loader.reader(reader/'candidate.py')(Path(cursor['path'])) as rows:
        need(cursor['sequence']<=len(rows) and rows[cursor['sequence']-1]['record_hash']==cursor['hash'],'CURRENT_CURSOR_PREFIX_CHANGED');base=receipt['new_cursor'];need(rows[base['sequence']-1]['record_hash']==base['hash'],'MIGRATION_PREFIX_CHANGED')
    audit=Path(tempfile.mkdtemp(prefix='hilega-native-bytecode-repair-plan-',dir=repo));audit.chmod(0o700);stage=audit/'disposable-release';stage.mkdir(mode=0o700)
    for name in [*manifest['files'],'RELEASE-MANIFEST.json']:put(stage/name,raw(clean/name))
    test_wrapper=new_worker.replace(str(dest).encode(),str(stage).encode());need(test_wrapper!=new_worker,'DISPOSABLE_WRAPPER_ROOT_NOT_REBOUND');put(audit/'disposable-wrapper.py',test_wrapper);empty=audit/'empty.env';put(empty,b'');journal=audit/'empty.jsonl';put(journal,b'');db=audit/'application.sqlite';leases=[]
    print('AUDIT: '+str(audit),flush=True)
    for attempt in range(2):
        # Deliberately omit both -B and PYTHONDONTWRITEBYTECODE to exercise wrapper-level prevention.
        env=dict(PATH=os.defpath,LANG='C.UTF-8',HOME=str(audit),HILEGA_PRODUCTION_WORKSPACE_MODE='SIMULATION_ONLY',HILEGA_PRODUCTION_EXECUTION_ROUTE='PREPARATION_ONLY',HILEGA_PRODUCTION_SIM_BRIDGE_ENABLED='1',HILEGA_PRODUCTION_SIM_DB=str(db),HILEGA_PREPARATION_ADAPTER_DB=str(audit/'unused-adapter.sqlite'),HILEGA_PREPARATION_CAPTURE_ON_SIGNAL='0')
        r=subprocess.run([sys.executable,str(audit/'disposable-wrapper.py'),'--once','--env-file',str(empty),'--source',str(journal)],cwd=audit,env=env,capture_output=True,text=True,timeout=120)
        put(audit/('worker-'+str(attempt)+'.json'),encode(dict(exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr)));need(r.returncode==0,'NO_BYTECODE_WRAPPER_START_FAILED: '+str(audit));need(not inventory(stage,manifest),'WRAPPER_CREATED_UNMANIFESTED_CACHE')
        with sqlite3.connect(db.as_uri()+'?mode=ro',uri=True) as connection:
            c=json.loads(connection.execute('SELECT data FROM control WHERE id=1').fetchone()[0]);health=json.loads(connection.execute('SELECT data FROM sim_bridge_health WHERE id=1').fetchone()[0]);need(c['mode']=='PAUSED' and c['production_execution_enabled'] is False and health['phase']=='STOPPED','DISPOSABLE_RESTART_NOT_CLOSED');leases.append(health['run_id'])
            for table in ('intents','sim_orders','sim_fills','preparation_plans','preparation_shadow_holds','preparation_outbox'):need(connection.execute('SELECT COUNT(*) FROM '+table).fetchone()[0]==0,'DISPOSABLE_ACTIVITY_CREATED')
        print(json.dumps(dict(attempt=attempt+1,exit_code=0,bytecode_caches_created=False,controller_paused=True)),flush=True)
    need(leases[0]!=leases[1],'DISTINCT_DISPOSABLE_LEASES_REQUIRED');need(inventory(dest,manifest)==extras,'LIVE_CACHE_INVENTORY_CHANGED')
    for n,b in {'worker.py':new_worker,'CONFIG.json':new_config,'live_recovery.py':raw(proposal.parent/'payload/live_recovery.py'),'recovery.service':new_unit}.items():put(audit/'payload'/n,b)
    plan=dict(model='HILEGA_NATIVE_POST_COMMIT_BYTECODE_REPAIR_PROPOSAL_V1',status='POST_COMMIT_FORWARD_REPAIR_STAGED_NOT_APPLIED',repo=str(repo),created_at=time.time(),original_proposal=str(proposal),original_proposal_sha256=PROPOSAL_SHA,release=str(dest),release_sha256=RELEASE,worker=p['worker'],recovery_unit=p['recovery_unit'],old_worker_sha256=sha(old_worker),new_worker_sha256=sha(new_worker),old_recovery_unit_sha256=sha(old_unit),new_recovery_unit_sha256=sha(new_unit),old_recovery_folder=str(repo/'data/runtime/hilega-closed-pause-recovery'/ 'a8b24daa87d481410b47b47539e7bab303f98f13dc5945d533c5f894ceef2da4'),new_recovery_folder=str(new_recovery),application_db=str(app),adapter_db=str(adapter),controller_version=control['version'],session_date=control['session_date'],preserved_cursor=cursor,migration_receipt_sha256=sha(encode(receipt)),migration_transition_id=receipt['transition_id'],cache_files_to_quarantine=extras,unit_state=states,payload_hashes={q.name:sha(raw(q)) for q in (audit/'payload').iterdir()},wrapper_restart_cases=2,wrapper_cache_prevention_verified=True,cache_quarantine_performed=False,live_cursor_modified=False,services_changed=False,live_apply_available=False,production_execution_enabled=False)
    put(audit/'PLAN.json',encode(plan));print(json.dumps(dict(status=plan['status'],plan=str(audit/'PLAN.json'),plan_sha256=sha(raw(audit/'PLAN.json')),cache_files_to_quarantine=len(extras),preserved_cursor_sequence=cursor['sequence'],wrapper_restart_cases=2,wrapper_cache_prevention_verified=True,live_cursor_modified=False,services_changed=False,live_apply_available=False,production_execution_enabled=False),indent=2))
if __name__=='__main__':main()
