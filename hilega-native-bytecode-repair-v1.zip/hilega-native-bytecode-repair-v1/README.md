# Post-commit native bytecode forward repair proposal

Preparation and disposable wrapper tests only. No systemctl mutations, cache deletion/moves, installed file changes or live database writes. Preserves the current committed migration receipt and advanced cursor; never resets to the old proposal baseline.

Verifies original proposal, old-restored launcher/unit hashes, native release manifest and all source hashes. Only extra .pyc files under __pycache__ whose corresponding source is manifest-listed are eligible for proposed quarantine; any other extra or missing/changed source blocks. Caches are treated as untrusted artifacts and never executed by this tool. Their paths, sizes and hashes are recorded. A later exact repair must quarantine rather than discard them while source is stopped, then keep the strict no-extra-files manifest check.

Adds sys.dont_write_bytecode=True to the outer native wrapper before sealed imports. Regenerates the recovery config worker hash and recovery unit bindings. The sealed native payload/manifest itself is unchanged. Builds a clean disposable copy, rebinds only the disposable wrapper root, runs two complete once-only starts without -B or PYTHONDONTWRITEBYTECODE, and checks distinct leases, paused/empty state, and no generated caches. Those are empty-journal wrapper tests, not live source freshness or activation checks. The native application/recovery code is not weakened.

Native pause recovery against the new wrapper binding and an exact forward-repair transaction are still required before any live apply. Existing native source contract and migration receipts remain authoritative. This proposal has live_apply_available=false.

Only AST and ZIP structure checked locally. Run behavioral review on the VM.
